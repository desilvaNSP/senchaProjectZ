Ext.define('RestorationRoboticsArtasCalculator.view.ContentNavigation', {
    extend: 'Ext.NavigationView',
    xtype: 'contentnavigation',
    requires: [
    ],

    config: {
        height: '92%',

        layout: {
            type: 'card'
        },
        navigationBar: {
            hidden: true
        },

        items: [
            {
                xtype: 'practiceinformation'
            },
            {
                xtype: 'opportunities'
            },
            {
                xtype: 'harvestpayments'
            },
            {
                xtype: 'systemcosts'
            },
            {
                xtype: 'financingoptions'
            },
            {
                xtype: 'outputs'
            }
        ],
        listeners: {
            initialize: function () {
                this.setActiveItem(0);
            }
        }
    }
});
