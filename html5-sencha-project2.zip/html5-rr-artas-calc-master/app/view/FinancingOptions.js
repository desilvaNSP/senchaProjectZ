Ext.define('RestorationRoboticsArtasCalculator.view.FinancingOptions', {
    extend: 'RestorationRoboticsArtasCalculator.view.BaseView',
    xtype: 'financingoptions',
    requires: [
    ],
    config: {
        padding: '100 0 0 0',
        cls:'financingoptions'
    },
    financeOptionMonthlyPayment: function(formPanel) {
        this.fireEvent('financeMonthlyPayment', formPanel);
    },
    buyOptionsSelected: function(formPanel) {
        this.fireEvent('buyOptionsSelected', formPanel);
    },
    financingOption: function(formPanel) {
        this.fireEvent('financingOption', formPanel);
    },
    headlineReportSelected: function() {
        this.fireEvent('headlineReportSelected');
    },
    detailReportSelected: function() {
        this.fireEvent('detailReportSelected');
    },
    initialize: function() {
        this.topHorizontalDividerContainerWhite = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#FFFFFF'
        });
        this.topHorizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });
        var that = this;

        this.buyOptionRadioField = Ext.create('Ext.field.Radio',{
                width: '250px',
                height: '50px',
                margin: '0 0 0 215',
                name: 'buyOptions',
                value: 'buy',
                label: 'Buy',
                checked: true,
                labelWidth: '200px',
                cls: 'radioFinancingOptionsBuy',
                labelAlign: 'right',
                listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.buyOptionsSelected(that.formPanelFinance);
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });

        this.financeOptionRadioField = Ext.create('Ext.field.Radio',{
            width: '250px',
            height: '50px',
            name: 'buyOptions',
            value: 'finance',
            label: 'Finance',
            labelWidth: '200px',
            cls: 'radioFinancingOptionsLeaseTerms',
            labelAlign: 'right',
            listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.financingOption(that.formPanelFinance);
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });

        this.oneTimePaymentField = Ext.create('Ext.field.Text', {
            label: 'One Time Payment',
            name: 'oneTimePayment',
            labelWidth: '200px',
            margin: '20 0 0 0',
            cls: 'oneTimePayment',
            readOnly: true
        });

        this.shippingField = Ext.create('Ext.field.Text', {
            label: 'Shipping',
            name: 'shippingTextField',
            labelWidth: '200px',
            margin: '10 0 0 0',
            cls: 'shippingTextField',
            readOnly: true,
            width:'200px'
        });

        this.detailsReportBuyOptionField = Ext.create('Ext.field.Radio', {
            width: '250px',
            height: '50px',
            margin: '20 0 0 15',
            name: 'BuyResultOptions',
            value: 'detailsReport',
            label: 'Detailed Report',
            checked: true,
            labelWidth: '200px',
            cls: 'radioBuyResultOptionDetailed',
            labelAlign: 'right',
            listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.detailReportSelected();
                    that.detailsReportFinanceOptionField.check();
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    that.detailsReportFinanceOptionField.uncheck();
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });

        this.headlineReportBuyOptionField = Ext.create('Ext.field.Radio', {
            width: '250px',
            height: '50px',
            name: 'BuyResultOptions',
            value: 'headlineReport',
            label: 'HeadLine Report',
            labelWidth: '200px',
            cls: 'radioBuyResultOptionsBuy',
            labelAlign: 'right',
            margin: '20 0 0 15',
            listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.headlineReportSelected();
                    that.headlineReportFinanceField.check();
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    that.headlineReportFinanceField.uncheck();
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });

        this.financeTerm = Ext.create('Ext.field.Select', {
            name: 'financeTerm',
            label: 'Finance Term',
            hidden: true,
            cls: 'financeTermField',
            labelWidth: '200px',
            margin: '20 0 0 0',
            placeHolder: 'Select term',
            options: [
                {text: 'Default',  value: '0'},
                {text: '3 years',  value: '3'},
                {text: '4 years', value: '4'},
                {text: '5 years',  value: '5'}
            ],
            autoSelect: null,
            defaultTabletPickerConfig: {
                height: 180,
                width: 140,
                minHeight: 180
            },
            listeners : {
                change: function () {
                    that.financeOptionMonthlyPayment(that.formPanelFinance);
                },
                hide: function () {
                    if (this.getValue() === null){
                        this.setOptions([{text: 'Default',  value: '0'}]);
                        this.setValue('0');
                    }
                },
                painted: function () {
                    if (this.getOptions().length === 1)
                    {
                        this.setValue(null);
                        this.setOptions([
                            {text: '3 years',  value: '3'},
                            {text: '4 years', value: '4'},
                            {text: '5 years',  value: '5'}
                        ]);
                    }
                }
            }
        });

        this.downPayment = Ext.create('Ext.field.Text', {
            label: 'Down Payment',
            name: 'downPayment',
            hidden: true,
            labelWidth: '200px',
            margin: '20 0 0 0',
            cls: 'downPaymentField',
            placeHolder: 'Enter number',
            listeners: {
                blur: function() {
                    this.suspendEvents(false);
                    that.fieldBlur(this);
                    this.resumeEvents(true);
                },
                focus: function() {
                    that.fieldFocus(this);
                },
                change: function() {
                    that.financeOptionMonthlyPayment(that.formPanelFinance);
                },
                hide: function () {
                    if (this.getValue() === ''){
                        this.setValue('default');
                    }
                },
                painted: function () {
                    if (this.getValue() === 'default')
                    {
                        this.setValue('');
                    }
                }
            }
        });

        this.interestTerm = Ext.create('Ext.field.Select', {
            name: 'interestTerm',
            label: 'Interest Rate',
            hidden: true,
            cls: 'interestTermField',
            labelWidth: '200px',
            margin: '20 0 0 0',
            placeHolder: 'Select rate',
            options: [
                {text: 'Default',  value: '0'},
                {text: '5%',  value: '5%'},
                {text: '6%', value: '6%'},
                {text: '7%',  value: '7%'}
            ],

            autoSelect: null,
            defaultTabletPickerConfig: {
                height: 180,
                width: 140,
                minHeight: 180
            },
            listeners : {
                change: function() {
                    that.financeOptionMonthlyPayment(that.formPanelFinance);
                },
                hide: function () {
                    if (this.getValue() === null){
                        this.setOptions([{text: 'Default',  value: '0'}]);
                        this.setValue('0');
                    }
                },
                painted: function () {
                    if (this.getOptions().length === 1)
                    {
                        this.setValue(null);
                        this.setOptions([
                            {text: '5%',  value: '5%'},
                            {text: '6%', value: '6%'},
                            {text: '7%',  value: '7%'}
                        ]);
                    }
                }
            }
        });

        this.monthlyPayment = Ext.create('Ext.field.Text', {
            label: 'Monthly Payment',
            name: 'monthlyPayment',
            hidden: true,
            labelWidth: '200px',
            margin: '20 0 0 0',
            cls: 'monthlyPaymentField',
            readOnly: true
        });

        this.reportTextField = Ext.create('Ext.field.Text',{
            label: 'See Result',
            name: 'reportTextField',
            labelWidth: '200px',
            margin: '10 0 0 0',
            cls: 'reportTextField',
            readOnly: true,
            hidden: true,
            width:'200px'
        });

        this.detailsReportFinanceOptionField = Ext.create('Ext.field.Radio', {
            width: '250px',
            height: '50px',
            margin: '20 0 0 15',
            hidden: true,
            name: 'FinanceResultOptions',
            value: 'detailsReportFinance',
            label: 'Detailed Report',
            checked: true,
            labelWidth: '200px',
            cls: 'radioDetailedReportOptions',
            labelAlign: 'right',
            listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.detailReportSelected();
                    that.detailsReportBuyOptionField.check();
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    that.detailsReportBuyOptionField.uncheck();
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });


        this.headlineReportFinanceField = Ext.create('Ext.field.Radio', {
            width: '250px',
            height: '50px',
            margin: '20 0 0 15',
            hidden: true,
            name: 'FinanceResultOptions',
            value: 'headlineReportFinance',
            label: 'HeadLine Report',
            labelWidth: '200px',
            cls: 'radiofinanceResultOptions',
            labelAlign: 'right',
            listeners: {
                painted: function() {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function() {
                    that.headlineReportSelected();
                    that.headlineReportBuyOptionField.check();
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function() {
                    that.headlineReportBuyOptionField.uncheck();
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }
        });

        this.formPanelFinance = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['financingOptionsForm', 'formDefaults'],
            height: '100%',
            width: '70%',
            scrollable: false,
            margin: '0 auto'
        });

        this.formPanelFinance.add([this.buyOptionRadioField,this.financeOptionRadioField,this.oneTimePaymentField,
            this.shippingField,this.detailsReportBuyOptionField,this.headlineReportBuyOptionField,
            this.financeTerm,this.downPayment,this.interestTerm,this.monthlyPayment,this.reportTextField,
            this.detailsReportFinanceOptionField,this.headlineReportFinanceField]);

        this.formPanelFinance.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.FinancingOption'));
        this.formFinancingOptionsContainer = Ext.create(Ext.Container, {
            height: '100%',
            width: '100%',
            items: [
                {
                    html: 'Financing Options',
                    cls: 'formHeader'
                }
            ]
        });
        this.formFinancingOptionsContainer.add(this.formPanelFinance);
        this.formContainer = Ext.create(Ext.Container, {
            layout: {
                type: 'hbox',
                pack: 'center',
                align: 'center'
            },
            width: '100%',
            height: '100%'
        });
        this.dividerContainer = Ext.create(Ext.Container, {
            width: '1px',
            height: '100%',
            style: 'background:#AFAFAE'
        });
        this.horizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });

        this.formContainer.add(this.formFinancingOptionsContainer);
        this.add([this.topHorizontalDividerContainerWhite, this.topHorizontalDividerContainer, this.formContainer, this.horizontalDividerContainer]);
    },
    reset: function() {
        this.formPanelFinance.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.FinancingOption'));
    }
});
