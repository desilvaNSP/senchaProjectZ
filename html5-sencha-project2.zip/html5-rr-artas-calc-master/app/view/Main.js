Ext.define('RestorationRoboticsArtasCalculator.view.Main', {
    extend: 'Ext.Container',
    xtype: 'main',
    requires: [
        'Ext.TitleBar',
        'Ext.NavigationView',
        'Ext.Img',
        'Ext.SegmentedButton'
    ],
    config: {
        layout: 'vbox'
    },
    initialize: function () {
        var that = this;
        this.callParent(arguments);

        //Defining a custom checkbox field for options
        Ext.define('optionsCheckboxField', {
            extend: 'Ext.field.Checkbox',
            alias: 'widget.optionsCheckboxField',
            labelWidth: '0px',
            cls: 'roundedCheckButtonInactive',
            listeners: {
                painted: function () {
                    if (this.getChecked()) {
                        this.addCls('roundedCheckButtonActive');
                    } else {
                        this.addCls('roundedCheckButtonInactive');
                    }
                },
                check: function () {
                    this.addCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                },
                uncheck: function () {
                    this.removeCls('roundedCheckButtonActive');
                    this.addCls('roundedCheckButtonInactive');
                }
            }

        });


        this.menuButtonContainer = Ext.create('Ext.Container', {
            cls: 'menuButtonContainer',
            height: '8%',
            width: '100%',
            zIndex: 45,
            bottom: 0,
            items: [
                {
                    xtype: 'button',
                    width: '30%',
                    height: '100%',
                    text: 'MENU',
                    listeners: {
                        tap: function () {
                            that.menuView.show();
                            that.menuMaskContainer.show();

                        }
                    }
                }
            ]
        });
        this.menuMaskContainer = Ext.create('Ext.Container', {
            height: '100%',
            width: '100%',
            zIndex: 42,
            bottom: 0,
            style: 'backgroundColor : transparent;',
            opacity: 0.3,
            hidden: true

        });

        // bind the tap event to the Container
        this.menuMaskContainer.element.on({tap: {element: 'element', single: false, fn: function () {
            that.menuView.hide();
            that.menuMaskContainer.hide();
        }}});
        this.navigationView = Ext.create('RestorationRoboticsArtasCalculator.view.ContentNavigation', {});
        this.navBar = Ext.create('RestorationRoboticsArtasCalculator.view.NavBar', {});
        this.videoView = Ext.create('RestorationRoboticsArtasCalculator.view.VideoView', {});
        this.menuView = Ext.create('RestorationRoboticsArtasCalculator.view.MenuView', {});

        this.add([this.videoView, this.navigationView, this.menuButtonContainer, this.menuView, this.menuMaskContainer, this.navBar]);
    }
});
