Ext.define('RestorationRoboticsArtasCalculator.view.VideoView', {
    extend: 'Ext.Container',
    xtype: 'videoview',
    requires: [
        'Ext.Video',
        'Ext.Label'
    ],
    config: {
        layout: 'vbox'
    },

    canShowVideo: '',
    isVideoLoaded: false,
    itemId : '17175', //Staging ID - 17199 , Production ID - 17175

    paintedVideoView: function () {
        this.fireEvent('paintedVideoView');
    },
    pauseVideo: function () {
        this.fireEvent('pauseVideo');
    },
    skipVideo: function () {
        this.fireEvent('skipVideo');
    },
    videoStartUp: function (value) {
        this.fireEvent('videoStartUp', value);
    },
    videoStartUpCheck: function (value) {
        Ext.Viewport.fireEvent('videoStartUpCheck', value);
    },

    initialize: function () {
        var videoDetails = Ext.getStore('videodetails');
        this.canShowVideo = videoDetails.getAt(0).get('videoSkip');


        var that = this;
        this.skipButton = Ext.create('Ext.Button', {
            html: 'Skip Video',
            margin: '10 20 0 0',
            disabled: true,
            listeners: {
                tap: function () {
                    that.skipVideo();
                }
            }
        });

        this.videoCheck = Ext.create('Ext.field.Checkbox', {
            width: '200px',
            height: '50px',
            margin: '0 0 0 25',
            name: 'palyOnStartup',
            value: 'palyOnStartup',
            label: 'Play on Startup',
            labelWidth: '150px',
            labelAlign: 'right',
            listeners: {
                painted: function () {
                    if (that.canShowVideo) {
                        this.setCls('roundedCheckButtonActive');
                        this.check();
                    } else {
                        this.uncheck();
                        this.setCls('roundedCheckButtonInactive');
                    }
                },
                check: function () {
                    this.setCls('roundedCheckButtonActive');
                    this.removeCls('roundedCheckButtonInactive');
                    that.videoStartUp(true);
                },
                uncheck: function () {
                    this.removeCls('roundedCheckButtonActive');
                    this.setCls('roundedCheckButtonInactive');
                    that.videoStartUp(false);
                }
            }
        });


        this.videoContainerWrapper = Ext.create('Ext.Container', {
            layout: 'vbox',
            height: '100%',
            width: '100%',
            zIndex: 50,
            hidden: true,
            style: 'position:absolute;',
            listeners: {
                show: function () {
                    var videoDetails = Ext.getStore('videodetails');
                    that.canShowVideo = videoDetails.getAt(0).get('videoSkip');

                    if (that.canShowVideo) {
                        that.videoCheck.setCls('roundedCheckButtonActive');
                        that.videoCheck.check();
                        that.videoContainerWrapper.show();
                    }
                    else {
                        that.videoCheck.uncheck();
                        that.videoCheck.setCls('roundedCheckButtonInactive');
                    }

                }
            },
            items: [
                {
                    xtype: 'container',
                    layout: 'hbox',
                    height: '100px',
                    padding: '20',
                    style: 'background:#fff',
                    items: [
                        {
                            items: [that.videoCheck]
                        },
                        {
                            xtype: 'spacer'
                        },
                        {
                            items: [that.skipButton]
                        }
                    ]
                }
            ]

        });

        this.videoContainer = Ext.create('Ext.Container', {
            height: '700px',
            style: 'background:#fff'
        });
        this.mainVideo = Ext.create('Ext.Video', {
            width: '100%',
            height: '500px', // changed 500px to
            id: 'mainVideo',
            preload: true,
            autoplay: true,
            loop: false,
            //  url: 'resources/video/video.mp4',
//            posterUrl: 'resources/images/videoPoster.jpg',
            listeners: {
                painted: function () {
                    that.skipButton.enable();
                    if (!that.isVideoLoaded) {
                        macs.getAssetPath(that.itemId, function (dataUrl) {
                                that.mainVideo.setUrl(dataUrl.assetPath);
                            }
                        );

                        that.isVideoLoaded = true;
                    }
                    that.paintedVideoView();
                    this.play();
                },
                pause: function () {
                    that.pauseVideo();
                }
            }
        });


        this.videoContainer.add(this.mainVideo);
        this.videoContainerWrapper.add(this.videoContainer);
        this.add(this.videoContainerWrapper);

        if (this.canShowVideo) {
            this.videoCheck.setCls('roundedCheckButtonActive');
            this.videoCheck.check();
//            setTimeout(function () {
            that.videoContainerWrapper.show();
//            }, 100);

        }
        else {
            this.videoCheck.uncheck();
            this.videoCheck.setCls('roundedCheckButtonInactive');
        }

    }
});
