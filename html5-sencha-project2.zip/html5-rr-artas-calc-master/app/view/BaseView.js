Ext.define('RestorationRoboticsArtasCalculator.view.BaseView', {
    extend: 'Ext.Container',
    xtype: 'baseview',
    requires: [
    ],
    config: {

    },
    saveField: function () {
        this.fireEvent('saveField', this);
    },
    fieldBlur : function(field) {
        this.fireEvent('fieldBlur', field);
    },
    fieldFocus : function(field) {
        this.fireEvent('fieldFocus', field);
    },
    checkIsNaN: function(field) {
        if(isNaN(field.getValue())) {
            field.setValue('');
        }
    },
    disappear :function(){
      this.fireEvent('disappear', this);
    }
});
