Ext.define('RestorationRoboticsArtasCalculator.view.Opportunities', {
    extend: 'RestorationRoboticsArtasCalculator.view.BaseView',
    xtype: 'opportunities',
    requires: [
        'RestorationRoboticsArtasCalculator.form.Panel',
        'Ext.field.Radio'
    ],
    config: {
        padding: '100 0 0 0',
        items: [
        ]
    },
    pricingStrategyChange: function (formPanel) {
        this.fireEvent('pricingStrategyChange', formPanel);
    },
    initialize: function () {

        var that = this;

        this.topHorizontalDividerContainerWhite = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#FFFFFF'
        });
        this.topHorizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });

        this.formPanelOpportunities = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['opportunitiesForm', 'formDefaults'],
            height: '100%',
            //width: '45%',
            scrollable: false,
            padding: '0 10',
            items: [
                {
                    xtype: 'radiofield',
                    width: '220px',
                    height: '50px',
                    margin: '0 0 0 25',
                    name: 'cases',
                    value: 'casesWeek',
                    label: 'Cases/Week',
                    checked: true,
                    labelWidth: '150px',
                    cls: 'radioCasesWeek',
                    labelAlign: 'right',
                    listeners: {
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'radiofield',
                    width: '220px',
                    height: '50px',
                    name: 'cases',
                    value: 'casesMonths',
                    label: 'Cases/Month',
                    labelWidth: '150px',
                    cls: 'radioCasesMonths',
                    labelAlign: 'right',
                    listeners: {
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Month 1-3',
                    name: 'month1to3',
                    labelWidth: '200px',
                    margin: '70 0 0 0',
                    cls: 'month1to3',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Month 4-6',
                    name: 'month4to6',
                    labelWidth: '200px',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Month 7-9',
                    name: 'month7to9',
                    labelWidth: '200px',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Month 10-12',
                    name: 'month10to12',
                    labelWidth: '200px',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            that.checkIsNaN(this);
                        }
                    }
                }
            ]
        });
        this.formPanelOpportunities.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.OpportunityDetail'));

        this.formPanelArtasProcedure = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['opportunitiesForm', 'formDefaults'],
            height: '100%',
            scrollable: false,
            padding: '0 10',
            items: [
                {
                    xtype: 'selectfield',
                    width: '36%',
                    name: 'costOption',
                    labelWidth: '10px',
                    labelAlign: 'right',
                    cls: 'costOption',
                    value: 'costOption',
                    label: '>',
                    //labelWidth : '5%',
                    options: [
                        {text: 'Artas HA Cost', value: 'artasHACostSelected'},
                        {text: 'Procedure Attempt Cost', value: 'procedureAttemptCost'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 130,
                        minHeight: 130
                    }
                },
                {
                    xtype: 'textfield',
                    name: 'artasHACost',
                    labelWidth: '0px',
                    width: '57%',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            that.fieldBlur(this);
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        }
                    }
                },
                {
                    xtype: 'selectfield',
                    width: '70%',
                    label: 'Other Cost',
                    placeHolder: 'Select',
                    name: 'otherCost',
                    labelWidth: '210px',
                    cls: 'otherCostField',
                    value: 'perDay',
                    options: [
                        {text: 'Per Day', value: 'perDay'},
                        {text: 'Per Procedure', value: 'perWeek'},
                        {text: 'Per Month', value: 'perMonth'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 170,
                        minHeight: 170
                    }
                },
                {
                    xtype: 'textfield',
                    name: 'otherCostAmount',
                    labelWidth: '0px',
                    placeHolder: 'Enter number',
                    cls : 'otherCostInputField',
                    listeners: {
                        blur: function () {
                            that.fieldBlur(this);
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        }
                    }
                },
                {
                    xtype: 'selectfield',
                    label: 'Pricing Strategy',
                    name: 'pricingStrategy',
                    labelWidth: '210px',
                    cls: 'pricingStrategyField',
                    options: [
                        {text: 'Per Graft', value: 'perGraft'},
                        {text: 'Per Procedure', value: 'PerProcedure'}
                    ],
                    value: 'Per Procedure',
                    placeHolder: 'Select',
                    autoSelect: null,
                    defaultTabletPickerConfig: {
                        height: 120,
                        minHeight: 120
                    },
                    listeners: {
                        change: function () {
                            //  var formPanel = that.formPanelArtasProcedure;
//                            if (this.getValue() === 'perGraft') {
//                                formPanel.down('field[name=grafts]').show();
//
//                            }
//                            else if (this.getValue() === 'PerProcedure') {
//                                formPanel.down('field[name=grafts]').hide();
//                                that.pricingStrategyChange(that.formPanelArtasProcedure);
//                            }
                            that.pricingStrategyChange(that.formPanelArtasProcedure);

                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Grafts / Procedures',
                    name: 'grafts',
                    labelWidth: '210px',
                    placeHolder: 'Enter number',
                    listeners: {
                        change: function () {
                            that.pricingStrategyChange(that.formPanelArtasProcedure);
                        },
                        hide: function () {
                            if (this.getValue() === '') {
                                this.setValue('default');
                            }
                        },
                        blur: function () {
                            that.checkIsNaN(this);
                        },
                        painted: function () {
                            if (this.getValue() === 'default') {
                                this.setValue('');
                            }
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Price',
                    name: 'price',
                    labelWidth: '210px',
                    placeHolder: 'Enter number',
                    listeners: {
//                        painted: function() {
//                            that.fieldBlur(this);
//                        },
//
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                        },
                        focus: function () {
                            this.suspendEvents(false);
                            that.fieldFocus(this);
                            this.resumeEvents(true);
                        },
                        change: function () {
                            that.pricingStrategyChange(that.formPanelArtasProcedure);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    readOnly: true,
                    label: 'Price per Application',
                    name: 'pricePerApplication',
                    labelWidth: '210px',
                    cls: 'pricePerApplication',
                    listeners: {
                        painted: function () {
                            this.suspendEvents(false);
                            that.fieldFocus(this);
                            this.resumeEvents(true);


                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                        }
                    }
                }
            ]
        });
        this.formPanelArtasProcedure.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.ArtasProcedureDetail'));


        this.formPanelOpportunitiesContainer = Ext.create(Ext.Container, {
            height: '100%',
            width: '50%',
            items: [
                {
                    html: 'Opportunities',
                    cls: 'formHeader'
                }
            ]
        });
        this.formPanelOpportunitiesContainer.add(this.formPanelOpportunities);
        this.formPanelArtasProcedureContainer = Ext.create(Ext.Container, {
            height: '100%',
            width: '50%',
            items: [
                {
                    html: 'Artas Procedure',
                    cls: 'formHeader'
                }
            ]
        });
        this.formPanelArtasProcedureContainer.add(this.formPanelArtasProcedure);
        this.formContainer = Ext.create(Ext.Container, {
            layout: {
                type: 'hbox',
                pack: 'center',
                align: 'center'
            },
            width: '100%',
            height: '100%'
        });
        this.dividerContainer = Ext.create(Ext.Container, {
            width: '1px',
            height: '100%',
            style: 'background:#AFAFAE'
        });
        this.horizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });
        this.formContainer.add([this.formPanelOpportunitiesContainer, this.dividerContainer, this.formPanelArtasProcedureContainer]);
        this.add([this.topHorizontalDividerContainerWhite, this.topHorizontalDividerContainer, this.formContainer, this.horizontalDividerContainer]);
    },
    reset: function () {
        this.formPanelOpportunities.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.OpportunityDetail'));
        this.formPanelArtasProcedure.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.ArtasProcedureDetail'));
        var otherCostOptons = [
            {text: 'Per Day', value: 'perDay'},
            {text: 'Per Procedure', value: 'perWeek'},
            {text: 'Per Month', value: 'perMonth'}
        ];
        this.formPanelArtasProcedure.innerItems[2].setOptions(otherCostOptons).setValue(null);
        var graftProcedureOptions = [
            {text: 'Per Graft', value: 'perGraft'},
            {text: 'Per Procedure', value: 'PerProcedure'}
        ];
        this.formPanelArtasProcedure.innerItems[4].setOptions(graftProcedureOptions).setValue(null);
    }
});
