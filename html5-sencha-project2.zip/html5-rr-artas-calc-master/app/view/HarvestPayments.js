Ext.define('RestorationRoboticsArtasCalculator.view.HarvestPayments', {
    extend: 'RestorationRoboticsArtasCalculator.view.BaseView',
    xtype: 'harvestpayments',
    requires: [
    ],
    config: {
        padding: '100 0 0 0'
    },
    initialize: function() {
        this.topHorizontalDividerContainerWhite = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#FFFFFF'
        });
        this.topHorizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });

        this.formPanelHarvest = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['harvestPaymentsForm', 'formDefaults'],
            height: '100%',
            width: '75%',
            scrollable: false,
            margin: '0 auto',
            items: [
                {
                    xtype: 'textfield',
                    label: 'Patient Price<br/>Per Harvest',
                    name: 'patientPricePerHarvest',
                    labelWidth: '200px',
                    readOnly : true,
                    listeners: {

                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Cost Paid<br/>Per Harvest',
                    name: 'costPaidPerHarvest',
                    labelWidth: '200px',
                    readOnly : true,
                    listeners: {

                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Average Harvests<br/>Per Procedure',
                    name: 'averageHarvestsPerProcedure',
                    labelWidth: '200px',
                    readOnly : true,
                    listeners: {

                    }
                }
            ]
        });
        this.formHarvestPaymentsContainer = Ext.create(Ext.Container, {
            height: '100%',
            width: '100%',
            items: [
                {
                    html: 'Chart/Harvest Payments',
                    cls: 'formHeader'
                }
            ]
        });
        this.formPanelHarvest.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.HarvestPayment'));
        this.formHarvestPaymentsContainer.add(this.formPanelHarvest);
        this.formContainer = Ext.create(Ext.Container, {
            layout: {
                type: 'vbox',
                pack: 'center',
                align: 'center'
            },
            width: '100%',
            height: '100%'
        });
        this.dividerContainer = Ext.create(Ext.Container, {
            width: '1px',
            height: '100%',
            style: 'background:#AFAFAE'
        });
        this.horizontalDividerContainer = Ext.create(Ext.Container, {
            height: '1px',
            width: '100%',
            style: 'background:#AFAFAE'
        });

        this.formContainer.add(this.formHarvestPaymentsContainer);
        this.add([this.topHorizontalDividerContainerWhite, this.topHorizontalDividerContainer, this.formContainer, this.horizontalDividerContainer]);
    },
    reset: function() {
        this.formPanelHarvest.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.HarvestPayment'));
    }
});
