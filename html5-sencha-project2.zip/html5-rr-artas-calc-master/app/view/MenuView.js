Ext.define('RestorationRoboticsArtasCalculator.view.MenuView', {
    extend: 'Ext.Container',
    xtype: 'menuview',
    requires: [
        'RestorationRoboticsArtasCalculator.store.Assets'
    ],
    config: {
        layout: 'vbox',
        hidden: true,
        width: '100%',
        height: '70%',
        top: '30%',
        zIndex: 900,
        style: 'position:absolute;',
        showAnimation: {
            type: 'slide',
            duration: 500,
            direction: 'up'
        },
        hideAnimation: {
            type: 'slideOut',
            duration: 500,
            direction: 'down'
        },
        cls: 'menuView'
    },
    savePersonalSettings: function (button) {
        this.fireEvent('savePersonalSettings', button);
    },
    menuButtonTapped: function (button) {
        this.fireEvent('menuButtonTapped', button);
    },
    relatedDocumentsButtonTapped: function (button) {
        this.fireEvent('relatedDocumentsButtonTapped', button);
    },
    slideNotesButtonTapped: function (button) {
        this.fireEvent('slideNotesButtonTapped', button);
    },
    menuCloseButtonTapped: function () {
        this.fireEvent('menuCloseButtonTapped');
    },
    resetButtonTapped: function () {
        this.fireEvent('resetButtonTapped');
    },
    playBackVideo: function () {
        this.fireEvent('playBackVideo');
    },
    printPdf: function () {
        this.fireEvent('printPdf');
    },
    initialize: function () {
        var that = this;
        this.callParent(arguments);

        this.buttonContainer = Ext.create('Ext.Container', {
            layout: 'hbox',
            width: '100%',
            height: '10%',
            cls: 'buttonContainer',
            style: 'background:transparent;'
        });

        this.menuButton = Ext.create('Ext.Button', {
            text: 'MENU',
            width: '30%',
            height: '100%',
            listeners: {
                tap: function (button) {
                    that.menuButtonTapped(button);
                }
            }
        });

        this.relatedDocumentsButton = Ext.create('Ext.Button', {
            text: 'RELATED DOCUMENTS',
            width: '30%',
            height: '100%',
            style: 'opacity:0.8',
            listeners: {
                tap: function (button) {
                    that.loadRelatedDocs();
                    that.relatedDocumentsButtonTapped(button);
                }
            }
        });

        this.slideNotesButton = Ext.create('Ext.Button', {
            text: 'SLIDE NOTES',
            width: '30%',
            height: '100%',
            style: 'opacity:0.8',
            listeners: {
                tap: function (button) {
                    that.slideNotesButtonTapped(button);
                }
            }
        });

        this.closeButton = Ext.create('Ext.Button', {
            text: 'X',
            width: '10%',
            height: '100%',
            style: 'opacity:0.8;z-index:999;zoom:1;position:absolute',
            listeners: {
                tap: function () {
                    that.menuCloseButtonTapped();
                }
            }
        });

        this.menuNavView = Ext.create('Ext.NavigationView', {
            width: '100%',
            height: '90%',
            cls: 'menuNavView',
            navigationBar: {
                hidden: true
            }
        });

        //Menu Tab Details go here
        this.menuDetailsContainer = Ext.create('Ext.Container', {
            width: '100%',
            height: '100%',
            layout: 'hbox',
            cls: 'menuDetailsContainer',
            items: [
            ]
        });
        this.menuDetailsLeftContainer = Ext.create('Ext.Container', {
            width: '30%',
            height: '100%',
            layout: 'vbox',
            cls: 'menuDetailsLeftContainer',
            items: [
            ]
        });
        this.menuDetailsMediaButton = Ext.create('Ext.Container', {
            layout: 'hbox',
            items: [
                {
                    xtype: 'container',
                    style: 'background:url(resources/images/media.png) no-repeat center center; background-size:contain;',
                    height: 50,
                    width: 50
                },
                {
                    xtype: 'button',
                    text: 'Media',
                    width: '60%',
                    listeners: {
                        tap: function () {
                            that.playBackVideo();
                        }
                    }
                }
            ]
        });
        this.menuDetailsPrintButton = Ext.create('Ext.Container', {
            layout: 'hbox'
        });

        this.printContainer = Ext.create('Ext.Container', {
            style: 'background:url(resources/images/share.png) no-repeat center center; background-size:contain;',
            height: 55,
            width: 50
        });

        this.printButton = Ext.create('Ext.Button', {
            text: 'Share',
            width: '60%',
            listeners: {
                tap: function () {
                    that.printPdf();
                }
            }
        });

        this.menuDetailsPrintButton.add([this.printContainer, this.printButton]);


        this.menuDetailsResetButton = Ext.create('Ext.Container', {
            layout: 'hbox',
            items: [
                {
                    xtype: 'container',
                    style: 'background:url(resources/images/reset.png) no-repeat center center; background-size:contain;',
                    height: 50,
                    width: 50
                },
                {
                    xtype: 'button',
                    text: 'Reset',
                    width: '60%',
                    listeners: {
                        tap: function () {
                            that.resetButtonTapped();
                        }
                    }
                }
            ]
        });
        this.menuDetailsPlayVideoButton = Ext.create('Ext.Container', {
            layout: 'hbox',
            items: [
                {
                    xtype: 'container',
                    style: 'background:url(resources/images/video.png) no-repeat center center; background-size:contain;',
                    height: 50,
                    width: 50
                },
                {
                    xtype: 'button',
                    text: 'Play Opening Video',
                    width: '61%',
                    listeners: {
                        tap: function () {
                            that.playBackVideo();
                        }
                    }
                }
            ]
        });
        this.menuDetailsLeftContainer.add([this.menuDetailsMediaButton, this.menuDetailsPrintButton, this.menuDetailsResetButton, this.menuDetailsPlayVideoButton]);

        this.menuDetailsRightContainer = Ext.create('Ext.Container', {
            width: '60%',
            height: '100%',
            layout: 'vbox',
            cls: 'menuDetailsRightContainer',
            items: [
                {
                    html: 'PERSONAL SETTINGS',
                    style: 'padding:20px 0 20px 60px;color:#AFAFAE'
                }
            ]
        });
        this.formPanelPersonalSettings = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['PersonalSettings', 'formDefaults'],
            height: '100%',
            width: '100%',
            scrollable: false,
            padding: '0 10',
            items: [
                {
                    xtype: 'textfield',
                    label: 'Rep Name',
                    name: 'repName',
                    labelWidth: '180px',
                    margin: '10 0 0 0',
                    cls: 'repName',
                    placeHolder: 'First and Last Name',
                    listeners: {
                        blur: function () {
                            //  that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Phone Number',
                    name: 'phoneNumber',
                    labelWidth: '180px',
                    margin: '10 0 0 0',
                    cls: 'phoneNumber',
                    placeHolder: '(xxx)xxx-xxxx',
                    listeners: {
                        blur: function () {
                            //  that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Email',
                    name: 'email',
                    labelWidth: '180px',
                    margin: '10 0 0 0',
                    cls: 'email',
                    placeHolder: 'example@mail.com',
                    listeners: {
                        blur: function () {
                            //  that.checkIsNaN(this);
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: 'Save Changes',
                    margin: '40 0 0 0',
                    cls: 'saveButton',
                    listeners: {
                        tap: function () {
                            that.savePersonalSettings(this);
                        }
                    }
                }
            ]
        });

        var settingsStore = Ext.getStore('personaldetails');
        settingsStore.load();
        this.formPanelPersonalSettings.setRecord(settingsStore.getAt(0));
        this.add(this.formPanelPersonalSettings);
        this.menuDetailsRightContainer.add(this.formPanelPersonalSettings);
        this.menuDetailsContainer.add([this.menuDetailsLeftContainer, this.menuDetailsRightContainer]);

        this.relatedDocumentsContainer = Ext.create('Ext.Container', {
            width: '100%',
            height: '100%',
            scrollable:true
        });

//        var store = Ext.create('RestorationRoboticsArtasCalculator.store.Assets');


//        this.relatedDocumentsPanel.add(this.relatedDocumentsList);
//        this.relatedDocumentsContainer.add(this.relatedDocumentsPanel);

        //Slide Notes Tab Details goes here
        this.slideNotesContainer = Ext.create('Ext.Container', {
            width: '100%',
            height: '100%',
            cls: 'slideNotesContainer',
            scrollable: true,
            items: [
                {
                    html: '<table width="100%" border="0" cellspacing="0" cellpadding="0" class = "slidesnotesContent"> \
                        <tr>\
                            <td >\
                                <h5>1. - Are you interested in building your practice with a new procedure?</h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>2. - Did you practice grow last year? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>3. - Is it growing this year? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>4. - By how much </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>5. - How did you grow your practice? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>6. - Why is it important to grow your practice? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>7. - How much do you want to grow your practice? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>8. - How much did you send on marketing and promoting your practice or specific procedures? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>9. - Why are you interested in building your practice with a new procedure? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>10. - Why are you interested in ARTAS? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>11. - What have you heard about the ARTAS and the Hair Restoration? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>12. - Why are you interested in hair restoration? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>13. - What do you think is the biggest challenge in starting this procedure in your practice?  </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>14. - What was the last piece of equipment you bought for your practice </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>15. - How much did it cost?  </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>16. - Did this procedure meet your objectives</h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>17. - What was the last new procedure you introduced in your practice </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>18. - What is the procedure price</h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>19. - How many do you perform today per week/month </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>20. - Do you know how big the market is for hair restoration? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>21. - Do you know how many bald me are in your country?</h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>22. - Do you know if the market is growing in your market? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>23. - How many patients do you have in your database? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>24. - If you perform hair restoration today how many patients do your treat a week/month </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>25. - How much do you charge per FUE or Strip per procedure? </h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>26. - Do you have technicians that have been trained to assist in a hair procedure</h5>\
                            </td>\
                        </tr>\
                        <tr>\
                            <td >\
                                <h5>27. - If yes how many? </h5>\
                            </td>\
                        </tr>\
                    </table>'
                }
            ]
        });

        this.buttonContainer.add([this.menuButton, this.relatedDocumentsButton, this.slideNotesButton, this.closeButton]);
        this.menuNavView.push([this.menuDetailsContainer, this.relatedDocumentsContainer, this.slideNotesContainer]);
        this.menuNavView.setActiveItem(0);
        this.add([this.buttonContainer, this.menuNavView]);

    },
    disablePrintButton: function (disable) {
        this.printButton.setDisabled(disable);
    },
    getItemInfo: function (itemId) {
        var success = false;
        var title = null;
        var fileType = null;
        var iconImageName = null;
        var itemDescription = '';
        var indexArray = [];
        macs.getRequiredAssetDetails(
            itemId,
            ['itemTypeId', 'title', 'fileType', 'iconImageName', 'itemDescription'],
            function (data) {
                if (data) {
                    var itemTypeId = parseInt(data.itemTypeId);
                    fileType = data.fileType;
                    if (itemTypeId === 3 || fileType === 'zip') {
                        success = false;
                    } else {
                        success = true;
                        title = data.title;
                        fileType = data.fileType;

                        if (data.itemDescription) {
                            itemDescription = data.itemDescription;
                        }

                        if (data.iconImageName && data.iconImageName !== 'Not available') {
                            iconImageName = data.iconImageName;
                        }
                    }

                } else {
                    success = false;
                }
            },
            function () {
                success = false;
            }
        );

        indexArray.isNotFolder = success;
        indexArray.title = title;
        indexArray.fileType = fileType;
        indexArray.iconImageName = iconImageName;
        indexArray.itemDescription = itemDescription;

        return indexArray;
    },
    getIconImagePath: function (iconName, fileType) {
        var iconImagePath = null;
        var itemTypes = fileTypes.initItemTypes();
        if (iconName !== null) {
            var fullPath = window.location.pathname;
            var pathComponentsArray = fullPath.split('/');
            var removedString = pathComponentsArray[pathComponentsArray.length - 2] + '/' + pathComponentsArray[pathComponentsArray.length - 1];
            var documentPath = fullPath.replace(removedString, '');
            iconImagePath = documentPath.concat(iconName + '.png');
        }
        else {
            iconImagePath = 'resources/images/fileTypes/' + itemTypes[fileType] + '_default_thumbnail.png';
        }

        return iconImagePath;
    },
    truncateTitle: function (title, length) {
        if (title.length > length) {
            title = title.substring(0, length) + '...';
        }
        return title;
    },
    openItem: function (itemId) {

        macs.viewAsset(itemId.toString(),
            function () {

            }
        );
    },
    loadRelatedDocs: function () {
        var that = this;
        if (that.relatedDocumentsContainer.getItems().length == 0) {
            macs.getFolderAssets(
                '17168', //Production Id - 17168 , Staging ID - 17163
                function (data) {
                    var children = [];
                    var chidrenCount = 0;
                    for (var index = 0; index < data.children.length; index++) {
                        var itemId = data.children[index];
                        var resultArray = that.getItemInfo(itemId);
                        children.push([]);

                        if (resultArray.isNotFolder) {
                            var imagePath = that.getIconImagePath(resultArray.iconImageName, resultArray.fileType);
                            children[chidrenCount].itemId = itemId;
                            children[chidrenCount].imagePath = imagePath;
                            children[chidrenCount].title = that.truncateTitle(resultArray.title, 20);
                            children[chidrenCount].description = resultArray.itemDescription;
                            chidrenCount++;
                        }
                    }

                    var store = Ext.data.StoreManager.lookup('Assets');
                    var buttons = [];
                    var itemIds = [];
                    store.setData(children);
                    console.log(store);

                    Ext.each(store.data.items, function (item, i) {
                            itemIds[i] = item.data.itemId;
                            buttons[i] = Ext.create('Ext.Button', {
                                html: item.data.title,
                                cls:'relatedDocumentsIcon',
                                style: 'background : url(' + item.data.imagePath + ') no-repeat',
                                listeners: {
                                    initialize:function(){
                                        if((i+1)%3===0){
                                            this.addCls('noRightBorder');
                                        }
                                    },
                                    tap: function () {
                                        that.openItem(itemIds[i]);
                                    }
                                }
                                
                            });
                            that.relatedDocumentsContainer.add(buttons[i]);
                        }
                    );

                }
            );
        }
    }

});
