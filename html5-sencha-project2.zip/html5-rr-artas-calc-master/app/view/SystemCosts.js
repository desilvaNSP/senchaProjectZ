Ext.define('RestorationRoboticsArtasCalculator.view.SystemCosts', {
    extend: 'RestorationRoboticsArtasCalculator.view.BaseView',
    xtype: 'systemcosts',
    requires: [
        'RestorationRoboticsArtasCalculator.form.Panel'
    ],
    config: {
        cls: 'systemcosts'
    },
    calculateSystemCost: function (formPanel, formPanelOtherCost) {
        this.fireEvent('calculateSystemCost', formPanel, formPanelOtherCost);
    },
    initialize: function () {

        var that = this;
        this.formPanel = Ext.create('Ext.form.Panel', {
            cls: ['systemCostsForm', 'formDefaults'],
            height: '525px',
            width: '50%',
            scrollable: false,
            items: [
                {
                    html: 'System Costs',
                    cls: 'formHeader'
                },
                {
                    xtype: 'textfield',
                    label: 'System Price',
                    name: 'systemPrice',
                    labelWidth: '200px',
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Tax',
                    name: 'tax',
                    labelWidth: '200px',
                    placeHolder: 'Enter %',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Shipping',
                    name: 'shipping',
                    labelWidth: '200px',
                    placeHolder: 'Enter number',
                    listeners: {
                        painted: function () {
                            this.fireEvent('change');
                        },
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);

                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Total Investment',
                    name: 'totalInvestment',
                    cls: 'totalInvestment',
                    labelWidth: '200px',
                    readOnly: true
                }
            ]
        });
        this.formPanelOtherCost = Ext.create('Ext.form.Panel', {
            cls: ['formPanelOtherCost', 'formDefaults'],
            height: '525px',
            width: '50%',
            fieldValues: [0],
            scrollable: false,
            items: [
                {
                    html: 'Options',
                    cls: 'formHeader'
                },
                {
                    xtype: 'textfield',
                    label: 'ARTAS System',
                    name: 'machine',
                    placeHolder: 'Enter number',
                    clearIcon: false,
                    labelWidth: '250px',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'machineCheckField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    disabled : true,
                    cls: 'roundedCheckButtonInactive',
                    listeners: {
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'New Hair Acc. Training',
                    name: 'trainingA',

                    labelWidth: '250px',
                     clearIcon: false,
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'trainingAField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    cls: 'roundedCheckButtonInactive',
                    listeners: {
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'EXP’D Hair Acc. Training',
                    name: 'trainingB',

                    labelWidth: '250px',
                    placeHolder: 'Enter number',
                     clearIcon: false,
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'trainingBField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    cls: 'roundedCheckButtonInactive',
                    listeners: {

                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Procedure Package',
                    name: 'procedurePackage',

                    labelWidth: '250px',
                    clearIcon: false,
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);

                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'procedurePackageCheckField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    cls: 'roundedCheckButtonInactive',
                    listeners: {
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Practice Development Fund ',
                    name: 'practiceDev',
                    labelWidth: '250px',
                     clearIcon: false,
                    placeHolder: 'Enter number',
                    listeners: {
                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'practiceDevpmtFndCheckField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    cls: 'roundedCheckButtonInactive',
                    listeners: {
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Ext. 1 year Service Contract',
                    name: 'services',
                    labelWidth: '250px',
                     clearIcon: false,
                    placeHolder: 'Enter number',
                    listeners: {

                        blur: function () {
                            this.suspendEvents(false);
                            that.fieldBlur(this);
                            this.resumeEvents(true);
                            this.fireEvent('change');
                        },
                        focus: function () {
                            that.fieldFocus(this);
                        },
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    name: 'extndSrvceCntrctCheckField',
                    alias: 'widget.optionsCheckboxField',
                    labelWidth: '0px',
                    cls: 'roundedCheckButtonInactive',
                    listeners: {
                        change: function () {
                            that.calculateSystemCost(that.formPanel, that.formPanelOtherCost);
                        },
                        painted: function () {
                            if (this.getChecked()) {
                                this.addCls('roundedCheckButtonActive');
                            } else {
                                this.addCls('roundedCheckButtonInactive');
                            }
                        },
                        check: function () {
                            this.addCls('roundedCheckButtonActive');
                            this.removeCls('roundedCheckButtonInactive');
                        },
                        uncheck: function () {
                            this.removeCls('roundedCheckButtonActive');
                            this.addCls('roundedCheckButtonInactive');
                        }
                    }
                }
            ]
        });


     //   this.formPanelOtherCost.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost'));
        this.formPanel.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost'));
        this.formPanelWrapper = Ext.create('Ext.Container', {
            width: '100%',
            margin: '100 0 0 0',
            layout: {
                type: 'hbox',
                align: 'start',
                pack: 'strat'
            }
        });
        this.formPanelWrapper.add([this.formPanel, this.formPanelOtherCost]);
        this.add(this.formPanelWrapper);
    },


    reset: function () {
        this.formPanel.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost'));
        this.formPanelOtherCost.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost'));
        this.formPanelOtherCost.innerItems[2].uncheck();
        this.formPanelOtherCost.innerItems[4].uncheck();
        this.formPanelOtherCost.innerItems[6].uncheck();
        this.formPanelOtherCost.innerItems[8].uncheck();
        this.formPanelOtherCost.innerItems[10].uncheck();
        this.formPanelOtherCost.innerItems[12].uncheck();
    },
    updateValues : function(){
         this.formPanelOtherCost.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost'));

    }

});
