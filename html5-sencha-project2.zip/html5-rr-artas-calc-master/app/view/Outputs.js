Ext.define('RestorationRoboticsArtasCalculator.view.Outputs', {
    extend: 'Ext.Container',
    xtype: 'outputs',
    requires: [
    ],
    config: {
        padding: '100 0 0 0',
        cls: 'outputs'
    },
    initialize: function() {
        this.initDetailReport();
    },
    loadRevenueReport: function() {
        this.fireEvent('loadRevenueReport');
    },
    initDetailReport: function() {
        this.detailedReportContainer = Ext.create('Ext.Container', {
            height: '100%',
            width: '95%',
            scrollable: false,
            margin: '0 auto',
            cls:'detailedReportContainer'
        });

        this.outputHeaders = Ext.create('Ext.Container', {
            cls: ['outputsForm', 'formDefaults'],
            layout: 'vbox',
            items: [
                {
                    html: 'Report',
                    cls: ['formHeader','detailedReportHeader'],
                    style: 'padding-left:0px;text-transform:capitalize;color:#5E5F5E;'
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    height: '60px',
                    style: 'color:#999',
                    items: [
                        {
                            xtype: 'label',
                            html: '',
                            width: '20%'
                        },
                        {
                            xtype: 'label',
                            html: 'Applications',
                            width: '20%',
                            style: 'text-align:center'
                        },
                        {
                            xtype: 'label',
                            html: 'Revenue',
                            width: '20%',
                            style: 'text-align:center'
                        },
                        {
                            xtype: 'label',
                            html: 'Direct Costs',
                            width: '20%',
                            style: 'text-align:center'
                        },
                        {
                            xtype: 'label',
                            html: 'Net Income',
                            width: '20%',
                            style: 'text-align:center'
                        }
                    ]
                }
            ]
        });

        this.month0to3Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '60px',
            style: 'border-bottom:1px solid #808285; border-top:1px solid #999; padding-top:10px',
            items: [
                {
                    xtype: 'label',
                    html: 'Month 0-3',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'month0to3Applications',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month0to3Revenue',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month0to3DirectCosts',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month0to3NetIncome',
                    width: '20%',
                    readOnly: true
                }
            ]
        });
        this.month4to6Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '60px',
            style: 'border-bottom:1px solid #808285; padding-top:10px',
            items: [
                {
                    xtype: 'label',
                    html: 'Month 4-6',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'month4to6Applications',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month4to6Revenue',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month4to6DirectCosts',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month4to6NetIncome',
                    width: '20%',
                    readOnly: true
                }
            ]
        });
        this.month7to9Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '60px',
            style: 'border-bottom:1px solid #808285; padding-top:10px',
            items: [
                {
                    xtype: 'label',
                    html: 'Month 7-9',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'month7to9Applications',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month7to9Revenue',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month7to9DirectCosts',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month7to9NetIncome',
                    width: '20%',
                    readOnly: true
                }
            ]
        });
        this.month10to12Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '60px',
            style: 'border-bottom:1px solid #999; padding-top:10px',
            items: [
                {
                    xtype: 'label',
                    html: 'Month 10-12',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'month10to12Applications',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month10to12Revenue',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month10to12DirectCosts',
                    width: '20%',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'month10to12NetIncome',
                    width: '20%',
                    readOnly: true
                }
            ]
        });
        this.year1Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '40px',
            cls: 'yearOneRaw',
            items: [
                {
                    xtype: 'label',
                    html: 'Year 1',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'year1Applications',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year1Revenue',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year1DirectCosts',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year1NetIncome',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                }
            ]
        });
        this.year2Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '40px',
            cls: 'yearTwoRaw',
            items: [
                {
                    xtype: 'label',
                    html: 'Year 2',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'year2Applications',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year2Revenue',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year2DirectCosts',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year2NetIncome',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                }
            ]
        });
        this.year3Raw = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '42px',
            cls: 'yearThreeRaw',
            items: [
                {
                    xtype: 'label',
                    html: 'Year 3',
                    width: '20%'
                },
                {
                    xtype: 'textfield',
                    name: 'year3Applications',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year3Revenue',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year3DirectCosts',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    name: 'year3NetIncome',
                    width: '18%',
                    margin: '0 2% 0 0',
                    readOnly: true
                }
            ]
        });
        this.revenueGraphContainer = Ext.create('Ext.Container', {
            height: '100%',
            width: '95%',
            scrollable: false,
            margin: '0 auto',
            cls:'revenueGraphContainer',
            items: [
                {
                    html: '<h2>Report</h2>',
                    cls: ['formHeader','revenueGraphHeader'],
                    style: 'padding-left:0px;text-transform:capitalize;color:#5E5F5E;'
                },
                {
                    xtype:'container',
                    layout:'hbox',
                    margin:'10 0',
                    items:[
                        {html:'BREAK EVEN POINT', width:'320px'},
                        {xtype:'spacer'},
                        {html:'REVENUE', width:'320px'},
                        {xtype:'spacer'},
                        {html:'FIXED COSTS', width:'320px'}
                    ]
                }
            ]
        });
        this.revenueGraphWrapper = Ext.create('Ext.Container', {
            layout: 'hbox',
            cls:'revenueGraphWrapper'
        });

        this.barChart = Ext.create('Ext.Container', {
            //height: '100%',
            width: '320px',
            cls:'barChartWrapper',
            items: [
                {
                    html: '<div style="width:100%"><div><canvas id="canvasBEP" height="300px" width="300px"></canvas></div></div>',
                    cls: 'formHeader'
                }
            ]

        });
        this.lineChart = Ext.create('Ext.Container', {
           
            width: '320px',
            cls:'lineChartWrapper',
            items: [
                {
                    html: '<div style="width:100%"><div><canvas id="canvasRevenue" height="300px" width="300px"></canvas></div></div>',
                    cls: 'formHeader'
                }
            ]
        });
        this.fixedCost = Ext.create('Ext.Container', {
            //height: '100%',
            width: '320px',
            cls:'fixedCostWrapper',
            items: [
                {
                    html: '',
                    cls: 'fixedCostHeader'
                },
                {
                    xtype:'container',
                    cls: 'fixedCostMiddleLine'
                },
                {
                    html: 'year',
                    cls: 'fixedCostValue'
                }
            ]
        });

        this.yearContainer = Ext.create('Ext.Container', {
            cls: 'yearContainer'
        });

        this.yearContainer.add([this.year1Raw, this.year2Raw, this.year3Raw]);

        this.revenueGraphWrapper.add([this.barChart,{xtype:'spacer'}, this.lineChart,{xtype:'spacer'}, this.fixedCost]);
        this.revenueGraphContainer.add(this.revenueGraphWrapper);

        this.detailedReportContainer.add([this.outputHeaders, this.month0to3Raw, this.month4to6Raw, this.month7to9Raw,
            this.month10to12Raw, this.yearContainer]);
        
        //this.extraContainer = Ext.create('Ext.Container',{id:'extraContainer',cls:'extraContainer',width:400,height:400});
        
//        this.add([this.extraContainer,this.detailedReportContainer, this.revenueGraphContainer]);
        
        this.add([this.detailedReportContainer, this.revenueGraphContainer]);
        this.revenueGraphContainer.hide();
    },
    switchToHeadlineReport: function() {
        this.detailedReportContainer.hide();
        this.revenueGraphContainer.show();
    },
    switchToDetailReport: function() {
        this.detailedReportContainer.show();
        this.revenueGraphContainer.hide();
    },
    lineChartGenaration: function(zero, month0to3, month4to6, month7to9, month10to12) {
        var lineChartData = {
            labels: [" ", " ", " ", " ", " ", " "],
            datasets: [
                {
                    strokeColor: "rgba(220,220,220,1)",
                    pointColor: "rgba(65, 173, 72,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: [zero, month0to3, month4to6, month7to9, month10to12]
                }
            ]

        };
        var canvasRev = document.getElementById("canvasRevenue");
        var ctxRevenue = canvasRev.getContext("2d");
        new Chart(ctxRevenue).Line(lineChartData, {
            bezierCurve: false,
            responsive: true,
            scaleShowGridLines: false,
            scaleShowValues: true,
            scaleValuePaddingX: 13,
            scaleValuePaddingY: -5,
            scaleShowLabels: false,
            scaleLineWidth: null,
            datasetFill: false,
            datasetStroke: false,
            scaleFontStyle: "bold",
            scaleFontSize: 14,
            showScale: false
        });
    },
    barChartGeneration: function(data1, data2, data3, data4) {
        var barChartData = {
            labels: [" ", " ", " ", " "],
            datasets: [
                {
                    fillColor: "rgba(154,155,157,0.5)",
                    strokeColor: "rgba(220,220,220,0.8)",
                    highlightFill: "rgba(220,220,220,0.75)",
                    highlightStroke: "rgba(220,220,220,1)",
                    data: [
                        data1,
                        data2,
                        data3,
                        data4
                    ]
                }
            ]

        };

        var canvas = document.getElementById("canvasBEP");
        var ctxBEP = canvas.getContext("2d");
        new Chart(ctxBEP).Bar(barChartData, {
            responsive: true,
            scaleShowGridLines: false,
            scaleShowValues: true,
            scaleValuePaddingX: 250,
            scaleValuePaddingY: 13,
            scaleShowLabels: false,
            scaleLineWidth: null,
            scaleFontStyle: "bold",
            scaleFontSize: 14,
            showScale: false,
            xAxisBottom: true,
            xAxisTop: false

        });

    }
});
