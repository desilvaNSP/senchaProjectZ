Ext.define('RestorationRoboticsArtasCalculator.view.NavBar', {
    extend: 'Ext.Container',
    xtype: 'navbar',
    requires: [
    ],
    config: {
        height: '100',
        zIndex : 40,
        width: '100%',
        top: '0%'
    },
    nextNavigate: function () {
        this.fireEvent('nextNavigation', this);
    },
    backNavigate: function () {
        this.fireEvent('backNavigation', this);
    },
    initialize: function () {
        var that = this;
        this.nextButton = Ext.create('Ext.Button', {
            text: 'Next',
            padding: '10 20',
            margin: '25 20 0 0',
            height: '40px',
            listeners: {
                tap: function () {
                    that.nextNavigate();
                }
            }
        });
        this.backButton = Ext.create('Ext.Button', {
            text: 'Back',
            padding: '10 20',
            margin: '25 0 0 20',
            height: '40px',
            listeners: {
                tap: function () {
                    that.backNavigate();
                }
            }
        });
        this.logoImage = Ext.create('Ext.Img', {
            src: 'resources/images/artasLogoWhite.png',
            height: 90,
            width: 258
        });
        this.footerNavBar = Ext.create('Ext.Container', {
            layout: 'hbox',
            items: [
                {
                    items: [this.backButton]
                },
                {
                    xtype: 'spacer'
                },
                {
                    items: [this.nextButton]
                }
            ]
        });
        this.add([this.footerNavBar]);
    }
});
