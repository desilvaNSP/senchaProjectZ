Ext.define('RestorationRoboticsArtasCalculator.view.PracticeInformation', {
    extend: 'RestorationRoboticsArtasCalculator.view.BaseView',
    xtype: 'practiceinformation',
    requires: [
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.field.Select',
        'RestorationRoboticsArtasCalculator.form.Panel'
    ], config: {
        padding: '100 0 0 0',
        cls: 'practiceinformation',
        items: [
            {
                html: 'Practice Information',
                cls: 'formHeader',
                style: 'color:#fff;'
            }
        ]
    },
    currency: '',
    resetChangeCurrency: function (booleanVal, formPanel, options) {
        this.fireEvent('resetChangeCurrency', booleanVal, formPanel, options);
    },
    updatedefaults: function (currencyType) {
        this.fireEvent('updatedefaults', currencyType);
    },
    initialize: function () {
        var that = this;
        var optionsSet = [
            {text: 'Euros', value: '€'},
            {text: 'Dollars', value: '$'},
            {text: 'Pound', value: '£'},
            {text: 'Peso', value: '₱'},
            {text: 'Yen', value: '¥'},
            {text: 'Korean Won', value: '₩'},
            {text: 'Taiwan Dollar', value: ' $'},
            {text: 'Mexican Peso', value: '  $'}
        ];
        this.countriesStore = Ext.create('RestorationRoboticsArtasCalculator.store.Countries');
        this.countriesStore.load();
        this.formPanel = Ext.create('RestorationRoboticsArtasCalculator.form.Panel', {
            cls: ['practiceInformationForm', 'formDefaults'],
            height: '100%',
            width: '65%',
            scrollable: false,
            items: [
                {
                    xtype: 'selectfield',
                    label: 'Currency',
                    name: 'currencyExchange',
                    labelWidth: '250px',
                    cls: 'currencyExchageField',
                    placeHolder: 'Select',
                    value: 'none',
                    autoSelect: null,
                    required: true,
//                    usePicker: true,
                    defaultTabletPickerConfig: {
                        height: 200,
                        minHeight: 200
                    },
                    listeners: {
                        initialize: function () {
                            this.setOptions(optionsSet);

                        },
                        painted: function () {
                        },
                        change: function (field, newValue, oldValue) {
                            var currencyField = this;

                            that.updatedefaults(field.getRecord().data.text);
                            if (oldValue !== null && that.currency !== newValue) {
                                Ext.Msg.confirm("Change Currency", "Changing currency will reset the calculator. Do you wish to continue? ", function (value) {
                                    if (value === "yes") {
                                        that.currency = newValue;
                                        that.resetChangeCurrency(false, that.formPanel, optionsSet);


                                    }
                                    else {
                                        currencyField.setValue(that.currency);
                                    }
                                });
                            }
                            else if (oldValue === null) {
                                that.currency = newValue;
                            }
                        }

                    }

                },
                {
                    xtype: 'textfield',
                    label: 'Physician Name',
                    name: 'physician',
                    placeHolder: 'Enter name',
                    labelWidth: '250px',
                    required: true
                },
                {
                    xtype: 'textfield',
                    label: 'Address 1',
                    placeHolder: 'Enter address',
                    name: 'addressOne',
                    labelWidth: '250px',
                    required: true
                },
                {
                    xtype: 'textfield',
                    label: 'Address 2',
                    placeHolder: 'Enter address',
                    name: 'addressTwo',
                    labelWidth: '250px'
                },
                {
                    xtype: 'textfield',
                    label: 'City',
                    name: 'city',
                    placeHolder: 'Enter city',
                    cls: 'cityField',
                    labelWidth: '250px',
                    width: '68%'
                },
                {
                    xtype: 'textfield',
                    name: 'zip',
                    label: 'Postal/</br>Zip Code',
                    placeHolder: 'Enter zip',
                    cls: 'zipField',
                    labelWidth: '120px'
                },
                {
                    xtype: 'selectfield',
                    name: 'country',
                    label: 'Country',
                    cls: 'countryField',
                    labelWidth: '250px',
                    store: this.countriesStore,
                    displayField: 'name',
                    valueField: 'name',
                    placeHolder: 'Select',
                    autoSelect: null,
                    required: true,
                    defaultTabletPickerConfig: {
                        height: 200,
                        minHeight: 200
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'State/Province/Region',
                    name: 'region',
                    placeHolder: 'Enter region',
                    labelWidth: '250px'
                }
            ]

        });


        this.overlayContainer = Ext.create('Ext.Panel', {
            modal: true,
            hideOnMaskTap: true,
            type: 'hbox',
            config: {
                alignment: 'ct-cc?'
            },
            hidden: true,
            layout: 'fit',
            height: '200px',
            style: 'background-color:#fff;',
            zIndex: 500,
            centered: true,
            styleHtmlContent: true,
            items: [
                {
                    xtype: 'list',
                    height: '200px',
                    width: '200px',
                    mode: 'SINGLE',
                    store: this.countriesStore,
                    scrollable: {
                        initialOffset: {
                            x: 0,
                            y: 60
                        }
                    },
                    items: [
                        {
                            xtype: 'toolbar',
                            docked: 'top',
                            items: [
                                {
                                    xtype: 'searchfield',
                                    scrollDock: 'top',
                                    padding: '5px',
                                    placeHolder: 'Search...',
                                    listeners: {
                                        keyup: function () {
                                            var store = that.countriesStore;
                                            store.clearFilter();
                                            store.filter('name', this.getValue());
                                        },
                                        change: function () {
                                            var store = that.countriesStore;
                                            store.clearFilter();
                                        }
                                    }
                                }
                            ]
                        }
                    ],
                    itemTpl: '{name}',
                    listeners: {
                        select: function (field, record) {
                            that.formPanel.down('field[name=country]').setValue(record.get('name'));
                            that.overlayContainer.hide();
                        }
                    }
                }
            ]

        });
        this.formPanel.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.PracticeInformation'));
        this.add(this.formPanel);
    },
    reset: function () {
        this.formPanel.setRecord(Ext.create('RestorationRoboticsArtasCalculator.model.PracticeInformation'));
        this.formPanel.down('field[name=country]').getStore().removeAll();
        this.countriesStore = Ext.create('RestorationRoboticsArtasCalculator.store.Countries');
        this.countriesStore.load();
        this.formPanel.down('field[name=country]').setStore(this.countriesStore);

    }
});
