Ext.define('RestorationRoboticsArtasCalculator.controller.Menu', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    sessionData: '',
    config: {
        refs: {
            menuview: 'menuview',
            main: 'main',
            practiceinformation: 'practiceinformation',
            opportunities: 'opportunities',
            systemcosts: 'systemcosts',
            financingoptions: 'financingoptions'
        }
    },
    menuButtonTapped: function (button) {
        this.getMenuview().menuNavView.animateActiveItem(0, {type: 'fade'});

    },
    relatedDocumentsButtonTapped: function (button) {
        this.getMenuview().menuNavView.animateActiveItem(1, {type: 'fade'});
    },
    slideNotesButtonTapped: function (button) {
        this.getMenuview().menuNavView.animateActiveItem(2, {type: 'fade'});
    },
    menuCloseButtonTapped: function () {
        this.getMenuview().hide();
    },
    onItemTap: function (view, index, target, record, event) {
    },
    printPdf: function () {
        var settingsStore = Ext.getStore('personaldetails');
        settingsStore.load();
        var personalSettingsDetail = settingsStore.getAt(0);

        var facilityName = '', addressOne = '', addressTwo = '', city = '', postalCode = '', state = '', repName = '', repPhoneNo = '', repEmail = '',
            casesPerWeek = '', systemPrice = '', artasHACost = '', tax = '', otherCosts = '', shipping = '', pricePerApplication = '', totalInvestment = '',
            buy = '', oneTimePayment = '', patientPricePerHarvest = '', costPaidPerHarvest = '', averageHarvests = '', harvestYieldPercentage = '',
            pdfContent = '';

        facilityName = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('physician'),
            addressOne = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('addressOne'),
            addressTwo = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('addressTwo'),
            city = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('city'),
            postalCode = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('zip'),
            state = this.getApplication().getController('Calculate').sessionData.practiceInformation.get('region'),
            repName = personalSettingsDetail.get('repName'),
            repPhoneNo = personalSettingsDetail.get('phoneNumber'),
            repEmail = personalSettingsDetail.get('email'),
            casesPerWeek = '?',
            systemPrice = this.getApplication().getController('Calculate').sessionData.systemCost.get('systemPrice'),
            artasHACost = this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('artasHACost'),
            tax = this.getApplication().getController('Calculate').sessionData.systemCost.get('tax'),
            otherCosts = this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('otherCostAmount'),
            shipping = this.getApplication().getController('Calculate').sessionData.systemCost.get('shipping'),
            pricePerApplication = this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('pricePerApplication'),
            totalInvestment = this.getApplication().getController('Calculate').sessionData.systemCost.get('totalInvestment'),
            buy = this.getApplication().getController('Calculate').sessionData.financingOption.get('oneTimePayment'),
            oneTimePayment = this.getApplication().getController('Calculate').sessionData.financingOption.get('oneTimePayment'),
            patientPricePerHarvest = this.getApplication().getController('Calculate').sessionData.harvestPayment.get('patientPricePerHarvest'),
            costPaidPerHarvest = this.getApplication().getController('Calculate').sessionData.harvestPayment.get('costPaidPerHarvest'),
            averageHarvests = this.getApplication().getController('Calculate').sessionData.harvestPayment.get('averageHarvestsPerProcedure')


        if (repName == null) {
            repName = '';
        }
        if (repPhoneNo == null) {
            repPhoneNo = '';
        }
        if (repEmail == null) {
            repEmail = '';
        }

        var header = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="pdfHeader">\
                            <tr><td>\
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">\
                                        <tr><td><img src="resources/images/logoPdf.png" width="258"></td></tr>\
                                    </table>\
                                </td>\
                                <td>\
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="repDetails">\
                                        <tr><td>' + repName + '</td></tr>\
                                        <tr><td>' + repPhoneNo + '</td></tr>\
                                        <tr><td>' + repEmail + '</td></tr>\
                                    </table>\
                                </td>\
                            </tr>\
                        </table>';

        var results = '<table width="100%" border="0" cellspacing="0" cellpadding="0">\
                            <tr><td class="pdfHeading">Results</td></tr>\
                            <tr><td>' + facilityName + '</td></tr>\
                            <tr><td>' + addressOne + '&nbsp;' + addressTwo + '</td></tr>\
                            <tr><td>' + city + '&nbsp;' + state + '&nbsp;' + postalCode + '</td></tr>\
                            <tr><td>&nbsp;</td></tr>\
                            <tr><td>&nbsp;</td></tr>\
                        </table>';
        var resultTable = '\
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="resultTable">\
                        <tr><td>\
                            <table width="100%" border="1" cellspacing="0" cellpadding="0" class="tableOneDetails">\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE">Cases/Week</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + casesPerWeek + '</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">System Price</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + systemPrice + '</td>\
                                </tr>\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE">Artas HA Cost</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + artasHACost + '</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">Tax</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + tax + '</td>\
                                </tr>\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE">Other Costs</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + otherCosts + '</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">Shipping</td> \
                                    <td style="border-bottom:1px solid #AFAFAE">' + shipping + '</td>\
                                </tr>\
                                <tr>\
                                    <td>Price Per Application</td> \
                                    <td>' + pricePerApplication + '</td> \
                                    <td>Total Investment</td> \
                                    <td>' + totalInvestment + '</td>\
                                </tr>\
                            </table>\
                        </td></tr>\
                        <tr><td height="30px"></td></tr>\
                        <tr><td>\
                            <table width="100%" border="0" cellspacing="0" cellpadding="0"  class="tableTwoDetails">\
                                <tr>\
                                    <td  style="border-bottom:1px solid #AFAFAE;"  width="50%" >Buy</td> \
                                    <td style="border-bottom:1px solid #AFAFAE"   width="50%" >' + buy + '</td>\
                                </tr>\
                                <tr>\
                                    <td  width="50%" >One Time Payment</td>\
                                    <td  width="50%" >' + oneTimePayment + '</td>\
                                </tr>\
                            </table></td></tr>\
                        <tr><td height="30px"></td></tr>\
                        <tr><td>\
                            <table width="100%" border="0" cellspacing="0" cellpadding="0"  class="tableThreeDetails">\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >Patient Price Per Harvest</td> \
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >' + patientPricePerHarvest + '</td>\
                                </tr>\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >Cost Paid Per Harvest</td> \
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >' + costPaidPerHarvest + '</td>\
                                </tr>\
                                <tr>\
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >Average Harvests</td> \
                                    <td style="border-bottom:1px solid #AFAFAE"  width="50%" >' + averageHarvests + '</td>\
                                </tr>\
                            </table>\
                        </td></tr>\
                    </table>';


//        var detailedReportContainerContent = Ext.select('.detailedReportContainer').elements[0].innerHTML;
//        var revenueGraphContainerContent = Ext.select('.revenueGraphContainer').elements[0].innerHTML;

        var applications = this.getApplication().getController('Calculate').applications;
        console.log(applications);
        var revenueArray = this.getApplication().getController('Calculate').revenueArray;
        var directCostArray = this.getApplication().getController('Calculate').directCostArray;
        var netInComeArray = this.getApplication().getController('Calculate').netInComeArray;
        var currencySym = this.getApplication().getController('Calculate').sessionData.practiceinformation.getData().currencyExchange;
        var fixedCost = this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.systemCost.getData().totalInvestment);

        var canvas = document.getElementById("canvasBEP");
        var imgCanvasBEP = canvas.toDataURL("image/png");

        var canvas = document.getElementById("canvasRevenue");
        var imgCanvasRevenue = canvas.toDataURL("image/png");

        var detailedReportContainerContent =
            '<table border="0" class="reportDetailsTable" cellspacing="0" cellpadding="0">\
            <tr class="bottomBorder heading">\
                <td></td>\
                <td>Applications</td>\
                <td>Revenue</td>\
                <td>Direct Costs</td>\
                <td>Net Income</td>\
            </tr>\
            <tr class="bottomBorder"><td>Month 0-3</td><td>' + applications.month0to3Applications + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.month0to3Revenue)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.month0to3DirectCosts)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.month0to3NetIncome)))) + '</td></tr>\
                <tr class="bottomBorder"><td>Month 4-6</td><td>' + applications.month4to6Applications + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.month4to6Revenue)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.month4to6DirectCosts)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.month4to6NetIncome)))) + '</td></tr>\
                <tr class="bottomBorder"><td>Month 7-9</td><td>' + applications.month7to9Applications + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.month7to9Revenue)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.month7to9DirectCosts)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.month7to9NetIncome)))) + '</td></tr>\
                <tr class="bottomBorder"><td>Month 10-12</td><td>' + applications.month10to12Applications + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.month10to12Revenue)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.month10to12DirectCosts)))) + '</td><td>' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.month10to12NetIncome)))) + '</td></tr>\
                <tr class="spacingRow"><td colspan="5"></td></tr>\
                <tr>\
                    <td>Year 1</td>\
                    <td><div class="yearOne">' + applications.year1Application + '</div></td>\
                    <td><div class="yearOne">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.year1Revenue)))) + '</div></td>\
                    <td><div class="yearOne">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.year1DirectCosts)))) + '</div></td>\
                    <td><div class="yearOne">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.year1NetIncome)))) + '</div></td>\
                </tr>\
                <tr>\
                    <td>Year 2</td>\
                    <td><div class="yearTwo">' + applications.year2Applications + '</div></td>\
                    <td><div class="yearTwo">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.year2Revenue)))) + '</div></td>\
                    <td><div class="yearTwo">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.year2DirectCosts)))) + '</div></td>\
                    <td><div class="yearTwo">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.year2NetIncome)))) + '</div></td>\
                </tr>\
                <tr>\
                    <td>Year 3</td>\
                    <td><div class="yearThree">' + applications.year3Applications + '</div></td>\
                    <td><div class="yearThree">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(revenueArray.year3Revenue)))) + '</div></td>\
                    <td><div class="yearThree">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(directCostArray.year3DirectCosts)))) + '</div></td>\
                    <td><div class="yearThree">' + this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(netInComeArray.year3NetIncome)))) + '</div></td>\
                </tr>\
        </table>';

        var revenueGraphContainerContent = '<table border="0" class="revenueGraphTable">\
                <tr>\
                    <td width="5" height="20"></td>\
                    <td width="300">BREAK EVEN POINT</td>\
                    <td width="10"></td>\
                    <td width="300">REVENUE</td>\
                    <td width="10"></td>\
                    <td width="300">FIXED COSTS</td>\
                    <td width="5"></td>\
                </tr>\
                <tr>\
                    <td width="5"></td>\
                    <td width="330" height="300"><div class="breakEvenPointBox"><img src="imgCanvasBEP.abc" width="300"></div></td>\
                    <td width="10"></td>\
                    <td width="330" height="300"><div class="revenueBox"><img src="imgCanvasRevenue.abc" width="300"></div></td>\
                    <td width="10"></td>\
                    <td style="vertical-align: top;" width="330" height="300"><div class="fixedCostsBox"><div class="fixedCostHeader">' + currencySym + fixedCost + '</div><div class="fixedCostMiddleLine"></div><div class="fixedCostValue">year</div></div></td>\
                    <td width="5"></td>\
                </tr>\
        </table>';


        var pageOneContentHTML = '<img src="resources/images/logo.png" width="100%">';
        var pageTwoContentHTML = '<div>' + results + '</div><div>' + resultTable + '</div>';
        var pageThreeContentHTML = '<div class="pdfHeading pdfReferences" style="text-transform:capitalize;padding-left:20px">Report</div>\
                                  <div class="detailedReportContainerContent">' + detailedReportContainerContent + '</div>\
                                   <div class="revenueGraphWrapperContent">' + revenueGraphContainerContent + '</div>';

        var pageFourContentHTML = '\
            <table width="100%" border="0" cellspacing="0" cellpadding="0">\
                <tr><td><div class="pdfHeading pdfReferences">Assumptions</div></td></tr>\
                <tr><td>*Model assumes 30 % growth per year.</td></tr>\
            </table>';


        macs.saveFile({"byteStream": "" + imgCanvasBEP.split(",")[1] + "", "fileName": "imgCanvasBEP", "filetype": "abc"}, function (result) {
        });
        macs.saveFile({"byteStream": "" + imgCanvasRevenue.split(",")[1] + "", "fileName": "imgCanvasRevenue", "filetype": "abc"}, function (result) {
        });

//        var containerIma = Ext.select('.extraContainer').elements[0].innerHTML;

        pdfContent =
            '<table class="printTable"><tr><td>' + header + '</td></tr><tr><td class="printTableContent">' + pageOneContentHTML + '</td></tr><tr><td class="printTablePageNumber"></td></tr></table>' +
            '<table class="printTable"><tr><td>' + header + '</td></tr><tr><td class="printTableContent">' + pageTwoContentHTML + '</td></tr><tr><td class="printTablePageNumber"></td></tr></table>' +
            '<table class="printTable headerThree"><tr><td>' + header + '</td></tr><tr><td class="printTableContent outputs">' + pageThreeContentHTML + '</td></tr><tr><td class="printTablePageNumber"></td></tr></table>' +
            '<table class="printTable"><tr><td>' + header + '</td></tr><tr><td class="printTableContent">' + pageFourContentHTML + '</td></tr><tr><td class="printTablePageNumber"></td></tr></table>';

        macs.getPathForConvertedPDFFileFromHTML(
            {"pageContent": "" +
                encodeURI("<!DOCTYPE html>\
                                        <html>\
                                        <head>\
                                            <link rel='stylesheet' href='touch/resources/css/cupertino.css'>\
                                            <link href='resources/css/app.css' rel='stylesheet' type='text/css'>\
                                            <link href='resources/css/print.css' rel='stylesheet' type='text/css'>\
                                            <script src='chartjs/Chart.js'></script>\
                                        </head>\
                                        <body>" + pdfContent + "</body>\
                                    </html>") +
                "", "width": "600", "height": "700"},
            function (result) {
                macs.viewAsset(result.filePath, function (result) {
                });
            });

    },
    onResetButtonTap: function () {
        var practiceInformationView = this.getPracticeinformation();
        var opportunitiesView = this.getOpportunities();
        var systemCostsView = this.getSystemcosts();
        var financeOptionsView = this.getFinancingoptions();
        practiceInformationView.reset();
        opportunitiesView.reset();
        systemCostsView.reset();
        financeOptionsView.reset();
    },
    onPlayBackVideo: function () {
        var main = this.getMain();
        var menuView = this.getMenuview();
        main.videoView.videoContainerWrapper.show();
        menuView.hide();
    },
    onSavePersonalSettings: function () {
        var settingsStore = Ext.getStore('personaldetails');
        var settingsModel = Ext.create('RestorationRoboticsArtasCalculator.model.PersonalSettingsDetail', this.getMenuview().formPanelPersonalSettings.getValues());
        var errors = settingsModel.validate();
        var errorMsg = '';
        if (errors.getCount() > 0) {
            errors.each(function (errorObj) {
                errorMsg += errorObj.getMessage() + '<br>';
            });
            Ext.Msg.show({
                title: 'Artas Robotic Hair Transplant',
                message: '<b>Please enter the following</b><br>' + errorMsg,
                minWidth: 300
            });
            return false;
        }
        else {
            settingsStore.removeAll();
            settingsStore.add(settingsModel);
            settingsStore.sync();

            Ext.Msg.alert('Artas Robotic Hair Transplant', 'Your settings has been successfully saved.', Ext.emptyFn);
            this.getApplication().getController('Calculate').sessionData.personalSettingsDetail = settingsModel;

            return true;
        }
    },
    launch: function () {
        this.callParent();
        var menuview = this.getMenuview();
        menuview.on({
            scope: this,
            menuButtonTapped: this.menuButtonTapped,
            relatedDocumentsButtonTapped: this.relatedDocumentsButtonTapped,
            slideNotesButtonTapped: this.slideNotesButtonTapped,
            menuCloseButtonTapped: this.menuCloseButtonTapped,
            printPdf: this.printPdf,
            playBackVideo: this.onPlayBackVideo,
//            resetButtonTapped: this.onResetButtonTap,
            savePersonalSettings: this.onSavePersonalSettings
        });
    }
});
