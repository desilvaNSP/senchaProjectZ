Ext.define('RestorationRoboticsArtasCalculator.controller.Opportunities', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
        'RestorationRoboticsArtasCalculator.model.ArtasProcedureDetail'
    ],
    config: {
        refs: {
            opportunities: 'opportunities',
            harvestPayments: 'harvestpayments'

        }
    },
    sessionData: '',
    saveField: function () {

    },
    onPricingStrategyChange: function (formPanel) {

        var strategyField = formPanel.down('field[name=pricingStrategy]'),
            graftsField = formPanel.down('field[name=grafts]'),
            priceField = formPanel.down('field[name=price]'),
            ppaField = formPanel.down('field[name=pricePerApplication]');


            if (strategyField.getValue() === 'PerProcedure') {
                 var ppaValPerProcedure = this.onCleanCurrency(this.checkIfMinus(this.checkIfBlank(priceField.getValue())));
                ppaField.setValue(this.onFormatCurrency(ppaValPerProcedure));
            }
            else if (strategyField.getValue() === 'perGraft') {
                var ppaValPerGraft = parseFloat(this.onCleanCurrency(this.checkIfMinus(this.checkIfBlank(priceField.getValue())))) *  parseFloat(this.onCleanCurrency(this.checkIfMinus(this.checkIfBlank(graftsField.getValue()))));
                ppaField.setValue(this.onFormatCurrency(ppaValPerGraft));
            }
    },

    onDisappear: function () {
        var opportunityDetail = Ext.create('RestorationRoboticsArtasCalculator.model.OpportunityDetail', this.getOpportunities().formPanelOpportunities.getValues());
        var artasProcedureDetail = Ext.create('RestorationRoboticsArtasCalculator.model.ArtasProcedureDetail', this.getOpportunities().formPanelArtasProcedure.getValues());


        var errorsOpportunity = opportunityDetail.validate();
        var errorsArtasProcedure = artasProcedureDetail.validate();
        var errorMsg = '<b>Please enter the following</b><br/>';
        if (errorsOpportunity.getCount() > 0 || errorsArtasProcedure.getCount() > 0 ) {
            errorsOpportunity.each(function (errorObj) {
                errorMsg += errorObj.getMessage() + '<br>';
            });
            errorsArtasProcedure.each(function (errorObjArtas) {
                errorMsg += errorObjArtas.getMessage() + '<br>';
            });
            Ext.Msg.show({
                title: 'Artas Robotic Hair Transplant',
                message: errorMsg,
                minWidth: 300
            });
            return false;
        }
        else {


            this.getApplication().getController('Calculate').sessionData.OpportunityDetail = opportunityDetail;
            this.getApplication().getController('Calculate').sessionData.artasProcedureDetail = artasProcedureDetail;

            
            var patientPrice = this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('price')),
            ARTASharvestCost = this.onFormatCurrency(this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('artasHACost'))),
            avgHarvestPP = this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.artasProcedureDetail.get('grafts')),
            patientPricePH = this.onFormatCurrency((patientPrice));
            this.getHarvestPayments().formPanelHarvest.down('field[name=patientPricePerHarvest]').setValue(patientPricePH);
            this.getHarvestPayments().formPanelHarvest.down('field[name=costPaidPerHarvest]').setValue(ARTASharvestCost);
            this.getHarvestPayments().formPanelHarvest.down('field[name=averageHarvestsPerProcedure]').setValue(avgHarvestPP);
        }
        return true;


    },

    launch: function () {
        this.callParent();

        var opportunities = this.getOpportunities();


        opportunities.on({
            scope: this,
            saveField: this.saveField,
            cleanCurrency: this.onCleanCurrency,
            formatCurrency: this.onFormatCurrency,
            fieldBlur: this.onFieldBlur,
            fieldFocus: this.onfieldFocus,
            disappear: this.onDisappear,
            pricingStrategyChange: this.onPricingStrategyChange
        });
    }
});
