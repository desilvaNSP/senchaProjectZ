Ext.define('RestorationRoboticsArtasCalculator.controller.FinancingOptions', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    sessionData: '',
    config: {
        refs: {
            financingOptions: 'financingoptions',
            harvestPayments: 'harvestpayments',
            outputs :'outputs'
        }
    },
    onDisappear: function () {
       var financingOption = Ext.create('RestorationRoboticsArtasCalculator.model.FinancingOption', this.getFinancingOptions().formPanelFinance.getValues());
       var totalInvestment =this.getApplication().getController('Calculate').sessionData.systemCost.get('totalInvestment');
       var outfix = this.getOutputs().fixedCost.getItems().items[0];
       outfix.setHtml(totalInvestment);


        var errorsFiancingOption = financingOption.validate();
        var errorMsg = '<b>Please enter the following</b><br/>';
        if (errorsFiancingOption.getCount() > 0) {
            errorsFiancingOption.each(function (errorObj) {
                errorMsg += errorObj.getMessage() + '<br>';
            });
            Ext.Msg.show({
                title: 'Artas Robotic Hair Transplant',
                message: errorMsg,
                minWidth: 300
            });
            return false;
        }
        else {
            this.getApplication().getController('Calculate').sessionData.financingOption = financingOption;

            var returnApplicationsArray = this.getApplication().getController('Calculate').calculateApplications();
            var returnRevenueArray = this.getApplication().getController('Calculate').calculateRevenue();
            var returnDirectCostArray = this.getApplication().getController('Calculate').calculateDirectCost();
            var returnNetInComeArray = this.getApplication().getController('Calculate').calculateNetInCome();

            this.getApplication().getController('Outputs').printRevenueDetailReport(returnRevenueArray);
            this.getApplication().getController('Outputs').printApplicationsDetailReport(returnApplicationsArray);
            this.getApplication().getController('Outputs').printDirectCostDetailReport(returnDirectCostArray);
            this.getApplication().getController('Outputs').printNetInComeDetailReport(returnNetInComeArray);
        }
        return true;
    },
    onFinanceMonthlyPayment: function (formPanel) {

        var financeTerm = formPanel.down('field[name=financeTerm]'),
            downPayment = formPanel.down('field[name=downPayment]'),
            interestTerm = formPanel.down('field[name=interestTerm]'),
            monthlyPayment = formPanel.down('field[name=monthlyPayment]');

        var interesrTermValue = parseFloat(this.onCleanPercentage(interestTerm.getValue())),
            financeTermValue = parseFloat(financeTerm.getValue()),
            downPaymentValue = parseFloat(this.onCleanCurrency(downPayment.getValue()));

        var totalInvestment = parseFloat(this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.systemCost.get('totalInvestment'))),
            monthlyPaymentCalcualtion;

        monthlyPaymentCalcualtion = this.calculatePMT((interesrTermValue / 100), (financeTermValue * 12), (totalInvestment - downPaymentValue));

        monthlyPayment.setValue(monthlyPaymentCalcualtion);
    },


    onBuyOptionsSelected: function (formPanel) {
        this.getFinancingOptions().setStyle("background: url('resources/images/financingOptions.png') no-repeat bottom left; background-size: 305px 336px;");
        formPanel.down('field[name=oneTimePayment]').show();
        formPanel.down('field[value=detailsReport]').show();
        formPanel.down('field[value=headlineReport]').show();
        formPanel.down('field[name=shippingTextField]').show();
        formPanel.down('field[name=financeTerm]').hide();
        formPanel.down('field[name=downPayment]').hide();
        formPanel.down('field[name=interestTerm]').hide();
        formPanel.down('field[name=reportTextField]').hide();
        formPanel.down('field[value=detailsReportFinance]').hide();
        formPanel.down('field[value=headlineReportFinance]').hide();
    },
    onFinancingOption: function (formPanel) {
        this.getFinancingOptions().setStyle('background:#fff');
        formPanel.down('field[name=financeTerm]').show();
        formPanel.down('field[name=downPayment]').show();
        formPanel.down('field[name=interestTerm]').show();
        formPanel.down('field[name=reportTextField]').show();
        formPanel.down('field[value=detailsReportFinance]').show();
        formPanel.down('field[value=headlineReportFinance]').show();
        formPanel.down('field[name=oneTimePayment]').hide();
        formPanel.down('field[value=detailsReport]').hide();
        formPanel.down('field[value=headlineReport]').hide();
        formPanel.down('field[name=shippingTextField]').hide();
    },
    launch: function () {
        this.callParent();
        this.launched = false;
        var financingOptions = this.getFinancingOptions();

        financingOptions.on({
            scope: this,
            fieldBlur: this.onFieldBlur,
            fieldFocus: this.onfieldFocus,
            disappear: this.onDisappear,
            financingOption: this.onFinancingOption,
            buyOptionsSelected: this.onBuyOptionsSelected,
            financeMonthlyPayment: this.onFinanceMonthlyPayment
        });
    }
});
