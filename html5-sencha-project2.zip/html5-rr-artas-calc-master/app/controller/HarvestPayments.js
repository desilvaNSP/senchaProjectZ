Ext.define('RestorationRoboticsArtasCalculator.controller.HarvestPayments', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    sessionData: '',
    config: {
        refs: {
            harvestPayments: 'harvestpayments'

        }
    },

    onDisappear: function () {


        var harvestpayment = Ext.create('RestorationRoboticsArtasCalculator.model.HarvestPayment', this.getHarvestPayments().formPanelHarvest.getValues());

        var errorsHarvest = harvestpayment.validate();
        var errorMsg = '<b>Please enter the following</b><br/>';
        if (errorsHarvest.getCount() > 0) {
            errorsHarvest.each(function (errorObj) {
                errorMsg += errorObj.getMessage() + '<br>';
            });
            Ext.Msg.show({
                title: 'Artas Robotic Hair Transplant',
                message: errorMsg,
                minWidth: 300
            });
            return false;
        }
        else {
        this.getApplication().getController('Calculate').sessionData.harvestPayment = harvestpayment;

        }
        return true;
    },

    launch: function () {
        this.callParent();
        this.launched = false;
        var harvestPayments = this.getHarvestPayments();

        harvestPayments.on({
            scope: this,
            fieldBlur: this.onFieldBlur,
            fieldFocus: this.onfieldFocus,
            disappear: this.onDisappear
        });
    }
});
