Ext.define('RestorationRoboticsArtasCalculator.controller.Calculate', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    sessionData: '',
    output: '',
    applications: '',
    revenueArray: '',
    directCostArray:'',
    netInComeArray:'',
    
    config: {
        refs: {
            outputs: 'outputs'
        }
    },
    
    calculateApplications: function() {
        var that = this;
        var monthsArray = []; //OpportunityDetail model Field Values

        this.sessionData.OpportunityDetail.fields.each(function(field, index) {
            // Code here
            var fieldName = field.getName(); //getting field names
            if (!isNaN(that.sessionData.OpportunityDetail.get(fieldName))) {
                monthsArray[index - 1] = parseFloat(that.sessionData.OpportunityDetail.get(fieldName)).toFixed(2); //first element is a string
            }

        });
        var totalApplicationsForYear3 = 0;
        var totalApplicationsForYear2 = 0;
        var totalApplicationsForYear1 = 0;

        //real calculations for months
        for (var i = 0; i < monthsArray.length; i++) {
            if (that.sessionData.OpportunityDetail.get('cases') === 'casesWeek') {
                //Converting from weeks to months
                monthsArray[i] = monthsArray[i] * 4.34812;
                console.log(monthsArray);
            }
            if (i === monthsArray.length - 1) {
                totalApplicationsForYear2 = monthsArray[i]; //temporary value
            }
            monthsArray[i] = monthsArray[i] * 3;
            totalApplicationsForYear1 += Math.floor(monthsArray[i]); //sum of month costs
        }
        totalApplicationsForYear2 = totalApplicationsForYear1 * 1.3; //real totalApplicationsForYear2 value
        totalApplicationsForYear3 = totalApplicationsForYear2 * 1.3;

        monthsArray.push(totalApplicationsForYear1)
        monthsArray.push(totalApplicationsForYear2);
        monthsArray.push(totalApplicationsForYear3);
        var outputFields = this.output.getFields().all;
        for (var j = 0; j < 7; j++) {
            this.output.set(outputFields[j].getName(), Math.floor(monthsArray[j]));
        }
        var month0To3Applications = parseFloat(this.output.get('month0to3Applications')).toFixed(0),
                month4To6Applications = parseFloat(this.output.get('month4to6Applications')).toFixed(0),
                month7To9Applications = parseFloat(this.output.get('month7to9Applications')).toFixed(0),
                month10To12Applications = parseFloat(this.output.get('month10to12Applications')).toFixed(0),
                year1Applications = parseFloat(this.output.get('year1Applications')).toFixed(0),
                year2Applications = parseFloat(this.output.get('year2Applications')).toFixed(0),
                year3Applications = parseFloat(this.output.get('year3Applications')).toFixed(0);

        this.applications = {
            'month0to3Applications': month0To3Applications,
            'month4to6Applications': month4To6Applications,
            'month7to9Applications': month7To9Applications,
            'month10to12Applications': month10To12Applications,
            'year1Application': year1Applications,
            'year2Applications': year2Applications,
            'year3Applications': year3Applications
        };
        return this.applications;
    },
    calculateRevenue: function() {
        //  var costPaidPerHarvest = this.onCleanCurrency(this.sessionData.harvestPayment.get('harvestYieldPercentage'));
        var avgHarvestsPerProcedure = this.sessionData.harvestPayment.get('averageHarvestsPerProcedure');
        var patientPricePerHarvest = this.onCleanCurrency(this.sessionData.harvestPayment.get('patientPricePerHarvest'));

        var month0To3Applications = parseFloat(this.output.get('month0to3Applications')).toFixed(2);
        var month4To6Applications = parseFloat(this.output.get('month4to6Applications')).toFixed(2);
        var month7To9Applications = parseFloat(this.output.get('month7to9Applications')).toFixed(2);
        var month10To12Applications = parseFloat(this.output.get('month10to12Applications')).toFixed(2);
        var year2Applications = parseFloat(this.output.get('year2Applications')).toFixed(2);
        var year3Applications = parseFloat(this.output.get('year3Applications')).toFixed(2);

        var month0T03Revenue = month0To3Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        var month4To6Revenue = month4To6Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        var month7To9Revenue = month7To9Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        var month10To12Revenue = month10To12Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        var year1Revenue = month0T03Revenue + month4To6Revenue + month7To9Revenue + month10To12Revenue;
        var year2Revenue = year2Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        var year3Revenue = year3Applications * avgHarvestsPerProcedure * patientPricePerHarvest;
        this.output.set('month0to3Revenue', parseFloat(month0T03Revenue).toFixed(2));
        this.output.set('month4to6Revenue', parseFloat(month4To6Revenue).toFixed(2));
        this.output.set('month7to9Revenue', parseFloat(month7To9Revenue).toFixed(2));
        this.output.set('month10to12Revenue', parseFloat(month10To12Revenue).toFixed(2));
        this.output.set('year1Revenue', parseFloat(year1Revenue).toFixed(2));
        this.output.set('year2Revenue', parseFloat(year2Revenue).toFixed(2));
        this.output.set('year3Revenue', parseFloat(year3Revenue).toFixed(2));

        this.revenueArray = {
            'month0to3Revenue': month0T03Revenue,
            'month4to6Revenue': month4To6Revenue,
            'month7to9Revenue': month7To9Revenue,
            'month10to12Revenue': month10To12Revenue,
            'year1Revenue': year1Revenue,
            'year2Revenue': year2Revenue,
            'year3Revenue': year3Revenue
        };

        return this.revenueArray;
    },
    calculateDirectCost: function() {


        var buyOptions = this.sessionData.financingOption.get('buyOptions');
        var otherCostOption = this.sessionData.artasProcedureDetail.get('otherCost');

        var month0To3Applications = parseFloat(this.output.get('month0to3Applications')).toFixed(2),
            month4To6Applications = parseFloat(this.output.get('month4to6Applications')).toFixed(2),
            month7To9Applications = parseFloat(this.output.get('month7to9Applications')).toFixed(2),
            month10To12Applications = parseFloat(this.output.get('month10to12Applications')).toFixed(2),
            year2Applications = parseFloat(this.output.get('year2Applications')).toFixed(2),
            year3Applications = parseFloat(this.output.get('year3Applications')).toFixed(2);



        var month0to3DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, '0to3period') - this.firstSegmentOfDirectCostCalculation(month0To3Applications) - this.thirdSegmentOfDirectCostCalculation(otherCostOption, month0To3Applications));
        var month4to6DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, '4to6period')) - (this.firstSegmentOfDirectCostCalculation(month4To6Applications)) - (this.thirdSegmentOfDirectCostCalculation(otherCostOption, month4To6Applications));
        var month7to9DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, '7to9period')) - (this.firstSegmentOfDirectCostCalculation(month7To9Applications)) - (this.thirdSegmentOfDirectCostCalculation(otherCostOption, month7To9Applications));
        var month10to12DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, '10to12period')) - (this.firstSegmentOfDirectCostCalculation(month10To12Applications)) - (this.thirdSegmentOfDirectCostCalculation(otherCostOption, month10To12Applications));



        var yr1DirectCosts = month0to3DirectCosts + month4to6DirectCosts + month7to9DirectCosts + month10to12DirectCosts;
        var yr2DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, 'year2')) - (this.firstSegmentOfDirectCostCalculation(year2Applications)) - (this.thirdSegmentOfDirectCostCalculation(otherCostOption, year2Applications));
        var yr3DirectCosts = (this.secSegmentOfDirectCostCalculation(buyOptions, 'year3')) - (this.firstSegmentOfDirectCostCalculation(year3Applications)) - (this.thirdSegmentOfDirectCostCalculation(otherCostOption, year3Applications));


        this.output.set('month0to3DirectCosts', parseFloat(month0to3DirectCosts).toFixed(2));
        this.output.set('month4to6DirectCosts', parseFloat(month4to6DirectCosts).toFixed(2));
        this.output.set('month7to9DirectCosts', parseFloat(month7to9DirectCosts).toFixed(2));
        this.output.set('month10to12DirectCosts', parseFloat(month10to12DirectCosts).toFixed(2));
        this.output.set('year1DirectCosts', parseFloat(yr1DirectCosts).toFixed(2));
        this.output.set('year2DirectCosts', parseFloat(yr2DirectCosts).toFixed(2));
        this.output.set('year3DirectCosts', parseFloat(yr3DirectCosts).toFixed(2));

        this.directCostArray = {
            'month0to3DirectCosts': month0to3DirectCosts,
            'month4to6DirectCosts': month4to6DirectCosts,
            'month7to9DirectCosts': month7to9DirectCosts,
            'month10to12DirectCosts': month10to12DirectCosts,
            'year1DirectCosts': yr1DirectCosts,
            'year2DirectCosts': yr2DirectCosts,
            'year3DirectCosts': yr3DirectCosts

        };
        return this.directCostArray;
    },
    firstSegmentOfDirectCostCalculation: function(applications) {
        var costPaidPerHarvest = this.onCleanCurrency(this.sessionData.harvestPayment.get('costPaidPerHarvest')),
                avgHarvestsPerProcedure = this.sessionData.harvestPayment.get('averageHarvestsPerProcedure');
        return  costPaidPerHarvest * avgHarvestsPerProcedure * applications;
    },
    secSegmentOfDirectCostCalculation: function(option, period) {
        var downPayment = this.onCleanCurrency(this.sessionData.financingOption.get('downPayment')),

            monthlyPaymentValue = this.onCleanCurrency(this.sessionData.financingOption.get('monthlyPayment')),
            financeTerm = this.onCleanCurrency(this.sessionData.financingOption.get('financeTerm')),
            totalInvestment = parseFloat(this.onCleanCurrency(this.sessionData.systemCost.get('totalInvestment'))),
            oneTimePayment = this.onCleanCurrency(this.sessionData.financingOption.get('oneTimePayment'));

        if (period === '0to3period') {
            if (option === 'buy') {
              return (-totalInvestment);
            } else {
                return ((monthlyPaymentValue * 3) - downPayment);
            }
        }
        else if (period === 'year2' || period === 'year3') {
            if (option === 'finance') {
                if (financeTerm > 2) {
                    return  (monthlyPaymentValue * 12);
                }
            }
            else {
                return 0;
            }
        }
        else {
            if(option === 'finance') {
                return (monthlyPaymentValue * 3);
            }
            else if(option === 'buy'){
                return 0;
            }
        }
    },
    thirdSegmentOfDirectCostCalculation: function(option, applications) {
        var otherCostAmount = this.onCleanCurrency(this.sessionData.artasProcedureDetail.get('otherCostAmount'));
        if (option === "perDay") {
            return (otherCostAmount * 365);
        }
        else if (option === "perMonth") {
            return (otherCostAmount * 12);
        }
        else {
            return (applications * otherCostAmount);
        }
    },
    calculateNetInCome: function() {

        var month0to3NetIncome = parseFloat(this.output.get('month0to3Revenue')) + parseFloat(this.output.get('month0to3DirectCosts')),
                month4to6NetIncome = parseFloat(this.output.get('month4to6Revenue')) + parseFloat(this.output.get('month4to6DirectCosts')),
                month7to9NetIncome = parseFloat(this.output.get('month7to9Revenue')) + parseFloat(this.output.get('month7to9DirectCosts')),
                month10to12NetIncome = parseFloat(this.output.get('month10to12Revenue')) + parseFloat(this.output.get('month10to12DirectCosts')),
                yr1NetIncome = parseFloat(this.output.get('year1Revenue')) + parseFloat(this.output.get('year1DirectCosts')),
                yr2NetIncome = parseFloat(this.output.get('year2Revenue')) + parseFloat(this.output.get('year2DirectCosts')),
                yr3NetIncome = parseFloat(this.output.get('year3Revenue')) + parseFloat(this.output.get('year3DirectCosts'));

        this.output.set('month0to3NetIncome', parseFloat(month0to3NetIncome).toFixed(2));
        this.output.set('month4to6NetIncome', parseFloat(month4to6NetIncome).toFixed(2));
        this.output.set('month7to9NetIncome', parseFloat(month7to9NetIncome).toFixed(2));
        this.output.set('month10to12NetIncome', parseFloat(month10to12NetIncome).toFixed(2));

        this.netInComeArray = {
            'month0to3NetIncome': month0to3NetIncome,
            'month4to6NetIncome': month4to6NetIncome,
            'month7to9NetIncome': month7to9NetIncome,
            'month10to12NetIncome': month10to12NetIncome,
            'year1NetIncome': yr1NetIncome,
            'year2NetIncome': yr2NetIncome,
            'year3NetIncome': yr3NetIncome
        };
        console.log(this.netInComeArray);
        return this.netInComeArray;
    },
    launch: function() {
        this.callParent();
        this.sessionData = Ext.create('RestorationRoboticsArtasCalculator.model.SessionData');
        this.output = Ext.create('RestorationRoboticsArtasCalculator.model.Output');
    }
});
