Ext.define('RestorationRoboticsArtasCalculator.controller.PracticeInformation', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    config: {
        refs: {
            practiceInformation: 'practiceinformation'
            //diameterSelection: 'diameterselection'
        }
    },
    sessionData: '',
    loadData : function () {

    },
     onDisappear : function () {


            var practiceInformationModel = Ext.create('RestorationRoboticsArtasCalculator.model.PracticeInformation', this.getPracticeinformation().formPanel.getValues());
            var errors = practiceInformationModel.validate();
            var errorMsg = '<b>Please enter the following</b><br/>';
            if (errors.getCount() > 0) {
                errors.each(function (errorObj) {
                    errorMsg += errorObj.getMessage() + '<br>';
                });
                Ext.Msg.show({
                    title: 'Artas Robotic Hair Transplant',
                    message: errorMsg,
                    minWidth: 300
                });
                return false;
            }
            else {

              this.getApplication().getController('Calculate').sessionData.practiceInformation = practiceInformationModel;
              this.getApplication().getController('Calculate').sessionData.practiceinformation = practiceInformationModel;
              
              
          //  var currencyValue = this.getApplication().getController('Calculate').sessionData.practiceinformation.get('currencyExchange');


            }
       return true;


     },
    launch: function () {
        this.callParent();
        var practiceInformation = this.getPracticeInformation();
        practiceInformation.on({
            scope: this,
            disappear: this.onDisappear,
            fieldBlur: this.onFieldBlur,
            fieldFocus: this.onfieldFocus
        });
    }
});
