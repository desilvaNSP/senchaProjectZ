Ext.define('RestorationRoboticsArtasCalculator.controller.Main', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    sessionData: '',
    config: {
        refs: {
            main: 'main',
            navbar: 'navbar'
        }
    }
});
