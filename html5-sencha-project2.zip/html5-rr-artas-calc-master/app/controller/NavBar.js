Ext.define('RestorationRoboticsArtasCalculator.controller.NavBar', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
        'RestorationRoboticsArtasCalculator.model.SessionData',
        'RestorationRoboticsArtasCalculator.model.OpportunityDetail'

    ],
    config: {
        refs: {
            navbar: 'navbar',
            main: 'main',
            menuview: 'menuview',
            practiceinformation: 'practiceinformation',
            opportunities: 'opportunities',
            systemcosts: 'systemcosts',
            financingoptions: 'financingoptions'
        }
    },
    sessionData: '',
    onNextNavigation: function () {
        var navBar = this.getNavbar();
        var main = this.getMain();

        if (main.navigationView.getActiveItem().fireEvent('disappear')) {
            main.navigationView.setActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) + 1);
            if (main.navigationView.indexOf(main.navigationView.getActiveItem()) === main.navigationView.getItems().length - 2) {
                navBar.nextButton.setHidden(true);
            }
            else {
                navBar.nextButton.setHidden(false);
            }
            if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < 1) {
                navBar.backButton.setHidden(true);
            }
            else {
                  setTimeout(function(){
                        navBar.backButton.setHidden(false);
                 }, 200);


            }

        }
    },
    onBackNavigation: function () {
        var main = this.getMain();
        var navBar = this.getNavbar();


        main.navigationView.animateActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) - 1, {
            type: 'slide',
            direction: 'right'
        });
        if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < 1) {
            navBar.backButton.setHidden(true);
        }
        else {
            navBar.backButton.setHidden(false);;
        }
        if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < main.navigationView.getItems().length - 2) {
            navBar.nextButton.setHidden(false);
        } else {
            navBar.nextButton.setHidden(true);
        }
    },
    onResetButtonTap: function () {
        this.reset(true);
    },
    onPlayBackVideo: function () {
        var main = this.getMain();
        var menuView = this.getMenuview();
        main.videoView.videoContainerWrapper.show();
        menuView.hide();
    },
    reset: function (boolValue, formpanel, options) {

        var that = this;
        var navBar = this.getNavbar();
        var main = this.getMain();
        var practiceInformationView = this.getPracticeinformation();
        var opportunitiesView = this.getOpportunities();
        var systemCostsView = this.getSystemcosts();
        var financeOptionsView = this.getFinancingoptions();

        if (boolValue) {
            Ext.Msg.confirm("Reset", "Resetting your application will loose all your data. Do you want to continue?", function (value) {
                if (value == "yes") {
                    practiceInformationView.reset();
                    opportunitiesView.reset();
                    systemCostsView.reset();
                    financeOptionsView.reset();
                    that.goToRoot();



                }
            });
        }
        else {

            practiceInformationView.reset();
            opportunitiesView.reset();
            systemCostsView.reset();
            financeOptionsView.reset();
            formpanel.down('field[name=currencyExchange]').setOptions(options);
            that.goToRoot();

        }

    },
    goToRoot: function () {
        var navBar = this.getNavbar();
        var main = this.getMain();
         main.navigationView.setActiveItem(0);
         navBar.nextButton.setHidden(false);
        navBar.backButton.setHidden(true);
        this.getApplication().getController('Menu').menuCloseButtonTapped();
    },



    onUpdateDefaults: function (value) {
        var practiceInformationModel = Ext.create('RestorationRoboticsArtasCalculator.model.PracticeInformation', this.getPracticeinformation().formPanel.getValues());
        this.getApplication().getController('Calculate').sessionData.practiceInformation = practiceInformationModel;
        var systemCostsView = this.getSystemcosts();
        var model = Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost').getFields();
        if (value === 'Dollars') {
            for (var i = 4; i < model.length; i++) {
                var optionValues = ['300000','50000' ,'30000' ,'30000','20000','20000'];
                var newvalue = this.onFormatCurrency(parseFloat(optionValues[i-4]));
                model.all[i].setDefaultValue(newvalue);
            }
        }else{
           for (var i = 4; i < model.length; i++) {
                model.all[i].setDefaultValue('');

            }
        }
        systemCostsView.updateValues();
    },
    launch: function () {
        this.callParent();
        var navBar = this.getNavbar();
        var menuview = this.getMenuview();
        var practiceinformation = this.getPracticeinformation();
        navBar.backButton.setHidden(true);
        navBar.on({
            scope: this,
            nextNavigation: this.onNextNavigation,
            backNavigation: this.onBackNavigation,
            cleanCurrency: this.onCleanCurrency,
            formatCurrency: this.onFormatCurrency
        });
        menuview.on({
            scope: this,
            playBackVideo: this.onPlayBackVideo,
            resetButtonTapped: this.onResetButtonTap
        });
        practiceinformation.on({
            scope: this,
            resetChangeCurrency: this.reset,
            updatedefaults: this.onUpdateDefaults
        });
    }
});
