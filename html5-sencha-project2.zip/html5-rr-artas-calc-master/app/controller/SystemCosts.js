Ext.define('RestorationRoboticsArtasCalculator.controller.SystemCosts', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    config: {
        refs: {
            systemCosts: 'systemcosts',
//            harvestPayments: 'harvestpayments',
            financingoptions: 'financingoptions'
        }
    },
    sessionData: '',
    onSystemCostCalculation: function (formPanel, formPanelOption) {
        if(this.onCleanCurrency(formPanelOption.down('field[name=machine]').getValue()) !== ''){
            formPanelOption.down('field[name=machineCheckField]').enable();
        }else{
            formPanelOption.down('field[name=machineCheckField]').uncheck();
            formPanelOption.down('field[name=machineCheckField]').disable();
        }
        if(this.onCleanCurrency(formPanelOption.down('field[name=trainingA]').getValue()) !== ''){
            formPanelOption.down('field[name=trainingAField]').enable();
        }else{
            formPanelOption.down('field[name=trainingAField]').uncheck();
            formPanelOption.down('field[name=trainingAField]').disable();
        }
        if(this.onCleanCurrency(formPanelOption.down('field[name=trainingB]').getValue()) !== ''){
            formPanelOption.down('field[name=trainingBField]').enable();
        }else{
            formPanelOption.down('field[name=trainingBField]').uncheck();
            formPanelOption.down('field[name=trainingBField]').disable();
        }
        if(this.onCleanCurrency(formPanelOption.down('field[name=procedurePackage]').getValue()) !== ''){
            formPanelOption.down('field[name=procedurePackageCheckField]').enable();
        }else{
            formPanelOption.down('field[name=procedurePackageCheckField]').uncheck();
            formPanelOption.down('field[name=procedurePackageCheckField]').disable();
        }
        if(this.onCleanCurrency(formPanelOption.down('field[name=practiceDev]').getValue()) !== ''){
            formPanelOption.down('field[name=practiceDevpmtFndCheckField]').enable();
        }else{
            formPanelOption.down('field[name=practiceDevpmtFndCheckField]').uncheck();
            formPanelOption.down('field[name=practiceDevpmtFndCheckField]').disable();
        }
         if(this.onCleanCurrency(formPanelOption.down('field[name=services]').getValue()) !== ''){
            formPanelOption.down('field[name=extndSrvceCntrctCheckField]').enable();
        }else{
            formPanelOption.down('field[name=extndSrvceCntrctCheckField]').uncheck();
            formPanelOption.down('field[name=extndSrvceCntrctCheckField]').disable();
        }



        var returnValueOptions;
        var total;
        var systemPrice = parseFloat(this.onCleanCurrency(formPanel.down('field[name=systemPrice]').getValue())),
            taxPresentage = parseFloat(this.onCleanPercentage(formPanel.down('field[name=tax]').getValue())),
            shippingCost = parseFloat(this.onCleanCurrency(formPanel.down('field[name=shipping]').getValue())),
            totalInvestmentField = formPanel.down('field[name=totalInvestment]');

        returnValueOptions = parseFloat(this.onUpdateSystemCost(formPanelOption));


        if (isNaN(taxPresentage) || taxPresentage < 0) {
            taxPresentage = 0;
        }
        if (isNaN(shippingCost) || shippingCost < 0) {
            shippingCost = 0;
        }

        if (systemPrice !== '' && taxPresentage !== '' && shippingCost !== '') {
            var taxPrice = systemPrice * taxPresentage / 100;
            total = returnValueOptions + systemPrice + taxPrice + shippingCost;
            if (!isNaN(total)) {
                totalInvestmentField.setValue(this.onFormatCurrency((total).toString()));
            }
            else if (isNaN(total) && !isNaN(returnValueOptions)) {
                totalInvestmentField.setValue(this.onFormatCurrency(returnValueOptions));
            }
            else {
                totalInvestmentField.setValue(this.onFormatCurrency('0'));
            }
        }
        else {
            totalInvestmentField.setValue(this.onFormatCurrency('0'));
        }


    },
    onUpdateSystemCost: function (formPanelOption) {
        var optionsTotalValue = 0;
        if (formPanelOption.down('field[name=machineCheckField]').isChecked()) {
            var machine = this.onCleanCurrency(formPanelOption.down('field[name=machine]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(machine));
        }
        if (formPanelOption.down('field[name=trainingAField]').isChecked()) {
            var trainingA = this.onCleanCurrency(formPanelOption.down('field[name=trainingA]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(trainingA));
        }
        if (formPanelOption.down('field[name=trainingBField]').isChecked()) {
            var trainingB = this.onCleanCurrency(formPanelOption.down('field[name=trainingB]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(trainingB));
        }
        if (formPanelOption.down('field[name=procedurePackageCheckField]').isChecked()) {
            var procedurePackage = this.onCleanCurrency(formPanelOption.down('field[name=procedurePackage]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(procedurePackage));
        }
        if (formPanelOption.down('field[name=practiceDevpmtFndCheckField]').isChecked()) {
            var practiceDev = this.onCleanCurrency(formPanelOption.down('field[name=practiceDev]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(practiceDev));
        }
        if (formPanelOption.down('field[name=extndSrvceCntrctCheckField]').isChecked()) {
            var services = this.onCleanCurrency(formPanelOption.down('field[name=services]').getValue());
            optionsTotalValue = optionsTotalValue + parseFloat(this.isEmpty(services));
        }
        return optionsTotalValue;
    },

    isEmpty : function(value){
        if (value === "" || value === null) {
              return '0';
        }else {
            return value;
        }
    },
    onDisappear: function () {

        var systemCostDetail = Ext.create('RestorationRoboticsArtasCalculator.model.SystemCost', this.getSystemCosts().formPanel.getValues());

        var errorsStstemCost = systemCostDetail.validate();
        var errorMsg = '<b>Please enter the following</b><br/>';
        if (errorsStstemCost.getCount() > 0) {
            errorsStstemCost.each(function (errorObjSystemCost) {
                errorMsg += errorObjSystemCost.getMessage() + '<br>';
            });
            Ext.Msg.show({
                title: 'Artas Robotic Hair Transplant',
                message: errorMsg,
                minWidth: 300
            });
            return false;
        }
        else {


            this.getApplication().getController('Calculate').sessionData.systemCost = systemCostDetail;

            var totalInvestment = this.onCleanCurrency(this.getApplication().getController('Calculate').sessionData.systemCost.get('totalInvestment'));
            this.getFinancingoptions().formPanelFinance.down('field[name=oneTimePayment]').setValue(this.onFormatCurrency(totalInvestment));
        }

        return true;
    },

    launch: function () {
        this.callParent();
        this.launched = false;
        var systemCost = this.getSystemCosts();
        systemCost.on({
            scope: this,
            fieldBlur: this.onFieldBlur,
            fieldFocus: this.onfieldFocus,
            calculateSystemCost: this.onSystemCostCalculation,
            disappear: this.onDisappear
        });
    }
});
