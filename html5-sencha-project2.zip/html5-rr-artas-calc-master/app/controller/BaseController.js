Ext.define('RestorationRoboticsArtasCalculator.controller.BaseController', {
    extend: 'Ext.app.Controller',
    requires: [
    ],
    currencyExchange: '$',
    config: {
        refs: {
            //diameterSelection: 'diameterselection'
            practiceinformation: 'practiceinformation'
        }
    },
    checkIfBlank: function (value) {
        if (value === '') {
            return 0;
        }
        return value;
    },
    checkIfMinus: function (value) {
        if (value < 0) {
            return 0;
        }
        return value;
    },
    onFormatPercentage: function (number) {
        var numberVal = '';
        var numberText = this.onCleanPercentage(number);
        if (!isNaN(numberText)) {
            number = numberText.toString();
            if (number.indexOf('%') === number.length - 1) {
                numberVal = number;
            }
            else {
                numberVal = number + '%';
            }
        }
        else {
            numberVal = '';
        }

        return numberVal;
    },
    onCleanPercentage: function (number) {
        //cleaning percentage sign
        if (number === null) {
            return 0;
        }

        number = number.toString();
        if (number.indexOf('%') === number.length - 1) {
            return number.slice(0, -1);
        }
        else {
            return number;
        }
    },

    onFormatCurrency: function (number) {
        //adding $ sign and commas to the currency
        var numberText = this.onCleanCurrency(number);
        if (!isNaN(numberText) && numberText !== '') {
            number = number.toString();
            if (number.indexOf(this.getApplication().getController('Calculate').sessionData.practiceInformation.getData().currencyExchange) === 0) {
                return this.getApplication().getController('Calculate').sessionData.practiceInformation.getData().currencyExchange + parseFloat(number.substring(1)).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
            else {
                return this.getApplication().getController('Calculate').sessionData.practiceInformation.getData().currencyExchange + parseFloat(number).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
        } else {
            return '';
        }
    },
    onCleanCurrency: function (number) {
        var numberString = number.toString();
        var currency = this.getApplication().getController('Calculate').sessionData.practiceInformation.getData().currencyExchange;
        var currencyText = numberString.substring(0, currency.length);
        //  alert(currencyText);
        if (currencyText === currency && numberString !== '') {
            if (numberString.indexOf(',') > -1) {
                return parseFloat(numberString.substring(currency.length, numberString.length).split(',').join(''));
            }
            else {
                return parseFloat(numberString.substring(currency.length, numberString.length));
            }
        }
        else {
            if (numberString.indexOf(',') > -1) {
                return parseFloat(numberString.split(',').join(''));
            }
            else {
                return number;
            }
        }
    },

    onFieldBlur: function (field) {

        var value = field.getValue();


        if (value !== '') {

            if (!isNaN(value) && value < 0) {
                field.setValue('');
            }
            else {
                if (field.getName() === 'tax' || field.getName() === 'harvestYieldPercentage' || field.getName() === 'interestTerm') {
                    field.setValue(this.onFormatPercentage(field.getValue()));
                }
                else {
                    field.setValue(this.onFormatCurrency(field.getValue()));
                }
            }
        }
        else {
            field.setValue('');
        }

    },
    onfieldFocus: function (field) {
        var value = field.getValue();

        if (value !== '') {
            if (!isNaN(value) && value < 0) {
                field.setValue('');
            }
            else {
                if (field.getName() === 'tax' || field.getName() === 'harvestYieldPercentage' || field.getName() === 'interestTerm') {
                    field.setValue(this.onCleanPercentage(field.getValue()));
                }
                else {
                    field.setValue(this.onCleanCurrency(field.getValue()));
                }
            }
        }
        else {
            field.setValue('');
        }
    },


    calculatePMT: function (ir, np, pv, fv, type) {

        var pmt, pvif;

        fv || (fv = 0);
        type || (type = 0);

        if (ir === 0)
            return -(pv + fv) / np;

        pvif = Math.pow(1 + ir, np);
        pmt = -ir * pv * (pvif + fv) / (pvif - 1);

        if (type === 1)
            pmt /= (1 + ir);

        return pmt;
    },


    roundToInteger: function (number) {
        if (number > 0) {
            return Math.round(number);
        } else {
            return Math.abs(Math.round(number));
        }
    },

    removeDecimal: function (vlaue) {
        var str = vlaue.split('.');
        return str[0];
    },

    addBrackets: function (number, realValue) {
        if (realValue < 0) {
            return '(' + number + ')';
        }
        return number;
    }

// var posNum = (value < 0) ? value * -1 : value
//    addToTheLocalStorage : function(store,model){
//        store.removeAll();
//        store.add(model);
//        store.sync();
//    },
//
//    getFromLocalStorage : function(){
//
//    }

});
