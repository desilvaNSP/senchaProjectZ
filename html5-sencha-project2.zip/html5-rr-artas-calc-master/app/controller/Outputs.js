Ext.define('RestorationRoboticsArtasCalculator.controller.Outputs', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    config: {
        refs: {
            outputs: 'outputs',
            financingOptions: 'financingoptions'
        }
    },

    printApplicationsDetailReport: function (jsonApplications) {
     //   var objApplications = JSON.parse(jsonApplications);
        this.getOutputs().month0to3Raw.innerItems[1].setValue(jsonApplications.month0to3Applications);
        this.getOutputs().month4to6Raw.innerItems[1].setValue(jsonApplications.month4to6Applications);
        this.getOutputs().month7to9Raw.innerItems[1].setValue(jsonApplications.month7to9Applications);
        this.getOutputs().month10to12Raw.innerItems[1].setValue(jsonApplications.month10to12Applications);
        this.getOutputs().year1Raw.innerItems[1].setValue(jsonApplications.year1Application);
        this.getOutputs().year2Raw.innerItems[1].setValue(jsonApplications.year2Applications);
        this.getOutputs().year3Raw.innerItems[1].setValue(jsonApplications.year3Applications);
        this.getOutputs().barChartGeneration(
           parseFloat (jsonApplications.month0to3Applications),
           parseFloat (jsonApplications.month4to6Applications),
           parseFloat (jsonApplications.month7to9Applications),
           parseFloat (jsonApplications.month10to12Applications)
        );

    },

    printRevenueDetailReport: function (jsonRevenue) {
    //    var objRevenue = JSON.parse(jsonRevenue);
        this.getOutputs().month0to3Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.month0to3Revenue)))));
        this.getOutputs().month4to6Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.month4to6Revenue)))));
        this.getOutputs().month7to9Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.month7to9Revenue)))));
        this.getOutputs().month10to12Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.month10to12Revenue)))));
        this.getOutputs().year1Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.year1Revenue)))));
        this.getOutputs().year2Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.year2Revenue)))));
        this.getOutputs().year3Raw.innerItems[2].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonRevenue.year3Revenue)))));
        this.getOutputs().lineChartGenaration(parseFloat(0),parseFloat(jsonRevenue.month0to3Revenue).toFixed(0),parseFloat(jsonRevenue.month4to6Revenue).toFixed(0),parseFloat(jsonRevenue.month7to9Revenue).toFixed(0),parseFloat(jsonRevenue.month10to12Revenue).toFixed(0));

    },

    printDirectCostDetailReport : function(jsonDirectCosts){

        this.getOutputs().month0to3Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.month0to3DirectCosts)))));
        this.getOutputs().month4to6Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.month4to6DirectCosts)))));
        this.getOutputs().month7to9Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.month7to9DirectCosts)))));
        this.getOutputs().month10to12Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.month10to12DirectCosts)))));
        this.getOutputs().year1Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.year1DirectCosts)))));
        this.getOutputs().year2Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.year2DirectCosts)))));
        this.getOutputs().year3Raw.innerItems[3].setValue(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonDirectCosts.year3DirectCosts)))));

    },
    printNetInComeDetailReport : function(jsonNetInCome){
       // var objNetInCome = JSON.parse(jsonNetInCome);
        this.getOutputs().month0to3Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.month0to3NetIncome)))), parseFloat(jsonNetInCome.month0to3NetIncome)));
        this.getOutputs().month4to6Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.month4to6NetIncome)))), parseFloat(jsonNetInCome.month4to6NetIncome)));
        this.getOutputs().month7to9Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.month7to9NetIncome)))), parseFloat(jsonNetInCome.month7to9NetIncome)));
        this.getOutputs().month10to12Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.month10to12NetIncome)))), parseFloat(jsonNetInCome.month10to12NetIncome)));
        this.getOutputs().year1Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.year1NetIncome)))), parseFloat(jsonNetInCome.year1NetIncome)));
        this.getOutputs().year2Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.year2NetIncome)))), parseFloat(jsonNetInCome.year2NetIncome)));
        this.getOutputs().year3Raw.innerItems[4].setValue(this.addBrackets(this.removeDecimal(this.onFormatCurrency(this.roundToInteger(parseFloat(jsonNetInCome.year3NetIncome)))), parseFloat(jsonNetInCome.year3NetIncome)));
    },

    onHeadlineReportSelected: function () {
        this.getOutputs().switchToHeadlineReport();
    },

    onDetailReportSelected: function () {
        this.getOutputs().switchToDetailReport();
    },
    launch: function () {
        this.callParent();
        this.launched = false;
        Ext.Viewport.on({
            scope: this
        });


        var financingOptions = this.getFinancingOptions();
        financingOptions.on({
            scope: this,
            detailReportSelected: this.onDetailReportSelected,
            headlineReportSelected: this.onHeadlineReportSelected
        });
    }
});
