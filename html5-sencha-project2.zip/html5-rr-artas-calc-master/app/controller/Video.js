Ext.define('RestorationRoboticsArtasCalculator.controller.Video', {
    extend: 'RestorationRoboticsArtasCalculator.controller.BaseController',
    requires: [
    ],
    config: {
        refs: {
            videoView: 'videoview',
            navBar: 'navbar',
            main:'main'
        }
    },
    onPaintedVideoView: function () {
        var videoView = this.getVideoView();
        var navbar = this.getNavBar();
        videoView.mainVideo.play();
        videoView.mainVideo.media.show();
        navbar.hide();
    },
    onPauseVideo: function () {
        var videoView = this.getVideoView();
        var navbar = this.getNavBar();
        if (videoView.mainVideo.getCurrentTime() === videoView.mainVideo.getDuration()) {
            videoView.videoContainerWrapper.hide();
            navbar.show();
        }
    },
    onSkipVideo: function () {
        var videoView = this.getVideoView();
        var navbar = this.getNavBar();
        videoView.mainVideo.pause();
        videoView.videoContainerWrapper.hide();
        navbar.show();
    },
    onVideoStartUp: function (value) {
        var videoDetails = Ext.getStore('videodetails');
        var videoDetailsModel = Ext.create('RestorationRoboticsArtasCalculator.model.Video');
        videoDetails.removeAll();
        videoDetailsModel.set('videoSkip', value);
        videoDetails.add(videoDetailsModel);
        videoDetails.sync();
    },
    onVideoStartUpCheck: function (value) {

        var videoView = this.getVideoView();
        var navbar = this.getNavBar();

        if (value) {
            setTimeout(function () {
                navbar.show();
            }, 10);

        }

    },

    launch: function () {
        this.callParent();
        var videoView = this.getVideoView();
        videoView.on({
            scope: this,
            paintedVideoView: this.onPaintedVideoView,
            pauseVideo: this.onPauseVideo,
            skipVideo: this.onSkipVideo,
            videoStartUp: this.onVideoStartUp

        });

        Ext.Viewport.on({
            scope: this,
            videoStartUpCheck: this.onVideoStartUpCheck
        });
    }
});
