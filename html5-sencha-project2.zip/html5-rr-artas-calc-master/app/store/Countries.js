Ext.define('RestorationRoboticsArtasCalculator.store.Countries', {
    extend: 'Ext.data.Store',
    config: {
        model: 'RestorationRoboticsArtasCalculator.model.Country',
        remoteSort: true,
        proxy: {
            type: 'ajax',
            url : 'resources/data/countries.json',
            reader: {
                type: 'json',
                rootProperty: 'countries'
            },
            root: 'countries'
        }
    }
});