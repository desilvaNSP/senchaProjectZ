Ext.define('RestorationRoboticsArtasCalculator.store.PracticeInformation', {
    extend: 'Ext.data.Store',
   config: {
        storeId: 'PracticeInformation',

        model: 'RestorationRoboticsArtasCalculator.model.PracticeInformation'

    }
});
