Ext.define('RestorationRoboticsArtasCalculator.store.States', {
    extend: 'Ext.data.Store',
   config: {
        model: 'RestorationRoboticsArtasCalculator.model.States',
        remoteSort: true,
        proxy: {
            type: 'ajax',
            url : 'resources/data/states.json',
            reader: {
                type: 'json',
                rootProperty: 'states'              
            },
            root: 'states' 
        }
    }
});
