/**
 * Created by eranjan on 6/30/14.
 */
Ext.define('RestorationRoboticsArtasCalculator.store.Assets', {
    extend: 'Ext.data.Store',
    config: {
        storeId: 'Assets',
        model: 'RestorationRoboticsArtasCalculator.model.Asset'
    }
});
