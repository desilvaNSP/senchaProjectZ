Ext.define('RestorationRoboticsArtasCalculator.model.Output', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            { name: 'month0to3Applications', type: 'string' },
            { name: 'month4to6Applications', type: 'string' },
            { name: 'month7to9Applications', type: 'string' },
            { name: 'month10to12Applications', type: 'string' },
            { name: 'year1Applications', type: 'string' },
            { name: 'year2Applications', type: 'string' },
            { name: 'year3Applications', type: 'string' },

            { name: 'month0to3Revenue', type: 'string' },
            { name: 'month4to6Revenue', type: 'string' },
            { name: 'month7to9Revenue', type: 'string' },
            { name: 'month10to12Revenue', type: 'string' },
            { name: 'year1Revenue', type: 'string' },
            { name: 'year2Revenue', type: 'string' },
            { name: 'year3Revenue', type: 'string' },

            { name: 'month0to3DirectCosts', type: 'string' },
            { name: 'month4to6DirectCosts', type: 'string' },
            { name: 'month7to9DirectCosts', type: 'string' },
            { name: 'month10to12DirectCosts', type: 'string' },
            { name: 'year1DirectCosts', type: 'string' },
            { name: 'year2DirectCosts', type: 'string' },
            { name: 'year3DirectCosts', type: 'string' },


            { name: 'month0to3NetIncome', type: 'string' },
            { name: 'month4to6NetIncome', type: 'string' },
            { name: 'month7to9NetIncome', type: 'string' },
            { name: 'month10to12NetIncome', type: 'string' },
            { name: 'year1NetIncome', type: 'string' },
            { name: 'year2NetIncome', type: 'string' },
            { name: 'year3NetIncome', type: 'string' }
        ]
    }
});
