Ext.define('RestorationRoboticsArtasCalculator.model.Video', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'videoSkip', type: 'boolean', defaultValue:'true' }
        ],
        proxy: {
            type: 'localstorage',
            id: 'video-settings'
        }
    }
});