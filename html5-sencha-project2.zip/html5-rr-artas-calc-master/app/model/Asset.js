/**
 * Created by eranjan on 6/30/14.
 */
Ext.define('RestorationRoboticsArtasCalculator.model.Asset', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'itemId', type: 'string'},
            { name: 'title', type: 'string' },
            { name: 'description', type: 'string'},
            { name: 'imagePath', type: 'string'}
        ]
    }
});
