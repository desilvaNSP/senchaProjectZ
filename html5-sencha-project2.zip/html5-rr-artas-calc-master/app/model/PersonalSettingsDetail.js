Ext.define('RestorationRoboticsArtasCalculator.model.PersonalSettingsDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'id', type: 'int' },
            { name: 'repName', type: 'string'},
            { name: 'phoneNumber', type: 'string'},
            { name: 'email', type: 'string'}
        ],
        validations: [
            {type: 'presence', field: 'repName', message: 'Rep name'},
            {type: 'presence', field: 'phoneNumber', message: 'Phone number'},
            {type: 'email', field: 'email', message: 'Valid Email Address'}

        ],
        proxy: {
            type: 'localstorage',
            id: 'personal-settings'
        }
    }
});