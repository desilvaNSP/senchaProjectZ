Ext.define('RestorationRoboticsArtasCalculator.model.PracticeInformation', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            {name: 'physician', type: 'string', defaultValue: ''},
            {name: 'addressOne', type: 'string', defaultValue: ''},
            {name: 'addressTwo', type: 'string', defaultValue: ''},
            {name: 'city', type: 'string', defaultValue: ''},
            {name: 'country', type: 'string', defaultValue: ''},
            {name: 'region', type: 'string', defaultValue: ''},
            {name: 'zip', type: 'string', defaultValue: ''},
            {name: 'currencyExchange', type: 'string', defaultValue: ''}
        ]
        ,
        validations: [
            {type: 'presence', field: 'currencyExchange', message: 'Currency Exchange'},
            {type: 'presence', field: 'physician', message: 'Physician\'s Name'},
            {type: 'presence', field: 'addressOne', message: 'Address Line One'},
            {type: 'presence', field: 'country', message: 'Country'}

        ]
    
    }
});
