Ext.define('RestorationRoboticsArtasCalculator.model.ArtasProcedureDetail', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'artasHACost', type: 'string'},
            { name: 'otherCost', type: 'string'},
            { name: 'otherCostAmount', type: 'string'},
            { name: 'pricingStrategy', type: 'string'},
            { name: 'grafts', type: 'string'},
            { name: 'price', type: 'string'},
            { name: 'pricePerApplication', type: 'string', defaultValue: '0'}
        ]
        ,
         validations: [
            { type: 'presence', field: 'artasHACost', message: 'Harvest Average Cost' },
//            { type: 'presence', field: 'otherCost', message: 'Other Cost' },
//            { type: 'presence', field: 'otherCostAmount', message: 'Cost Amount' },
            { type: 'presence', field: 'pricingStrategy', message: 'Pricing Strategy' },
            { type: 'presence', field: 'price', message: 'Price' },
            { type: 'presence', field: 'grafts', message: 'Grafts/Procedures' }

        ]

    },
    calculate: function () {
        var data = this.getData();
        data.artasHACost = this.formatCurrency(this.cleanCurrency(data.artasHACost));
        data.otherCostAmount = this.formatCurrency(this.cleanCurrency(data.otherCostAmount));
        data.price = this.formatCurrency(this.cleanCurrency(data.price));
        if (data.pricingStrategy === 'perGraph') {
            data.pricePerApplication = data.price;
        }
        else if (data.pricingStrategy === 'PerProcedure') {
            var ppa = this.cleanCurrency(data.price) / parseFloat(data.grafts);
            data.pricePerApplication = this.formatCurrency(ppa.toFixed(2));
            if (isNaN(data.pricePerApplication)) {
                data.pricePerApplication = '';
            }
        }
    },
    formatCurrency: function (number) {
        //adding $ sign and commas to the currency
        return '$' + parseFloat(number).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
    cleanCurrency: function (number) {
        //cleaning the currency, removing $ sign and commas
        if (number[0] === '$') {
            return parseFloat(number.substring(1).split(',').join(''));
        }
        else {
            return parseFloat(number.split(',').join(''));
        }
    }
})
;
