Ext.define('RestorationRoboticsArtasCalculator.model.Country', {
    extend: 'Ext.data.Model',
    config: {
        fields: ['name', 'code']
    }
});