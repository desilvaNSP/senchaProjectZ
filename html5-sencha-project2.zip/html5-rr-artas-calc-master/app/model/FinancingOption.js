Ext.define('RestorationRoboticsArtasCalculator.model.FinancingOption', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            {name: 'buyOptions', type: 'string', defaultValue: 'buy'},
            {name: 'oneTimePayment', type: 'string'},
            {name: 'financeTerm', type: 'string', defaultValue: '0'},
            {name: 'downPayment', type: 'string', defaultValue: 'default'},
            {name: 'interestTerm', type: 'string', defaultValue: '0'},
            {name: 'monthlyPayment', type: 'string'},
            {name: 'BuyResultOptions', type: 'string', defaultValue: 'detailsReport'},
            {name: 'FinanceResultOptions', type: 'string', defaultValue: 'detailsReport'}
        ]
        ,
        validations: [
            {type: 'presence', field: 'buyOptions', message: ' Buy option'},
            {type: 'presence', field: 'oneTimePayment', message: 'One Time Payment'},
            {type: 'presence', field: 'financeTerm', message: 'Finance Term'},
            {type: 'presence', field: 'downPayment', message: 'Down Payment'},
            {type: 'presence', field: 'interestTerm', message: 'Interest Term'},
            {type: 'presence', field: 'BuyResultOptions', message: 'Buy Result Option'},
            {type: 'presence', field: 'FinanceResultOptions', message: 'Finance Result Option'}
        ]
    }
});
