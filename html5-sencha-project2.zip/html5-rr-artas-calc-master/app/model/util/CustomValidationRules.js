/**
 * Adds custom validation rules to {@link #Ext.data.Validations} singleton
 * if they do not exist in the destination.
 * @return True of False based on the validation.
 *
 * Note: Since the date parsing behavior in Javascript does not support on
 * older versions of Safari, string manipulation methods have used to create Date object.
 */

Ext.define('RestorationRoboticsArtasCalculator.model.util.CustomValidationRules', {
    singleton: true,

    load: function () {
        //TODO: Check the validation functions.
//        Ext.applyIf(Ext.data.Validations, {
//            surgery_dateMessage: 'Please enter a valid Surgery Date.',
//            surgery_date: function (config, value, formData) {
//                var date = new Date();
//                var today = new Date(date.getFullYear(), ('0' + (date.getMonth() + 1)).slice(-2),
//                    ('0' + date.getDate()).slice(-2));
//                var formattedValue = value.split('-');
//                var surgeryDate = new Date(formattedValue[0], formattedValue[1], formattedValue[2]);
//
//                if (value) {
//                    return ((surgeryDate >= today));
//                }
//                return true;
//            },
//
//            sec_surgery_dateMessage: 'Please enter a valid Secondary Date.',
//            sec_surgery_date: function (config, value, formData) {
//                var date = new Date();
//                var today = new Date(date.getFullYear(), ('0' + (date.getMonth() + 1)).slice(-2),
//                    ('0' + date.getDate()).slice(-2));
//                var formattedValue = value.split('-');
//                var secSegDate = new Date(formattedValue[0], formattedValue[1], formattedValue[2]);
//
//                if (value) {
//                    if (formData.get('date_of_surgery')) {
//                        var formattedSurgDate = formData.get('date_of_surgery').split('-');
//                        var surgeryDate = new Date(formattedSurgDate[0], formattedSurgDate[1], formattedSurgDate[2]);
//                        return !!((secSegDate >= today && secSegDate >= surgeryDate));
//                    }
//                }
//                return true;
//            },
//
//            restoration_dateMessage: 'Please enter a valid Restoration Date.',
//            restoration_date: function (config, value, formData) {
//                var date = new Date();
//                var today = new Date(date.getFullYear(), ('0' + (date.getMonth() + 1)).slice(-2),
//                    ('0' + date.getDate()).slice(-2));
//                var formattedRecResDate = value.split('-');
//                var recResDate = new Date(formattedRecResDate[0], formattedRecResDate[1], formattedRecResDate[2]);
//                var lastDate = null;
//
//                if (formData.get('date_of_sec_surgery') !== '') {
//                    lastDate = formData.get('date_of_sec_surgery');
//                }
//                else if (formData.get('date_of_surgery') !== '') {
//                    lastDate = formData.get('date_of_surgery');
//                }
//
//                if (value && lastDate !== null) {
//                    var formattedLastDay = lastDate.split('-');
//                    lastDate = new Date(formattedLastDay[0], formattedLastDay[1], formattedLastDay[2]);
//                    return !!((recResDate >= today && recResDate >= lastDate));
//                }
//                return true;
//            }
//        });
    }
});