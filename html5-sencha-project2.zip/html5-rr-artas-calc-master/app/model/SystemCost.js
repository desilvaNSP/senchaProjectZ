Ext.define('RestorationRoboticsArtasCalculator.model.SystemCost', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'systemPrice', type: 'string'},
            { name: 'tax', type: 'string'},
            { name: 'totalInvestment', type: 'string'},
            { name: 'shipping', type: 'string' },
           { name: 'machine', type: 'string',defaultValue: '300000'},
            { name: 'trainingA', type: 'string',defaultValue: '50000'},
            { name: 'trainingB', type: 'string',defaultValue: '30000'},
            { name: 'procedurePackage', type: 'string',defaultValue: '30000'},
            { name: 'practiceDev', type: 'string',defaultValue: '20000'},
            { name: 'services', type: 'string',defaultValue: '20000'}

        ]
        ,
        validations: [
            {type: 'presence', field: 'systemPrice', message: 'System Cost'}
        ]
    }
});
// { name: 'machine', type: 'string',defaultValue: '300,000'},
//            { name: 'trainingA', type: 'string',defaultValue: '50,000'},
//            { name: 'trainingB', type: 'string',defaultValue: '30,000'},
//            { name: 'procedurePackage', type: 'string',defaultValue: '30,000'},
//            { name: 'practiceDev', type: 'string',defaultValue: '20,000'},
//            { name: 'services', type: 'string',defaultValue: '20,000'}