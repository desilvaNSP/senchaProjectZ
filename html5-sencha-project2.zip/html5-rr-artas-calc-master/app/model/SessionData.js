Ext.define('RestorationRoboticsArtasCalculator.model.SessionData', {
    practiceInformation: '',
    opportunityDetail: '',
    artasProcedureDetail: '',
    financingOption: '',
    harvestPayment: '',
    systemCost: '',
    output:'',
    personalSettingsDetail: ''
});
