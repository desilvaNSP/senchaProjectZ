Ext.define('RestorationRoboticsArtasCalculator.model.HarvestPayment', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'patientPricePerHarvest', type: 'string'},
            { name: 'costPaidPerHarvest', type: 'string'},
            { name: 'averageHarvestsPerProcedure', type: 'string'}
        ]


    }
});
