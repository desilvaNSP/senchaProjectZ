Ext.define('RestorationRoboticsArtasCalculator.model.OpportunityDetail', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            {name: 'cases', type: 'string', defaultValue: 'casesWeek'},
            {name: 'month1to3', type: 'string'},
            {name: 'month4to6', type: 'string'},
            {name: 'month7to9', type: 'string'},
            {name: 'month10to12', type: 'string'}
        ]
        ,
        validations: [
            {type: 'presence', field: 'cases', message: 'Case Option'},
            {type: 'presence', field: 'month1to3', message: 'Month 1 to 3'},
            {type: 'presence', field: 'month4to6', message: 'Month 4 to 6'},
            {type: 'presence', field: 'month7to9', message: 'Month 7 to 9'},
            {type: 'presence', field: 'month10to12', message: 'Month 10 to 12'}

        ]
    }
});
