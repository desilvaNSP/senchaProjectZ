Ext.define('RestorationRoboticsArtasCalculator.model.States', {
    extend: 'Ext.data.Model',
    config: {
        fields: ['abbr', 'state']
    }
});