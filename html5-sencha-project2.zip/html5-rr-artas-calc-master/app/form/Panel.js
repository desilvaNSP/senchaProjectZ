Ext.define('RestorationRoboticsArtasCalculator.form.Panel', {
    extend: 'Ext.form.Panel',
    xtype: 'roboticsartascalcformpanel',
    validationPassed: true,

    disappear: function () {
//        this.fireEvent('onDisappear', this);
        validationPassed = true;
    }
});