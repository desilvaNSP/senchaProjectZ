(function(w, d) {
    var api = {
        initApi: function(success, failure) {
            dispatch("initApi", {}, success, failure);
        },
        printAsset: function(id, success, failure) {
            dispatch("printAsset", {assetId: id}, success, failure);
        },
        emailAsset: function(id, success, failure) {
            dispatch("emailAsset", {assetId: id}, success, failure);
        },
        viewAsset: function(id, success, failure) {
            dispatch("viewAsset", {assetId: id}, success, failure);
        },
        getAssetPath: function(id, success, failure) {
            dispatch("getAssetPath", {assetId: id}, success, failure);
        },
        trackSection: function(sectionName, success, failure) {
            var arguments = {"eVar17": sectionName, "events": "event14"};
            this.trackEvent(arguments, success, failure);
        },
        emailMessage: function(emailObj, success, failure)
        {
            var jsonEmailObject;

            try
            {
                jsonEmailObject = JSON.parse(emailObj)
                dispatch("emailMesssage", jsonEmailObject, success, failure);
            }
            catch (err)
            {
                alert(err.message);
            }
        },
        readFileAtPath: function(filePath, success, failure)
        {
            dispatch("readFileAtPath", filePath, success, failure);
        },
        convertHTMLToPDF: function(htmlString, success, failure)
        {
            dispatch("convertHTMLToPDF", htmlString, success, failure);
        },
        getPathForConvertedPDFFileFromHTML: function(htmlString, success, failure)
        {
            dispatch("getPathForConvertedPDFFileFromHTML", htmlString, success, failure);
        },
        getOfflineLinksForAssets: function(assetslist, success, failure)
        {
            dispatch("getOfflineLinksForAssets", {assets: assetslist}, success, failure);
        },
        saveFile: function(fileObject, success, failure)
        {
            dispatch("saveFile", fileObject, success, failure);
        },
        emailWithMultipleAssets: function(emailObject, success, failure)
        {
            dispatch("emailWithMultipleAssets", emailObject, success, failure);
        },
        trackEvent :function (arguments, success, failures) 
        {
            dispatch("trackEvent", arguments, success, failures);
        },
        getCommand: function(key) {
            var cmd = _commands[key];
            return JSON.stringify(cmd);
        },
        callback: function(key, success, result) {
            var cmd = _commands[key];
            if (success) {
                cmd.success(result);
            }
            else {
                cmd.failure(result);
            }
            delete _command[key];
        }
    };

    var _commands = {};
    var _commandId = 0;

    function dispatch(command, arguments, successCallback, faliureCallback) {
        var key = "n" + (++_commandId);
        var commandObject = {cmd: command, args: arguments, success: successCallback, failure: faliureCallback};
        _commands[key] = commandObject;
        notify(key);
    }

    function notify(key) {
        var iframe = d.createElement("IFRAME");
        iframe.setAttribute("src", "macs://" + key);
        d.documentElement.appendChild(iframe);
        iframe.parentNode.removeChild(iframe);
    }

    currentState = {
        getKeyPath: function(path) {
            var pathComponentsArray = path.split("/");
            return pathComponentsArray[pathComponentsArray.length - 2];
        },
        createCookie: function(key, value) {
            var date = new Date();
            date.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
            var expires = "; expires=" + date.toGMTString();
            document.cookie = key + "=" + value + expires + "; path=/";
        },
        readCookie: function(key) {
            var nameEQ = key + "=";
            var ca = document.cookie.split(';');

            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ')
                    c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0)
                    return c.substring(nameEQ.length, c.length);
            }
            return "";
        },
        eraseCookie: function(key) {
            currentState.createCookie(key, "");
        }

    };

    w.macs = api;

})(window, document);