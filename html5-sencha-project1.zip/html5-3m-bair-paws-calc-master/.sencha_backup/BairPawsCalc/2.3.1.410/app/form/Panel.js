Ext.define('BairPawsCalc.form.Panel', {
    extend: 'Ext.form.Panel',
    xtype: 'bairpawscalcformpanel'
    
});