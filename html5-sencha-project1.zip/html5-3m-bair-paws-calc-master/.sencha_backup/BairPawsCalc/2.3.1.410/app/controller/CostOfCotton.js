Ext.define('BairPawsCalc.controller.CostOfCotton', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    newkitCosts : null,
    kitCosts : null,
    config: {
        refs: {
            costOfCottonView: 'costofcottonview',
            barChartView: 'barchartview',
            main: 'main',
            newBpKitCostsView: 'newbpkitcostsview',
            additionalKitCosts: 'additionalkitcosts',
            initialview: 'initialview'
        }
    },
    onDisappear: function () {


        var calculatorController = this.getApplication().getController('Calculator');
        if (calculatorController.sessionData.cottonCostDetail) {
            calculatorController.sessionData.cottonCostDetail.destroy();
        }
        if (calculatorController.sessionData.annualCostDetail) {
            calculatorController.sessionData.annualCostDetail.destroy();
        }
        if (calculatorController.sessionData.practiceCostDetail) {
            calculatorController.sessionData.practiceCostDetail.destroy();
        }
        calculatorController.sessionData.cottonCostDetail = Ext.create('BairPawsCalc.model.CottonCostDetail', this.getCostOfCottonView().formCostOfCottonView.getValues());


        var disableFields = [];
        var modelNumber = this.getApplication().getController('Calculator').sessionData.customerDetail.get('modelNumber');

        var currentCustomer = this.getApplication().getController('Calculator').sessionData.customerDetail.get('currentCustomer');
        if (currentCustomer === 'currentCustomer') {
            if (!this.onCheckedBlanketBase(modelNumber)) {
                disableFields.push("airWarmingCost");
            }
        }


        if (this.validateFields(calculatorController.sessionData.cottonCostDetail, disableFields)) {
         //   var currentCustomer = this.getApplication().getController('Calculator').sessionData.customerDetail.get('currentCustomer');
            calculatorController.sessionData.practiceCostDetail = Ext.create('BairPawsCalc.model.PracticeCostDetail', this.getCostOfCottonView().formLeftCurrentPracticeCosts.getValues());
            calculatorController.sessionData.annualCostDetail = Ext.create('BairPawsCalc.model.AnnualCostDetail', this.getCostOfCottonView().formRightCurrentPracticeCosts.getValues());
            if (currentCustomer !== 'currentCustomer') {
                calculatorController.calculateCurrentPracticeCosts(true);
            }

            return true;
        }
        else {
            return false;
        }

    },

    onCalculateValues: function () {
        var calculatorController = this.getApplication().getController('Calculator');
        calculatorController.calculateCurrentPracticeCosts();
    },
    onAdditionalCostCheckBoxChanged: function (name) {
        console.log(name);
//
//

        var currentCustomer = this.getApplication().getController('Calculator').sessionData.customerDetail.get('currentCustomer');
        var additionalkitcosts = this.getAdditionalKitCosts();



        var overlay = this.getCostOfCottonView().overlay;
        if (currentCustomer !== 'currentCustomer') {
            additionalkitcosts.formAdditionalKitCostsView.items.each(function (itm) {
                itm.setDisabled(false);
            });

        }
        overlay.passedButtonName = name;
                if(name ==='kitCosts'){
                    if(this.kitCosts) {
                        additionalkitcosts.formAdditionalKitCostsView.setValues(this.kitCosts);
                    }

        }else if(name === 'newKitCosts'){

                    if(this.newkitCosts){
                        additionalkitcosts.formAdditionalKitCostsView.setValues(this.newkitCosts);
                    }


        }
        overlay.show();



    },
    onChangeCustomerAndModelStatus: function () {
        var additionalkitcosts = this.getAdditionalKitCosts();
        additionalkitcosts.formAdditionalKitCostsView.reset();
        this.kitCosts = null;
        this.getCostOfCottonView().formCostOfCottonView.down('field[name=kitCosts]').uncheck();
    },

    onSaveValues:function(view,buttonName){
         var additionalkitcosts = this.getAdditionalKitCosts();
        if(buttonName ==='kitCosts'){
        this.kitCosts = additionalkitcosts.formAdditionalKitCostsView.getValues();
            console.log(this.kitCosts);
        }else if(buttonName === 'newKitCosts'){
        this.newkitCosts = additionalkitcosts.formAdditionalKitCostsView.getValues();
            console.log(this.newkitCosts);
        }
    },

    launch: function () {
        var costOfCotton = this.getCostOfCottonView();
        var newBpKitCostsView = this.getNewBpKitCostsView();
        var initialView = this.getInitialview();

        costOfCotton.on({
            scope: this,
            disappear: this.onDisappear,
            calculateValues: this.onCalculateValues,
            additionalCostCheckBoxChanged: this.onAdditionalCostCheckBoxChanged,
            saveValues : this.onSaveValues

        });

        newBpKitCostsView.on({
            scope: this,
            additionalCostCheckBoxChanged: this.onAdditionalCostCheckBoxChanged
        });

        initialView.on({
            scope: this,
            changeCustomerAndModelStatus: this.onChangeCustomerAndModelStatus
        });

    }
});
