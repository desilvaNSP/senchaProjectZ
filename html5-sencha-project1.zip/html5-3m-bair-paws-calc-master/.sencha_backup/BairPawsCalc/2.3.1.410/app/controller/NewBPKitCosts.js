Ext.define('BairPawsCalc.controller.NewBPKitCosts', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    config: {
        refs: {
            newBPKitCostsView: 'newbpkitcostsview',
            additionalKitCosts: 'additionalkitcosts',
            initialView: 'initialview',
            costOfCottonView: 'costofcottonview'
        }
    },
    onCalculateValues: function () {

    },
    onDisappear: function () {
        var calculatorController = this.getApplication().getController('Calculator');
        calculatorController.sessionData.newBPKitCosts = Ext.create('BairPawsCalc.model.NewBPKitCosts', this.getNewBPKitCostsView().formPanelBPKitCosts.getValues());

        var disableFields = [];
       var  modelNo = this.getNewBPKitCostsView().formPanelBPKitCosts.down('field[name=modelNumber]').getValue();
        console.log(modelNo);
        if(!this.onCheckedBlanketBase(modelNo)){
             disableFields.push("avgcostforcedairblanket");
        }

        if (this.validateFields(calculatorController.sessionData.newBPKitCosts,disableFields)) {
            console.log('calcualting costs - new BP')
            calculatorController.calculateCurrentPracticeCosts(true);
            return true;
        }
        else {
            return false;
        }


    },

    onkitCostChecked: function (modelNumber) {
        var modelNo;
        var textFieldMessage = 'Included in this model';
        if (modelNumber === "flag") {
            modelNo = this.getInitialView().formPanelInitialView.down('field[name=modelNumber]').getValue();
        } else {
            modelNo = modelNumber;
        }

       var currentCustomerSelection = this.getInitialView().formPanelInitialView.down('field[name=currentCustomer]').getValue();
        var returnKitCostArray = this.onCheckedKitCostBase(modelNo, "kitCosts");
        var additionalkitcosts = this.getAdditionalKitCosts();

        additionalkitcosts.formAdditionalKitCostsView.items.each(function (itm) {
            itm.setDisabled(false);
        });
        var allTextField  = [];
        allTextField.push( "bonnet", "booties", "garmentBag", "shoeBag");
         Ext.each(allTextField, function (value) {
             var selectedFiledForm = additionalkitcosts.formAdditionalKitCostsView.down('field[name=' + value + ']');
             selectedFiledForm.setPlaceHolder('Enter Value');
         });
        Ext.each(returnKitCostArray, function (value) {
            if (value !== "" ) {
                var selectedFiled = additionalkitcosts.formAdditionalKitCostsView.down('field[name=' + value + ']');
                if(currentCustomerSelection === 'currentCustomer'){
                   selectedFiled.setValue(textFieldMessage);
                    selectedFiled.disable();
                }else{
                    selectedFiled.setPlaceHolder("Enter Value");
                    selectedFiled.enable();
                }

            }

        });
    },
    onChageStatusOnNewModel: function (modelNumber) {
        var textFieldMessage = 'Included in this model';
        var additionalkitcosts = this.getAdditionalKitCosts();
        additionalkitcosts.formAdditionalKitCostsView.reset();

        this.getApplication().getController('CostOfCotton').newkitCosts = null;

        var calculatorController = this.getApplication().getController('Calculator');
        var formPanelBPKitCosts = this.getNewBPKitCostsView().formPanelBPKitCosts;
        formPanelBPKitCosts.down('field[name=newKitCosts]').uncheck();
        calculatorController.newBPKitCosts.set('newKitCosts', '0');
        var returnKitCostArray = this.onCheckedKitCostBase(modelNumber, "kitCosts");
        Ext.each(returnKitCostArray, function (value) {
            console.log(value);
            if (returnKitCostArray.length === 4) {
                 formPanelBPKitCosts.innerItems[2].disable();
                formPanelBPKitCosts.innerItems[3].show();
            } else {
                formPanelBPKitCosts.innerItems[2].enable();
                formPanelBPKitCosts.innerItems[3].hide();
            }
        });
        var avgCostForcedAirBlanket = formPanelBPKitCosts.down('field[name=avgcostforcedairblanket]');

        if(!this.onCheckedBlanketBase(modelNumber)){
            avgCostForcedAirBlanket.disable();
            avgCostForcedAirBlanket.setValue("");
            avgCostForcedAirBlanket.setPlaceHolder(textFieldMessage);
        }else{
            avgCostForcedAirBlanket.enable();
            avgCostForcedAirBlanket.setPlaceHolder("Enter Value");
        }

    },

    launch: function () {
        var newBPKitCostsView = this.getNewBPKitCostsView();
        var costOfCottonView = this.getCostOfCottonView();

        newBPKitCostsView.on({
            scope: this,
            disappear: this.onDisappear,
            calculateValues: this.onCalculateValues,
            kitCostChecked: this.onkitCostChecked,
            chageStatusOnNewModel: this.onChageStatusOnNewModel
        });

        costOfCottonView.on({
            scope: this,
            kitCostChecked: this.onkitCostChecked
        });


    }
});
