Ext.define('BairPawsCalc.controller.PersonalSettings', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ]
});
