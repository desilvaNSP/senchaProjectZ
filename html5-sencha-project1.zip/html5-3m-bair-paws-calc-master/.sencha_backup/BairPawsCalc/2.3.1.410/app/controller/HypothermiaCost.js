Ext.define('BairPawsCalc.controller.HypothermiaCost', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    config: {
        refs: {
            hypothermiaCostsView: 'hypothermiacostsview'
        }
    },
    onCalculateValues : function () {
        var calculatorController = this.getApplication().getController('Calculator');
         calculatorController.calculateHypothermiaCosts();
    },
    onDisappear : function () {
        var calculatorController = this.getApplication().getController('Calculator');

        if(calculatorController.sessionData.hypothermiaCostsDetail) {
            calculatorController.sessionData.hypothermiaCostsDetail.destroy();
        }
        if(calculatorController.sessionData.complicationsDetail) {
            calculatorController.sessionData.complicationsDetail.destroy();
        }
        calculatorController.sessionData.hypothermiaCostsDetail = Ext.create('BairPawsCalc.model.HypothermiaCostDetail',this.getHypothermiaCostsView().formHypothermiaCosts.getValues());
        calculatorController.sessionData.complicationsDetail = Ext.create('BairPawsCalc.model.ComplicationsDetail',this.getHypothermiaCostsView().formComplications.getValues());
        var disableFields = [];


        if(this.validateFields(calculatorController.sessionData.hypothermiaCostsDetail,disableFields)) {
            if(this.validateFields(calculatorController.sessionData.complicationsDetail,disableFields)) {
                calculatorController.calculateTotalCost();
                calculatorController.renderFinalChart();
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },

    launch: function () {
        var hypothermiaCostsView = this.getHypothermiaCostsView();
//calculateValues: this.onCalculateValues
        hypothermiaCostsView.on({
            scope: this,
            disappear: this.onDisappear,
            calculateValues: this.onCalculateValues
//            onMainInit: this.onMainInit
                    //diameterSelectionInitAction: this.onDiameterSelectionInitAction
        });
    }
});
