Ext.define('BairPawsCalc.controller.Calculator', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    sessionData: '',
    perPatientChatData: '',
    newBPKitCosts: '',

//annualCostDetail: '',
//    cottonCostDetail: '',
//    customerDetail: '',
//    practiceCostDetail: '',
//    volumeDetail: '',
//    hypothermiaCostsDetail: '',
//    complicationsDetail: '',
//    totalCostDetail: ''
    config: {
        refs: {
            initialView: 'initialview',
            main: 'main',
            costOfCottonView: 'costofcottonview',
            hypothermiaCostsView: 'hypothermiacostsview',
            barChartView: 'barchartview',
            chartView: 'chartview',
            resultView: 'resultview',
            additionalKitCosts: 'additionalkitcosts',
            volumeFieldView: 'volumefieldview',
            newBpKitCostsView:'newbpkitcostsview'
        }
    },
    costSavings: 0,

    onCalculateKitCosts: function () {
        var additionalKitCosts = this.getAdditionalKitCosts(),
            costOfCottonView = this.getCostOfCottonView(),
            surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2),
            bonnetCost = this.checkIsNaN(this.onCleanCurrency(additionalKitCosts.formAdditionalKitCostsView.down('field[name=bonnet]').getValue())),
            bootiesCost = this.checkIsNaN(this.onCleanCurrency(additionalKitCosts.formAdditionalKitCostsView.down('field[name=booties]').getValue())),
            garmentBagCost = this.checkIsNaN(this.onCleanCurrency(additionalKitCosts.formAdditionalKitCostsView.down('field[name=garmentBag]').getValue())),
            shoeBagCost = this.checkIsNaN(this.onCleanCurrency(additionalKitCosts.formAdditionalKitCostsView.down('field[name=shoeBag]').getValue())),

            totalKitCost = (bonnetCost + bootiesCost + garmentBagCost + shoeBagCost) * surgeriesPerYear;
        var main = this.getMain();
        var currentPage = main.navigationView.getActiveItem().xtype;

        if (currentPage === "newbpkitcostsview") {
            this.newBPKitCosts.set('newKitCosts', totalKitCost);
        } else {
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').setValue(this.onFormatCurrency(totalKitCost, true, true));
        }

    },

    calculateBpAndLinenKitcosts: function () {
        var that = this;
        var surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2),
            modelNumber = this.sessionData.customerDetail.get('modelNumber'),
            additionalkitcosts = this.getAdditionalKitCosts();
        var BpkitCostsFiledNameArr = [];
        BpkitCostsFiledNameArr.push("bonnet", "booties", "garmentBag", "shoeBag");

        var kitCostsFiledNameArr = this.onCheckedKitCostBase(modelNumber, 'kitCosts');
        console.log(kitCostsFiledNameArr);
        var totalBpAndLinenKitcostsValue = 0;
        Ext.each(kitCostsFiledNameArr, function (value) {
            var index = BpkitCostsFiledNameArr.indexOf(value);
            if (index > -1) {
                BpkitCostsFiledNameArr.splice(index, 1);
            }
        });

        Ext.each(BpkitCostsFiledNameArr, function (value) {
            totalBpAndLinenKitcostsValue += that.checkIsNaN(that.onCleanCurrency(additionalkitcosts.formAdditionalKitCostsView.down('field[name=' + value + ']').getValue()));
        });

        var totalBpAndLinenKitcostsValueFinal = totalBpAndLinenKitcostsValue * surgeriesPerYear;
        return totalBpAndLinenKitcostsValueFinal;

    },

    checkIsNaN: function (number) {
        if (isNaN(number)) {
            return 0;
        }
        else {
            return number;
        }
    },

    calculateCurrentPracticeCosts: function (isChartRender) {
        var costOfCottonView = this.getCostOfCottonView(),
            isCurrentUser = true;
        if (this.sessionData.customerDetail.get('currentCustomer') === 'notCurrentCustomer') {
            isCurrentUser = false;
        }

        var airWarmingBlanketsNo,
            airWarmingCostPerBlanket,
            totalCostForAirWarmingBlankets,
            surgeriesPerYear,
            currentCottonBlanketsPerPatient,
            cottonBlanketsPerPatient,
            avgCostOfCottonBlanket,
            avgCostOfCottonGown,
            totalCottonBlanketsAndGownCost,
            chartBlanketCostWithBairPaws,
            chartBlanketCostWithoutBairPaws,
            additionalKitCosts,
            currentCostOfAGown,
            bairPawsGownKitCost,
            bairPawsGownCost,
            totalAnnualCost,
            avgCostPerPatient,
            data,
            barNames,
            bairPawsGownCostForNewModel,
            totalCostForAirWarmingBlanketsForNewModel,
            costOfBairPawsGownForNewModel,
            avgForcedAirWarmingBlanketForNewModel,
            newBairPawsModelNumber;


        var customerDetailsModelNumber = this.sessionData.customerDetail.get('modelNumber');


        if (!isCurrentUser) {

            //not a Current Customer
            //Calculating Forced Air Warming Costs

            airWarmingBlanketsNo = parseFloat(this.sessionData.volumeDetail.get('airWarmingBlankets')).toFixed(2);


            var airWarmingCostPerBlanketValue = costOfCottonView.formCostOfCottonView.down('field[name=airWarmingCost]').getValue();

            if (airWarmingCostPerBlanketValue === "") {
                airWarmingCostPerBlanket = 0;
            }
            else {
                airWarmingCostPerBlanket = this.onCleanCurrency(airWarmingCostPerBlanketValue);
            }

            totalCostForAirWarmingBlankets = airWarmingBlanketsNo * airWarmingCostPerBlanket;

            //Calculating Cotton blankets and gowns costs
            surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2);
            currentCottonBlanketsPerPatient = parseFloat(this.sessionData.volumeDetail.get('cottonBlanketsCurrent')).toFixed(2);
            cottonBlanketsPerPatient = parseFloat(this.sessionData.volumeDetail.get('cottonBlankets')).toFixed(2);
            avgCostOfCottonBlanket = this.onCleanCurrency(costOfCottonView.formCostOfCottonView.down('field[name=avgCostBlanket]').getValue());
            avgCostOfCottonGown = this.onCleanCurrency(costOfCottonView.formCostOfCottonView.down('field[name=avgCostGown]').getValue());

            chartBlanketCostWithoutBairPaws = currentCottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);
            chartBlanketCostWithBairPaws = cottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);
            totalCottonBlanketsAndGownCost = currentCottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);

            //Calculating other Kit items cost
            additionalKitCosts = 0;
            if (costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').getValue() !== '') {
                additionalKitCosts = this.onCleanCurrency(costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').getValue());
            }

            //Calculating Bair paws gown costs
            currentCostOfAGown = this.onCleanCurrency(this.sessionData.customerDetail.get('currentCost')).toFixed(2);
            bairPawsGownCost = currentCostOfAGown * surgeriesPerYear;

            //Calculating total annual costs
            totalAnnualCost = totalCostForAirWarmingBlankets + totalCottonBlanketsAndGownCost + additionalKitCosts;

            //Calculating average cost per patient
            avgCostPerPatient = totalAnnualCost / surgeriesPerYear;


            //Adding values to the text fields
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=forcedAirWarming]').setValue(this.onFormatCurrency(totalCostForAirWarmingBlankets, true, true));
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=cottonBlanketsGowns]').setValue(this.onFormatCurrency(totalCottonBlanketsAndGownCost, true, true));

            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=bairPawsGown]').setValue(this.onFormatCurrency(bairPawsGownCost, true, true));
            costOfCottonView.formRightCurrentPracticeCosts.down('field[name=totalAnnualCost]').setValue(this.onFormatCurrency(totalAnnualCost, true, true));
            costOfCottonView.formRightCurrentPracticeCosts.down('field[name=averageCostPerPatient]').setValue(this.onFormatCurrency(avgCostPerPatient));

            var TotalBpAndLinenAirWarmingValue;
            var blanketDisability = this.onCheckedBlanketBase(customerDetailsModelNumber);
            if (!blanketDisability) {
                TotalBpAndLinenAirWarmingValue = 0;
            } else {
                TotalBpAndLinenAirWarmingValue = totalCostForAirWarmingBlankets;
            }


            if (isChartRender) {

                var totalValueOfBpLinenLitCosts = this.calculateBpAndLinenKitcosts();

                data = [
                    {
                        "key": "Bair Paws Gowns",
                        "colorCode": "#A901DB",
                        "values": [
                            {
                                "x": 0,
                                "y": 0
                            },
                            {
                                "x": 1,
                                "y": Math.round(bairPawsGownCost)
                            }
                        ]
                    },
                    {
                        "key": "Forced-Air Warming Blankets",
                        "colorCode": "#0431B4",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(totalCostForAirWarmingBlankets),
                                "label": "test"
                            },
                            {
                                "x": 1,
                                "y": Math.round(TotalBpAndLinenAirWarmingValue),
                                "text": "test"
                            }
                        ]
                    },
                    {
                        "key": "Cotton Blankets & Gowns",
                        "colorCode": "#c2d5ee",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(chartBlanketCostWithoutBairPaws)
                            },
                            {
                                "x": 1,
                                "y": Math.round(chartBlanketCostWithBairPaws)
                            }
                        ]
                    },
                    {
                        "key": "Additional Kit Costs",
                        "colorCode": "#DF7401",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(additionalKitCosts)
                            },
                            {
                                "x": 1,
                                "y": Math.round(totalValueOfBpLinenLitCosts)
                            }
                        ]
                    }
                ];

                barNames = [
                    {
                        "name": "Current<br>Practice Costs"
                    },
                    {
                        "name": "Proposed Bair Paws<br>System and Linen"
                    }
                ];
                this.perPatientChatData = [totalCostForAirWarmingBlankets, chartBlanketCostWithoutBairPaws, additionalKitCosts];
                var chartView = this.getChartView();
                chartView.setData(data, barNames, true);
                chartView.showDifference(this.calculateTotals(data,0,1));

            }
        }
        else {
            // current customer


            //Calculating Forced-Air Warming Costs
            console.log(this.sessionData);

            airWarmingBlanketsNo = parseFloat(this.sessionData.volumeDetail.get('airWarmingBlankets')).toFixed(2);
            if (!this.onCheckedBlanketBase(customerDetailsModelNumber)) {
                totalCostForAirWarmingBlankets = 0;
            } else {
                airWarmingCostPerBlanket = this.onCleanCurrency(costOfCottonView.formCostOfCottonView.down('field[name=airWarmingCost]').getValue());
                totalCostForAirWarmingBlankets = airWarmingBlanketsNo * airWarmingCostPerBlanket;
            }


            //Calculating Cotton blankets and gowns costs
            surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2);
            currentCottonBlanketsPerPatient = parseFloat(this.sessionData.volumeDetail.get('cottonBlanketsCurrent')).toFixed(2);
            cottonBlanketsPerPatient = parseFloat(this.sessionData.volumeDetail.get('cottonBlankets')).toFixed(2);
            avgCostOfCottonBlanket = this.onCleanCurrency(costOfCottonView.formCostOfCottonView.down('field[name=avgCostBlanket]').getValue());
            avgCostOfCottonGown = this.onCleanCurrency(costOfCottonView.formCostOfCottonView.down('field[name=avgCostGown]').getValue());
            chartBlanketCostWithoutBairPaws = currentCottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);
            chartBlanketCostWithBairPaws = cottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);
            totalCottonBlanketsAndGownCost = cottonBlanketsPerPatient * surgeriesPerYear * (avgCostOfCottonBlanket + avgCostOfCottonGown);


            //Calculating other Kit items cost
            additionalKitCosts = 0;
            if (costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').getValue() !== '') {
                additionalKitCosts = this.onCleanCurrency(costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').getValue());
            }

            //Calculating Bair paws gown costs
            bairPawsGownKitCost = this.onCleanCurrency(this.sessionData.customerDetail.get('currentCost')).toFixed(2);


            bairPawsGownCost = bairPawsGownKitCost * surgeriesPerYear;


            //Calculating total annual costs
            totalAnnualCost = totalCostForAirWarmingBlankets + totalCottonBlanketsAndGownCost + additionalKitCosts + bairPawsGownCost;

            //Calculating average cost per patient
            avgCostPerPatient = totalAnnualCost / surgeriesPerYear;


            //Adding values to the text fields
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=forcedAirWarming]').setValue(this.onFormatCurrency(totalCostForAirWarmingBlankets, true, true));
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=cottonBlanketsGowns]').setValue(this.onFormatCurrency(totalCottonBlanketsAndGownCost, true, true));

            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=bairPawsGown]').setValue(this.onFormatCurrency(bairPawsGownCost, true, true));
            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=bairPawsGown]').show();

            costOfCottonView.formLeftCurrentPracticeCosts.down('field[name=bairPawsGown]').setValue(this.onFormatCurrency(bairPawsGownCost, true, true));
            costOfCottonView.formRightCurrentPracticeCosts.down('field[name=totalAnnualCost]').setValue(this.onFormatCurrency(totalAnnualCost, true, true));
            costOfCottonView.formRightCurrentPracticeCosts.down('field[name=averageCostPerPatient]').setValue(this.onFormatCurrency(avgCostPerPatient));

            // calculation according to the new model selection only changing Forced-air-warming and Bair Paws Gown calculation
            //BairPaws Gown = Cost of a Bair Paws gown kit * Bumber of general & regional anethesia surgeries per year
            //Forced-air warming  = Number of Forced-air warming blanket used annually * Average forced air warming blanket


            if (isChartRender) {

                newBairPawsModelNumber = this.sessionData.newBPKitCosts.get('modelNumber');

                costOfBairPawsGownForNewModel = this.onCleanCurrency(this.sessionData.newBPKitCosts.get('currentCostBairPawsGown')).toFixed(2);

                if (!this.onCheckedBlanketBase(newBairPawsModelNumber)) {
                    totalCostForAirWarmingBlanketsForNewModel = 0;
                } else {
                    avgForcedAirWarmingBlanketForNewModel = this.onCleanCurrency(this.sessionData.newBPKitCosts.get('avgcostforcedairblanket')).toFixed(2);
                    totalCostForAirWarmingBlanketsForNewModel = airWarmingBlanketsNo * avgForcedAirWarmingBlanketForNewModel;
                }


                var newModelKitCost = this.newBPKitCosts.get('newKitCosts');
                bairPawsGownCostForNewModel = costOfBairPawsGownForNewModel * surgeriesPerYear;

                data = [
                    {
                        "key": "Bair Paws Gowns",
                        "colorCode": "#A901DB",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(bairPawsGownCost)
                            },
                            {
                                "x": 1,
                                "y": Math.round(bairPawsGownCostForNewModel)
                            }
                        ]
                    },
                    {
                        "key": "Forced-Air Warming Blankets",
                        "colorCode": "#0431B4",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(totalCostForAirWarmingBlankets)
                            },
                            {
                                "x": 1,
                                "y": Math.round(totalCostForAirWarmingBlanketsForNewModel)
                            }
                        ]
                    },
                    {
                        "key": "Cotton Blankets",
                        "colorCode": "#c2d5ee",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(chartBlanketCostWithBairPaws)
                            },
                            {
                                "x": 1,
                                "y": Math.round(chartBlanketCostWithBairPaws)
                            }
                        ]
                    },
                    {
                        "key": "Additional Kit Costs",
                        "colorCode": "#DF7401",
                        "values": [
                            {
                                "x": 0,
                                "y": Math.round(additionalKitCosts)
                            },
                            {
                                "x": 1,
                                "y": Math.round(newModelKitCost)
                            }
                        ]
                    }
                ];
                barNames = [
                    {
                        "name": "Current<br>Practice Costs"
                    },
                    {
                        "name": "Proposed Bair Paws<br>System and Linen"
                    }
                ];
                this.perPatientChatData = [totalCostForAirWarmingBlankets, chartBlanketCostWithoutBairPaws, additionalKitCosts];

                var chartViewOne = this.getChartView();
                chartViewOne.setData(data, barNames, true);
                chartViewOne.showDifference(this.calculateTotals(data,0,1));

            }
        }

    },
    calculateHypothermiaCosts: function () {

        //calculating total number of hypothermia patients
        var hypothermiaCostView = this.getHypothermiaCostsView(),
            surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2),
            estimatedPercentageOfPatientsHypothermic = this.onCleanPercentage(hypothermiaCostView.formHypothermiaCosts.down('field[name=percentageOfPatients]').getValue()),
            totalNumberOfHypothermiaPatients = surgeriesPerYear * estimatedPercentageOfPatientsHypothermic / 100;

        //calculating total number of patients with hypothermia complications
        var estimatedNumberOfPatientsWIthComplications = this.onCleanPercentage(hypothermiaCostView.formHypothermiaCosts.down('field[name=percentageOfPatientsComplications]').getValue()),
        //changes :  changes Total number of patients with hypothermia related complications calculaation according to the 2014/10/06 calculation sheet
            totalNumberOfPatientsWithHypothermiaComplications = totalNumberOfHypothermiaPatients * estimatedNumberOfPatientsWIthComplications / 100;

        hypothermiaCostView.formHypothermiaCosts.down('field[name=totalOfPatients]').setValue(totalNumberOfHypothermiaPatients.toFixed(0));
        hypothermiaCostView.formHypothermiaCosts.down('field[name=totalOfPatientsComplications]').setValue(parseFloat(totalNumberOfPatientsWithHypothermiaComplications).toFixed(0));
    },

    calculateTotalCost: function () {

        //calculating estimated total cost to treat complications
        var meanAcquisitionCostOfAUnitOfBlood = parseFloat(this.onCleanCurrency(this.sessionData.complicationsDetail.get('meanAcquisitionCost'))).toFixed(2), //complication first column
            totalNumberOfPatientsWithHypothermiaComplications = parseFloat(this.sessionData.hypothermiaCostsDetail.get('totalOfPatientsComplications')).toFixed(2),
            estimatedTotalCOstToTreatComplications = meanAcquisitionCostOfAUnitOfBlood * totalNumberOfPatientsWithHypothermiaComplications;


        //Calculating cost of savings to warm all patients
        var surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2);

        var  bairPawsGownCost = this.onCleanCurrency(this.sessionData.customerDetail.get('currentCost')).toFixed(2);

        var meanAcquisitionCost = this.onCleanCurrency(this.sessionData.complicationsDetail.get('meanAcquisitionCost'));
        var averageCostInpatient = this.onCleanCurrency(this.sessionData.complicationsDetail.get('averageCostInpatient'));
        var averageCostPACUMinute = this.onCleanCurrency(this.sessionData.complicationsDetail.get('averageCostPACUMinute'));
        var averageCostSSI7 = this.onCleanCurrency(this.sessionData.complicationsDetail.get('averageCostSSI7'));
        var averagePerPatient = this.onCleanCurrency(this.sessionData.complicationsDetail.get('averagePerPatient'));

        var estimatedCostOfComplications = this.sessionData.hypothermiaCostsDetail.get('estimatedCostOfComplications');
        if (estimatedCostOfComplications === 'unitOfBlood') {
            estimatedTotalCOstToTreatComplications = meanAcquisitionCost * totalNumberOfPatientsWithHypothermiaComplications;
        }
        else if (estimatedCostOfComplications === 'inpatientDay') {
            estimatedTotalCOstToTreatComplications = ( averageCostInpatient * 2.6 ) * totalNumberOfPatientsWithHypothermiaComplications;
        }
        else if (estimatedCostOfComplications === 'PACUminute') {
            estimatedTotalCOstToTreatComplications = (averageCostPACUMinute * 40) * totalNumberOfPatientsWithHypothermiaComplications;
        }
        else if (estimatedCostOfComplications === 'costSSI') {
            estimatedTotalCOstToTreatComplications = averageCostSSI7 * totalNumberOfPatientsWithHypothermiaComplications;
        }
        else if (estimatedCostOfComplications === 'mahoneyValue') {
            estimatedTotalCOstToTreatComplications = averagePerPatient * totalNumberOfPatientsWithHypothermiaComplications;
        }

        var costSavingsToWarmAllPatients = Math.abs(estimatedTotalCOstToTreatComplications - (surgeriesPerYear * bairPawsGownCost));
        if(this.sessionData.totalCostDetail) {
            this.sessionData.totalCostDetail.destroy();
        }
        this.sessionData.totalCostDetail = Ext.create('BairPawsCalc.model.TotalCostDetail', {'estimatedTotalCost' : estimatedTotalCOstToTreatComplications, 'costSavings': costSavingsToWarmAllPatients});

        //console.log(meanAcquisitionCostOfAUnitOfBlood + ',' + totalNumberOfPatientsWithHypothermiaComplications);

    },
    calculateTotals: function (data, position1, position2) {
      var costDifference = 0;
      var costWithBp = 0;
      var costWithoutBp = 0;
      var i = 0;

      Ext.Array.each(data, function(record){
        costWithBp += record['values'][position2]['y'];
        costWithoutBp += record['values'][position1]['y'];

      });
      costDifference = costWithoutBp - costWithBp;
      this.costSavings = costDifference;
      return costDifference;
    },
    renderFinalChart: function () {

        var customerDetailsModelNumber = this.sessionData.customerDetail.get('modelNumber');

        var totalValueOfBpLinenKitCosts = this.calculateBpAndLinenKitcosts();

        var hypothermiaComplications = this.onCleanCurrency(this.sessionData.totalCostDetail.get('estimatedTotalCost')),
            surgeriesPerYear = parseFloat(this.sessionData.volumeDetail.get('anesthesiaSurgeries')).toFixed(2),
            additionalKitCosts = 0;
        if (!isNaN(this.onCleanCurrency(this.sessionData.practiceCostDetail.get('otherKitItems')))) {
//            additionalKitCosts = this.onCleanCurrency(this.sessionData.practiceCostDetail.get('otherKitItems')) * surgeriesPerYear;
            additionalKitCosts = this.onCleanCurrency(this.sessionData.practiceCostDetail.get('otherKitItems'));
        }
        var avgCostOfCottonBlanket = this.onCleanCurrency(this.sessionData.cottonCostDetail.get('avgCostBlanket')),
            avgCostOfCottonGown = this.onCleanCurrency(this.sessionData.cottonCostDetail.get('avgCostGown')),
            cottonBlanketsPerPatientBeforeBairPaws = parseFloat(this.sessionData.volumeDetail.get('cottonBlanketsCurrent')).toFixed(2),
            cottonBlanketsPerPatientAfterBairPaws = parseFloat(this.sessionData.volumeDetail.get('cottonBlankets')).toFixed(2),
            linenPracticeCosts = (avgCostOfCottonBlanket + avgCostOfCottonGown) * surgeriesPerYear * cottonBlanketsPerPatientBeforeBairPaws,
            linenBairPawsSystem = (avgCostOfCottonBlanket + avgCostOfCottonGown) * surgeriesPerYear * cottonBlanketsPerPatientAfterBairPaws;

        var bairPawsGownCost = this.onCleanCurrency(this.sessionData.customerDetail.get('currentCost')).toFixed(2);
        var costOfForcedAirWarmingBlanket;
        var costOfForcedAirWarmingBlanketSeesionValue = this.sessionData.cottonCostDetail.get('airWarmingCost');
        if (costOfForcedAirWarmingBlanketSeesionValue === "") {
            costOfForcedAirWarmingBlanket = 0;
        } else {
            costOfForcedAirWarmingBlanket = this.onCleanCurrency(costOfForcedAirWarmingBlanketSeesionValue);
        }

        console.log("costOfForcedAirWarmingBlanket : " + costOfForcedAirWarmingBlanket);

        var forcedAirWarmingBlanketsUsedManually = parseFloat(this.sessionData.volumeDetail.get('airWarmingBlankets')).toFixed(2),
            forcedAirWarming = costOfForcedAirWarmingBlanket * forcedAirWarmingBlanketsUsedManually,
            bairPawsGownsCost = bairPawsGownCost * surgeriesPerYear;

        var TotalBpAndLinenAirWarmingValue;
        var blanketDisability = this.onCheckedBlanketBase(customerDetailsModelNumber);
        if (!blanketDisability) {
            TotalBpAndLinenAirWarmingValue = 0;
        } else {
            TotalBpAndLinenAirWarmingValue = forcedAirWarming;
        }

        var dataRight = [
            {
                "key": "Bair Paws Gowns",
                "colorCode": "#A901DB",
                "values": [
                    {
                        "x": 0,
                        "y": 0
                        //Math.round(bairPawsGownsCost)
                    },
                    {
                        "x": 1,
                        "y": 0
                    },
                    {
                        "x": 2,
                        "y": Math.round(bairPawsGownsCost)
                    }
                ]
            },
            {
                "key": "Forced-Air Warming Blankets",
                "colorCode": "#0431B4",
                "values": [
                    {
                        "x": 0,
                        "y": Math.round(forcedAirWarming)
                    },
                    {
                        "x": 1,
                        "y": Math.round(forcedAirWarming)
                    },
                    {
                        "x": 2,
                        "y": Math.round(TotalBpAndLinenAirWarmingValue)
                    }
                ]
            },
            {
                "key": "Cotton Blankets & Gowns",
                "colorCode": "#c2d5ee",
                "values": [
                    {
                        "x": 0,
                        "y": Math.round(linenPracticeCosts) // changes : according to update excel sheet 2014/10/06
                    },
                    {
                        "x": 1,
                        "y": Math.round(linenPracticeCosts)
                    },
                    {
                        "x": 2,
                        "y": Math.round(linenBairPawsSystem)
                    }
                ]
            },
            {
                "key": "Additional Kit Costs",
                "colorCode": "#DF7401",
                "values": [
                    {
                        "x": 0,
                        "y": Math.round(additionalKitCosts)
                    },
                    {
                        "x": 1,
                        "y": Math.round(additionalKitCosts)
                    },

                    {
                        "x": 2,
                        "y": Math.round(totalValueOfBpLinenKitCosts)
                    }

                ]
            },
            {
                "key": "Complications",
                "colorCode": "#FF0000",
                "values": [
                    {
                        "x": 0,
                        "y": 0
                    },
                    {
                        "x": 1,
                        "y": Math.round(hypothermiaComplications)
                    },
                    {
                        "x": 2,
                        "y": Math.round(hypothermiaComplications / this.onCleanPercentage(this.getHypothermiaCostsView().formHypothermiaCosts.down('field[name=percentageOfPatients]').getValue()) * 13)
                    }
                ]
            }
        ];
        var barNames = [
            {
                "name": "Current<br>Practice Costs"
            },
            {
                "name": "Current Practice<br>Costs Including<br>Complications"
            },
            {
                "name": "Proposed Bair<br>Paws System<br>and Linen*"
            }

        ];

        var resultView = this.getResultView();
        console.log('setting final chart');
        resultView.barChart.setData(dataRight, barNames, true);
        resultView.barChart.setFootNote();
        resultView.barChart.showDifference(this.calculateTotals(dataRight,1,2));
    },

    onResetDefaults: function () {
        var that = this;
        Ext.Msg.show({
            title: '3M Bair Paws',
            message: "This will reset all the information. Do you wish to continue?",
            buttons: [
                {
                    itemId: 'yes',
                    text: 'Yes'
                },
                {
                    itemId: 'no',
                    text: 'No'
                }
            ],
            fn: function (selection) {
                if (selection === 'yes') {
                    that.getVolumeFieldView().resetFields();
                    that.getCostOfCottonView().resetFields();
                    that.getHypothermiaCostsView().resetFields();
                    that.getInitialView().resetFields();
                    that.getAdditionalKitCosts().resetFields();
                    that.getNewBpKitCostsView().resetFields();
                    that.getMain().navigationView.animateActiveItem(0, {
                        type: 'slide',
                        direction: 'right'
                    });
                    that.getMain().segmentedButton.innerItems[2].enable();
                    that.getMain().segmentedButton.innerItems[2].removeCls('disableMedia');
                    that.getMain().navBar.backButton.hide();
                    that.getMain().navBar.settingsButton.show();
                    that.getMain().navBar.pdfButton.hide();
                    that.getMain().navBar.nextButton.show();
                }

            }
        });


    },


    launch: function () {
        //console.log('sessiondata loaded');
        var costOfCottonView = this.getCostOfCottonView(),
            main = this.getMain();
        costOfCottonView.on({
            scope: this,
            calculateKitCosts: this.onCalculateKitCosts
        });
        main.on({
            scope: this,
            resetDefaults: this.onResetDefaults

        });
        //console.log(this);
        this.sessionData = Ext.create('BairPawsCalc.model.SessionData');
        this.newBPKitCosts = Ext.create('BairPawsCalc.model.NewBPKitCosts');
    }
});
