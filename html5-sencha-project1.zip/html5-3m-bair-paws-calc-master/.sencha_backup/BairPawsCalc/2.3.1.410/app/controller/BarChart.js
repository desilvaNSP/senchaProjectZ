Ext.define('BairPawsCalc.controller.BarChart', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    config: {
        refs: {
            barChartView: 'barchartview',
            chartView: 'chartview'
        }
    },
    
    onFormatText: function (value) {
        this.getChartView().formattedText = this.onFormatCurrency(value);
    },

    onDisappear: function () {
        var calculatorController = this.getApplication().getController('Calculator');
        calculatorController.calculateHypothermiaCosts();
        return true;
    },
    launch: function () {
        var chartView = this.getChartView();
        chartView.on({
            scope: this,
            disappear: this.onDisappear,
            formatText: this.onFormatText
        });
    }
});
