Ext.define('BairPawsCalc.controller.Initial', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    config: {
        refs: {
            initialView: 'initialview',
            costofcottonview : 'costofcottonview',
            volumefieldview : 'volumefieldview'

        }
    },
    onDisappear: function () {
        var calculatorController = this.getApplication().getController('Calculator');
        var isNotCurrentCustomer = false;
        if(calculatorController.sessionData.customerDetail) {
            calculatorController.sessionData.customerDetail.destroy();
        }


       calculatorController.sessionData.customerDetail = Ext.create('BairPawsCalc.model.CustomerDetail',this.getInitialView().formPanelInitialView.getValues());
       var cottonBlanketsCurrentField =  this.getVolumefieldview().formVolumeFieldView.down('field[name=cottonBlanketsCurrent]');
       var cottonBlanketsReference =  this.getVolumefieldview().formVolumeFieldView.down('button[name=cottonReference]');
       if(calculatorController.sessionData.customerDetail.getData().currentCustomer === "notCurrentCustomer"){
           isNotCurrentCustomer = true;
              cottonBlanketsCurrentField.show();
              cottonBlanketsReference.show();
              this.getCostofcottonview().formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').addCls('otherCostItemNotCustomer');
       }else{
           cottonBlanketsCurrentField.hide();
           cottonBlanketsReference.hide();
           this.getCostofcottonview().formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').removeCls('otherCostItemNotCustomer');
       }


        var disableFields = [];
        return this.validateFields(calculatorController.sessionData.customerDetail,disableFields, isNotCurrentCustomer);
    },

    onChangeCustomerStatus: function(){
         this.getCostofcottonview().formCostOfCottonView.down('field[name=kitCosts]').uncheck();
         if(this.getInitialView().formPanelInitialView.down('field[name=currentCustomer]').getValue() === "notCurrentCustomer"){
             this.getInitialView().formPanelInitialView.down('field[name=currentCost]').setLabel('Proposed cost of a Bair Paws gown');
         }else{
             this.getInitialView().formPanelInitialView.down('field[name=currentCost]').setLabel('Current cost of a Bair Paws gown');
         }
    },

    launch: function () {
        var initialView = this.getInitialView();
        initialView.on({
            scope: this,
            disappear: this.onDisappear,
            changeCustomerAndModelStatus:this.onChangeCustomerStatus
        });

    }
});
