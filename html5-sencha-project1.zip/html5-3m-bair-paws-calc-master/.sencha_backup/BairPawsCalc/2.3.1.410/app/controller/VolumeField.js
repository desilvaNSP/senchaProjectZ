Ext.define('BairPawsCalc.controller.VolumeField', {
    extend: 'BairPawsCalc.controller.BaseController',
    requires: [
    ],
    currencyExchange: 1.00,
    sessionData: '',
    //annualCostDetail: '',
//    cottonCostDetail: '',
//    customerDetail: '',
//    practiceCostDetail: '',
//    volumeDetail: ''
    config: {
        refs: {
            volumeFieldView: 'volumefieldview',
            costOfCottonView: 'costofcottonview'
        }
    },
    onDisappear: function () {
        var calculatorController = this.getApplication().getController('Calculator');
        var formObjCostOfCotton = this.getCostOfCottonView().formCostOfCottonView;
        var formObjLeftCurrentpracticeCosts = this.getCostOfCottonView().formLeftCurrentPracticeCosts;
        var formLeftCurrentPracticeCostsWrapper = this.getCostOfCottonView().formLeftCurrentPracticeCostsWrapper;
        var costOfCottonReference = this.getCostOfCottonView().costOfCottonReference;
        var costOfCottonBlanketReference = this.getCostOfCottonView().cottonBlanketReference;
        var costOfCottonBlanketReferenceCurrent = this.getCostOfCottonView().cottonBlanketReferenceCurrent;
        var activeWarmingReference = this.getCostOfCottonView().activeWarmingReference;
        var cottonBlanketReference = this.getCostOfCottonView().cottonBlanketReference;
        var currentCustomer = calculatorController.sessionData.customerDetail.get('currentCustomer');
        var modelNumberCustomerDetails = calculatorController.sessionData.customerDetail.get('modelNumber');
        var returnKitCostArray = this.onCheckedKitCostBase(modelNumberCustomerDetails, "kitCosts");
        var kitCostField = formObjCostOfCotton.down('field[name=kitCosts]');
        var cottonBlanketsGownsField = formObjLeftCurrentpracticeCosts.down('field[name=cottonBlanketsGowns]');

        if (returnKitCostArray.length === 4) {
            if (currentCustomer === 'currentCustomer') {
                kitCostField.disable();
                kitCostField.uncheck();
                formObjCostOfCotton.innerItems[4].show();
            } else {
                kitCostField.enable();
                formObjCostOfCotton.innerItems[4].hide();
            }
        } else {

            kitCostField.enable();
            formObjCostOfCotton.innerItems[4].hide();

        }

        var blanketDisability = this.onCheckedBlanketBase(modelNumberCustomerDetails);
        var airwarmingCostFiled = formObjCostOfCotton.down('field[name=airWarmingCost]');
        var costPerUseCottonGown = formObjCostOfCotton.down('field[name=avgCostGown]');
        var forcedAirWarmingField = formObjLeftCurrentpracticeCosts.down('field[name=forcedAirWarming]');

        if (calculatorController.sessionData.volumeDetail) {
            calculatorController.sessionData.volumeDetail.destroy();
        }
        calculatorController.sessionData.volumeDetail = Ext.create('BairPawsCalc.model.VolumeDetail', this.getVolumeFieldView().formVolumeFieldView.getValues());
        var bariPawsGownCostField = this.getCostOfCottonView().formLeftCurrentPracticeCosts.down('field[name=bairPawsGown]');

        if (calculatorController.sessionData.customerDetail.get('currentCustomer') === 'notCurrentCustomer') {
            bariPawsGownCostField.hide();
            formLeftCurrentPracticeCostsWrapper.setHeight('333px');
        }
        else {
            bariPawsGownCostField.show();
            formLeftCurrentPracticeCostsWrapper.setHeight('444px');
        }
        var disableFields = [];
        if (this.validateFields(calculatorController.sessionData.volumeDetail, disableFields)) {
            console.log('calculating cost');
            calculatorController.calculateCurrentPracticeCosts(false);
            if (currentCustomer === 'currentCustomer') {
                console.log(modelNumberCustomerDetails);
                console.log(blanketDisability);
                if (!blanketDisability) {
                    airwarmingCostFiled.disable();
                    airwarmingCostFiled.setValue("");
                    forcedAirWarmingField.disable();
                    airwarmingCostFiled.setPlaceHolder("Included in model");
                }
                else {
                    airwarmingCostFiled.enable();
                    forcedAirWarmingField.enable();
                    airwarmingCostFiled.setPlaceHolder("Enter Value");
                }
                costPerUseCottonGown.setValue("$0");
                costPerUseCottonGown.hide();
                costOfCottonReference.hide();
                costOfCottonBlanketReference.hide();
                costOfCottonBlanketReferenceCurrent.show();
                activeWarmingReference.element.dom.style.cssText = activeWarmingReference.element.dom.style.cssText.replace('387px !important;', '295px !important;');
                cottonBlanketsGownsField.setLabel('Cotton blankets');
                cottonBlanketReference.element.dom.style.cssText = cottonBlanketReference.element.dom.style.cssText.replace('230px', '203px');
                cottonBlanketReference.element.dom.style.cssText = cottonBlanketReference.element.dom.style.cssText.replace('590px', '620px');


            } else {
                costOfCottonBlanketReferenceCurrent.hide();
                if (!blanketDisability) {
                    airwarmingCostFiled.enable();
                    forcedAirWarmingField.enable();
                    airwarmingCostFiled.setPlaceHolder("Enter Value");
                }
                else {
                    airwarmingCostFiled.enable();
                    forcedAirWarmingField.enable();
                    airwarmingCostFiled.setPlaceHolder("Enter Value");
                }
            }
            return true;
        }
        else {
            return false;
        }
    },

//    onHide: function (view) {
//        var volumeDetail = Ext.create('BairPawsCalc.model.VolumeDetail',view.formVolumeFieldView.getValues());
//        this.getApplication().getController('Calculator').sessionData.volumeDetail = volumeDetail;
//        this.getApplication().getController('Calculator').calculateCurrentPracticeCosts(view.formVolumeFieldView);
//    },

    launch: function () {
        var volumeFieldView = this.getVolumeFieldView();
        volumeFieldView.on({
            scope: this,
//            hide: this.onHide,
            disappear: this.onDisappear

        });
//        volumeFieldView.addBeforeListener('hide', 'beforeHide');
    }
});
