Ext.define('BairPawsCalc.controller.NavBar', {
    extend: 'BairPawsCalc.controller.BaseController',
    xtype: 'navbar',
    requires: [
    ],
    config: {
        refs: {
            navbarview: 'navbarview',
            main: 'main',
            calculator: 'calculator',
            personalSettingsView: 'personalSettingsView',
            costOfCottonView: 'costofcottonview',
            volumeFieldView: 'volumefieldview',
            hypothermiaCostsView: 'hypothermiacostsview',
            newBPKitCostsView: 'newbpkitcostsview',
            additionalKitCosts: 'additionalkitcosts'
        }
    },
    onNextNavigation: function () {

        var navBar = this.getNavbarview();
        var main = this.getMain();
        var nextpageIndex = main.navigationView.indexOf(main.navigationView.getActiveItem()) + 1;
        navBar.secondPdfButton.setHidden(true);
        if (nextpageIndex === 3 || nextpageIndex === 4 || nextpageIndex > 5) {
            this.getMain().segmentedButton.innerItems[2].disable();
           this.getMain().segmentedButton.innerItems[2].addCls('disableMedia');

        }
        else {
            this.getMain().segmentedButton.innerItems[2].enable();
            this.getMain().segmentedButton.innerItems[2].removeCls('disableMedia');
        }
        if (main.navigationView.getActiveItem().fireEvent('disappear')) {
            var currentCustomer = this.getApplication().getController('Calculator').sessionData.customerDetail.get('currentCustomer');
            if (main.navigationView.getActiveItem().xtype === 'costofcottonview' && currentCustomer === 'notCurrentCustomer') {
                navBar.nextButton.setHidden(false);
                navBar.pdfButton.setHidden(true);
                navBar.secondPdfButton.setHidden(false);
                main.navigationView.setActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) + 2);
            }

            else if (main.navigationView.getActiveItem().xtype === 'newbpkitcostsview' && currentCustomer !== 'notCurrentCustomer') {
                navBar.nextButton.setHidden(true);
                navBar.pdfButton.setHidden(false);
                main.navigationView.setActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) + 1);
            }
            else {
                main.navigationView.setActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) + 1);
                if (main.navigationView.indexOf(main.navigationView.getActiveItem()) === main.navigationView.getItems().length - 2) {
                    navBar.nextButton.setHidden(true);
                    navBar.pdfButton.setHidden(false);
                }
                else {
                    navBar.nextButton.setHidden(false);
                    navBar.pdfButton.setHidden(true);
                }
                if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < 1) {
                    navBar.backButton.setHidden(true);
                    navBar.settingsButton.setHidden(false);
                }
                else {
                    navBar.backButton.setHidden(false);
                    navBar.settingsButton.setHidden(true);
                }
            }
        }
    },
    disableButtons: function (disableNext, disableBack, timeInMilliseconds) {
        var navBar = this.getNavbarview();
        if (disableNext) {
            navBar.nextButton.disable();
            setTimeout(function () {
                navBar.nextButton.enable();
            }, timeInMilliseconds);
        }
        if (disableBack) {
            navBar.backButton.disable();
            setTimeout(function () {
                navBar.backButton.enable();
            }, timeInMilliseconds);
        }
    },
    onBackNavigation: function () {
        var main = this.getMain();
        var currentCustomer = this.getApplication().getController('Calculator').sessionData.customerDetail.get('currentCustomer');
        var navBar = this.getNavbarview();
        navBar.secondPdfButton.setHidden(true);

        if (main.navigationView.getActiveItem().xtype === 'hypothermiacostsview') {
            console.log('calcaulting costs - on back')
            this.getApplication().getController('Calculator').calculateCurrentPracticeCosts(true);
        }
        if (main.navigationView.getActiveItem().xtype === 'chartview' && currentCustomer === 'notCurrentCustomer') {
            main.navigationView.animateActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) - 2, {
                type: 'slide',
                direction: 'right'
            });
        } else {
            main.navigationView.animateActiveItem(main.navigationView.indexOf(main.navigationView.getActiveItem()) - 1, {
                type: 'slide',
                direction: 'right'
            });
        }

        var backpageIndex = main.navigationView.indexOf(main.navigationView.getActiveItem());
        if (backpageIndex === 3 || backpageIndex === 4 || backpageIndex > 5) {
            this.getMain().segmentedButton.innerItems[2].disable();
           this.getMain().segmentedButton.innerItems[2].addCls('disableMedia');
        }
        else {
            this.getMain().segmentedButton.innerItems[2].enable();
           this.getMain().segmentedButton.innerItems[2].removeCls('disableMedia');
        }

        if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < 1) {
            navBar.backButton.setHidden(true);
            navBar.settingsButton.setHidden(false);
        }
        else {
            navBar.backButton.setHidden(false);
            navBar.settingsButton.setHidden(true);
        }
        if (main.navigationView.indexOf(main.navigationView.getActiveItem()) < main.navigationView.getItems().length - 2) {
            navBar.nextButton.setHidden(false);
            navBar.pdfButton.setHidden(true);
        } else {
            navBar.nextButton.setHidden(true);
            navBar.pdfButton.setHidden(false);
        }
        if (main.navigationView.getActiveItem().xtype === 'chartview' && currentCustomer === 'notCurrentCustomer') {
          console.log('showing PDF Button;')
          navBar.secondPdfButton.setHidden(false);
        }
    },
    navbarViewSettingsButtonTapped: function () {
        var that = this;
        this.settingsView = Ext.create('BairPawsCalc.view.PersonalSettingsView');
        var okButton = Ext.create('Ext.Button', {
            text: 'Ok',
            bottom: '25px',
            left: '25px',
            width: '100px',
            listeners: {
                tap: function () {
                    that.settingsView.parent.hide();
                    setTimeout(function () {
                        that.onSettingsOkButtonTapped(that.settingsView.parent);
                    }, 500);

                }
            }
        });
        this.settingsView.formPersonalSettingsView.add(okButton);
        var overlayPanel = Ext.create('Ext.Panel', {
            xtype: 'panel',
            modal: true,
            //hideOnMaskTap: true,
            height: '450px',
            width: '600px',
            cls: 'personalSettingsViewFormWrapper',
            showAnimation: {
                type: 'popIn',
                duration: 300,
                easing: 'ease-out'
            },
            hideAnimation: {
                type: 'popOut',
                duration: 300,
                easing: 'ease-out'
            },
            centered: true,
            styleHtmlContent: true,
            scrollable: false
        });
        overlayPanel.add(this.settingsView);
        var overlay = Ext.Viewport.add(overlayPanel);
        overlay.show();

    },
    onSettingsOkButtonTapped: function (panel) {
        panel.hide();
        var customerSettings = Ext.create('BairPawsCalc.model.CustomerSettingsDetail', this.getPersonalSettingsView().formPersonalSettingsView.getValues());
        //console.log(customerSettings);
        var settingsStore = Ext.getStore('settingsstore');
        settingsStore.removeAll();
        settingsStore.add(customerSettings);
        settingsStore.sync();
        panel.destroy();
    },
    onPdfGenearate: function (button, includeComplications) {
      console.log(includeComplications);
        var that = this;
        var calculatorController = this.getApplication().getController('Calculator');
        var disclaimerHTML = '<p class="disclaimer"><b>DISCLAIMER:</b> Cost calculator estimates are based upon facility inputs. Current practice costs and proposed costs are based upon these inputs and may or may not reflect your facility&#39;s actual or future costs or savings.</p>';

        function getCleanedHypothermiaName(key) {
            var map = Ext.create('Ext.util.HashMap');
                map.add('unitOfBlood', 'Unit of blood');
                map.add('inpatientDay', 'Cost per inpatient day');
                map.add('PACUminute','PACU minutes');
                map.add('costSSI','Cost of an SSI');
                map.add('mahoneyValue','Meta-analysis');
            return map.get(key.trim());
        }
        facilityName = calculatorController.sessionData.customerDetail.get('facilityName');
        var settingsStore = Ext.getStore('settingsstore');
        settingsStore.load();
        var personalSettings = settingsStore.getAt(0);
        repName = personalSettings.get('salesRepName');
        repPhoneNo = personalSettings.get('phoneNumber');
        repEmail = personalSettings.get('email');

        if (repName === null) {
            repName = '';
        }
        if (repPhoneNo === null) {
            repPhoneNo = '';
        }
        if (repEmail === null) {
            repEmail = '';
        }
        var customerType, currentCustomer, pdfContent, header, customerInfo, completeTheVolumeInfo, costOfCotton, activeWarmingCosts,
            currentPracticeCost1, currentPracticeCost2CurrentCus, currentPracticeCost2NewCus, hypothermiaAssociatedCosts, complications, totalCosts,
            noOfSurgeries, estimatedTotalCost, hypothermiaCost, additionalKitCosts, linenCosts, forcedAirWarmingCosts, airWarmingBlankets,
            leftContainer, rightContainer, pageOneContent, pageTwoContent, pageThreeContent, pageFourContent, pageFiveContent, graphOne, graphTwo;
        customerType = calculatorController.sessionData.customerDetail.get('currentCustomer');
        hypothermiaCost = 0;
        additionalKitCosts = calculatorController.sessionData.practiceCostDetail.get("otherKitItems");
        linenCosts = that.onCleanCurrency(calculatorController.sessionData.practiceCostDetail.get("cottonBlanketsGowns"));
        forcedAirWarmingCosts = that.onCleanCurrency(calculatorController.sessionData.practiceCostDetail.get("forcedAirWarming"));
        noOfSurgeries = that.onCleanCurrency(calculatorController.sessionData.volumeDetail.get("anesthesiaSurgeries"));
        if(additionalKitCosts !== ''){
            additionalKitCosts = that.onCleanCurrency(additionalKitCosts);
        }
        airWarmingBlankets = calculatorController.sessionData.volumeDetail.get("airWarmingBlankets");
        // Charts (Page 1 and Page 2)
        header = '<div class="headerHolder"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="pdfHeader">  <tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td class="heading"><img src="resources/images/title.png" width="386px"/></td></tr><tr><td class="pdfHeading">Overall Results for ' + facilityName + '</td></tr>  </table></td><td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="repDetails"><tr><td>' + repName + '</td></tr><tr><td>' + repPhoneNo + '</td></tr><tr><td>' + repEmail + '</td></tr></table></td></tr></table></div>';
        footer = '<div class="footerHolder"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="pdfFooter"><tr><td class="printTablePageNumber">' + disclaimerHTML + '<div class="copyright">3M, BAIR PAWS and the BAIR PAWS logo are trademarks of 3M Company, used under license in Canada. &copy;3M 2015. All rights reserved.</div></td></tr></table></div>';

        if (customerType === 'notCurrentCustomer') {
            graphOne = Ext.select('.chartview').elements[0].innerHTML;
            graphTwo = Ext.select('.perPatientResultsView').elements[0].innerHTML;
            pageOneContent = '<div class="pdfPage chart1"><h2>Overall Facility Costs (\'000s)</h2><div class="chartview">' + graphOne + '</div></div>';
            pageTwoContent = '<div class="pdfPage chart2"><h2>Overall Facility Costs (\'000s)</h2><div class="chartview">' + graphTwo + '</div></div>';
        }
        else if (customerType === 'currentCustomer') {
            graphOne = Ext.select('.chartview').elements[0].innerHTML;
            pageOneContent = '<div class="pdfPage"><h2>Overall Facility Costs (\'000s)</h2><div class="chartview">' + graphOne + '</div></div>';
        }

        var costOfCottonView = this.getCostOfCottonView();

        if (customerType === 'currentCustomer') {
            currentCustomer = 'Yes';
        }
        else if (customerType === 'notCurrentCustomer') {
            currentCustomer = 'No';
        }
        // Page Three content
        if (customerType === 'currentCustomer') {
            customerInfo = '<div class="customerInfo clearfix">\
                                <div class="header">Customer Info</div>\
                                <div class="lableWrapper"><div class="label">Facility name</div><div class="value">' + calculatorController.sessionData.customerDetail.get("facilityName") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Current Bair Paws gown customer</div><div class="value">' + currentCustomer + '</div></div>\
                                <div class="lableWrapper"><div class="label">Model number</div><div class="value">' + calculatorController.sessionData.customerDetail.get("modelNumber") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Current cost of a Bair Paws gown</div><div class="value">' + calculatorController.sessionData.customerDetail.get("currentCost") + '</div></div>\
                                </div>';
            completeTheVolumeInfo = '<div class="completeTheVolumeInfo clearfix">\
                <div class="header">Volume Fields</div>\
                <div class="lableWrapper"><div class="label">Number of general & regional anesthesia<br/>surgeries per year</div><div class="value">' + calculatorController.sessionData.volumeDetail.get("anesthesiaSurgeries") + '</div></div>\
                <div class="lableWrapper"><div class="label">Number of cotton blankets per surgical patient (AFTER Bair Paws system use)</div><div class="value">' + calculatorController.sessionData.volumeDetail.get("cottonBlankets") + '</div></div>\
                <div class="lableWrapper"><div class="label">Number of forced-air warming blankets used annually (upper, lower, torso & full)</div><div class="value">' + airWarmingBlankets + '</div></div>\
                </div>';
            costOfCotton = '<div class="costOfCotton clearfix">\
                                <div class="header">Cost of Linen</div>\
                                <div class="lableWrapper"><div class="label">Average cost per use of cotton blanket<span class="reference">1, 2, 3</span></div><div class="value">' + calculatorController.sessionData.cottonCostDetail.get("avgCostBlanket") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Additional kit costs</div><div class="value">' + that.onFormatCurrency(parseFloat(additionalKitCosts/noOfSurgeries).toFixed(2)) + '</div></div>\
                                </div>';
            activeWarmingCosts = '<div class="activeWarmingCosts clearfix">\
                                <div class="header">Active Warming Costs</div>\
                                <div class="lableWrapper"><div class="label">Cost per forced-air warming blanket<br/>(upper, lower, torso & full) per patient<span class="reference">1</span></div><div class="value">' + calculatorController.sessionData.cottonCostDetail.get("airWarmingCost") + '</div></div>\
                                </div>';
            currentPracticeCost1 = '<div class="currentPracticeCost1 clearfix">\
                                <div class="header">Current Practice Costs</div>\
                                <div class="lableWrapper"><div class="label">Forced-air warming blankets<br/>(upper, lower, torso & full)</div><div class="value">' + that.onFormatCurrency(forcedAirWarmingCosts, true, true) + '</div></div>\
                                <div class="lableWrapper"><div class="label">Cotton blankets<span class="reference">1</span></div><div class="value">' + that.onFormatCurrency(linenCosts, true, true) + '</div></div>\
                                <div class="lableWrapper"><div class="label">Other kit items</div><div class="value">' + that.onFormatCurrency(additionalKitCosts, true, true) + '</div></div>\
                                <div class="lableWrapper"><div class="label">Bair Paws gowns</div><div class="value">' + calculatorController.sessionData.practiceCostDetail.get("bairPawsGown") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Average cost per patient</div><div class="value">' + costOfCottonView.formRightCurrentPracticeCosts.down('field[name=averageCostPerPatient]').getValue() + '</div></div>\
                                </div>';
        }
        else if (customerType === 'notCurrentCustomer') {
            customerInfo = '<div class="customerInfo clearfix">\
                                <div class="header">Customer Info</div>\
                                <div class="lableWrapper"><div class="label">Facility name</div><div class="value">' + calculatorController.sessionData.customerDetail.get("facilityName") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Current Bair Paws gown customer</div><div class="value">' + currentCustomer + '</div></div>\
                                <div class="lableWrapper"><div class="label">Model number</div><div class="value">' + calculatorController.sessionData.customerDetail.get("modelNumber") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Proposed cost of a Bair Paws gown</div><div class="value">' + calculatorController.sessionData.customerDetail.get("currentCost") + '</div></div>\
                                </div>';
            completeTheVolumeInfo = '<div class="completeTheVolumeInfo clearfix">\
                <div class="header">Volume Fields</div>\
                <div class="lableWrapper"><div class="label">Number of general & regional anesthesia<br/>surgeries per year</div><div class="value">' + calculatorController.sessionData.volumeDetail.get("anesthesiaSurgeries") + '</div></div>\
                <div class="lableWrapper"><div class="label">Current number of cotton blankets per surgical patient (BEFORE Bair Paws system use)<span class="reference">1, 2</span></div><div class="value">' + calculatorController.sessionData.volumeDetail.get("cottonBlanketsCurrent") + '</div></div>\
                <div class="lableWrapper"><div class="label">Number of cotton blankets per surgical patient (AFTER Bair Paws system use)</div><div class="value">' + calculatorController.sessionData.volumeDetail.get("cottonBlankets") + '</div></div>\
                <div class="lableWrapper"><div class="label">Number of forced-air warming blankets<br>used annually (upper, lower, torso & full)</div><div class="value">' + airWarmingBlankets + '</div></div>\
                </div>';
            costOfCotton = '<div class="costOfCotton clearfix">\
                                <div class="header">Cost of Linen</div>\
                                <div class="lableWrapper"><div class="label">Average cost per use of cotton blanket<span class="reference">1, 2, 3</span></div><div class="value">' + calculatorController.sessionData.cottonCostDetail.get("avgCostBlanket") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Average cost per use of cotton gown<span class="reference">1, 4</span></div><div class="value">' + calculatorController.sessionData.cottonCostDetail.get("avgCostGown") + '</div></div>\
                                <div class="lableWrapper"><div class="label">Additional kit costs</div><div class="value">' + that.onFormatCurrency(parseFloat(additionalKitCosts/noOfSurgeries).toFixed(2)) + '</div></div>\
                                </div>';
            activeWarmingCosts = '<div class="activeWarmingCosts clearfix">\
                                <div class="header">Active Warming Costs</div>\
                                <div class="lableWrapper"><div class="label">Cost per forced-air warming blanket<br/>(upper, lower, torso & full) per patient<span class="reference">1</span></div><div class="value">' + calculatorController.sessionData.cottonCostDetail.get("airWarmingCost") + '</div></div>\
                                </div>';
            currentPracticeCost1 = '<div class="currentPracticeCost1 clearfix">\
                                <div class="header">Current Practice Costs</div>\
                                <div class="lableWrapper"><div class="label">Forced-air warming blankets<br/>(upper, lower, torso & full)</div><div class="value">' + that.onFormatCurrency(forcedAirWarmingCosts, true, true) + '</div></div>\
                                <div class="lableWrapper"><div class="label">Cotton blankets and gowns<span class="reference">1</span></div><div class="value">' + that.onFormatCurrency(linenCosts, true, true) + '</div></div>\
                                <div class="lableWrapper"><div class="label">Other kit items</div><div class="value">' + that.onFormatCurrency(additionalKitCosts, true, true) + '</div></div>\
                                </div>';
        }


        leftContainer = '<div class="leftContainer">' + customerInfo + completeTheVolumeInfo + costOfCotton + activeWarmingCosts + currentPracticeCost1 + '</div>';
        if (customerType === 'notCurrentCustomer') {
            estimatedTotalCost = that.onFormatCurrency(Math.abs(calculatorController.costSavings));
            currentPracticeCost2NewCus = '<div class="currentPracticeCost2 clearfix">\
                            <div class="header">Current Practice Costs</div>\
                            <div class="lableWrapper"><div class="label">Additional kit costs - Cost per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(additionalKitCosts/noOfSurgeries).toFixed(2))+'</div></div>\
                            <div class="lableWrapper"><div class="label">Linen - Total cost per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(linenCosts/noOfSurgeries).toFixed(2))+'</div></div>\
                            <div class="lableWrapper"><div class="label">Cost per forced-air warming blanket<br/>(upper, lower, torso & full) per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(forcedAirWarmingCosts/airWarmingBlankets).toFixed(2))+'</div></div>\
                            <div class="lableWrapper"><div class="label">Average cost per patient</div><div class="value">' + costOfCottonView.formRightCurrentPracticeCosts.down('field[name=averageCostPerPatient]').getValue() + '</div></div>\
                            </div>';
            hypothermiaAssociatedCosts = '';
            complications = '';
            var costsavingLabelPDF = 'Estimated savings';
            if(calculatorController.costSavings < 0){
                costsavingLabelPDF = "Estimated investment";
            }
            if(includeComplications) {
              estimatedTotalCost = that.onCleanCurrency(calculatorController.sessionData.totalCostDetail.get("estimatedTotalCost"));
              hypothermiaCost = parseFloat(estimatedTotalCost/noOfSurgeries).toFixed(2);
              hypothermiaAssociatedCosts = '<div class="hypothermiaAssociatedCosts clearfix">\
              <div class="header">Hypothermia Associated Costs</div>\
              <div class="lableWrapper"><div class="label">Estimated % of patients hypothermic<span class="reference">1, 2, 3, 4</span></div><div class="value">' + calculatorController.sessionData.hypothermiaCostsDetail.get("percentageOfPatients") + '</div></div>\
              <div class="lableWrapper"><div class="label">Total number of hypothermic patients</div><div class="value">' + calculatorController.sessionData.hypothermiaCostsDetail.get("totalOfPatients") + '</div></div>\
              <div class="lableWrapper"><div class="label">Estimated % of patients with<br/>complications due to hypothermia<span class="reference">5</span></div><div class="value">' + calculatorController.sessionData.hypothermiaCostsDetail.get("percentageOfPatientsComplications") + '</div></div>\
              <div class="lableWrapper"><div class="label">Total number of patients with<br/> hypothermia related complications</div><div class="value">' + calculatorController.sessionData.hypothermiaCostsDetail.get("totalOfPatientsComplications") + '</div></div>\
              <div class="lableWrapper"><div class="label">Estimated cost of complications<br/>associated with hypothermia</div><div class="value">' + getCleanedHypothermiaName(calculatorController.sessionData.hypothermiaCostsDetail.get("estimatedCostOfComplications")) + '</div></div>\
              </div>';
              complications = '<div class="complications clearfix">\
              <div class="header">Complications</div>\
              <div class="lableWrapper"><div class="label">Mild hypothermia (< 1C) increases<br/>blood loss by 16% and relative<br/>risk of transfusion by 22%<span class="reference">1</span></div><div class="value">' + calculatorController.sessionData.complicationsDetail.get("meanAcquisitionCost") + '<br/><span class="bottomLabel">Mean acquisition cost<br>of a unit of blood</span></div><div class="reference">2</div></div>\
              <div class="lableWrapper"><div class="label">Hypothermic patients’ duration of<br/>hospitalization is 20% longer (2.6<br/>days) than normothermic patients<span class="reference">3</span></div><div class="value">' + calculatorController.sessionData.complicationsDetail.get("averageCostInpatient") + '<br/><span class="bottomLabel">Average cost of an<br>inpatient day</span></div><div class="reference">4</div></div>\
              <div class="lableWrapper"><div class="label">Hypothermic patients can have<br/>delayed PACU discharge times <br/>(40 minutes longer)<span class="reference">6</span></div><div class="value">' + calculatorController.sessionData.complicationsDetail.get("averageCostPACUMinute") + '<br/><span class="bottomLabel">Average cost of a<br>PACU minute</span></div><div class="reference">7</div></div>\
              <div class="lableWrapper"><div class="label">Wound infection rates are three<br/>times higher for hypothermic patients<br/>(19% vs. 6%)<span class="reference">3</span></div><div class="value">' + calculatorController.sessionData.complicationsDetail.get("averageCostSSI7") + '<br/><span class="bottomLabel">Average cost of<br>an SSI</span></div><div class="reference">8</div></div>\
              <div class="lableWrapper"><div class="label">Average cost to treat unintended<br/>hypothermia is estimated to be<br/>between $2,500-7,000 per patient</div><div class="value">' + calculatorController.sessionData.complicationsDetail.get("averagePerPatient") + '<br/><span class="bottomLabel">Average cost <br>per patient</span></div><div class="reference">5</div></div>\
              </div>';
            }
            totalCosts = '<div class="totalCosts clearfix">\
                            <div class="header">Totals</div>\
                            <div class="lableWrapper"><div class="label">'+costsavingLabelPDF+'</div><div class="value">' + that.onFormatCurrency(Math.abs(calculatorController.costSavings), true, true) + '</div></div>\
                            </div>';
            rightContainer = '<div class="rightContainer">' + currentPracticeCost2NewCus + hypothermiaAssociatedCosts + complications + totalCosts + '</div>';
        }
        else if (customerType === 'currentCustomer') {
            var costsavingLabelPDF = 'Estimated savings';
            if(calculatorController.costSavings < 0){
                costsavingLabelPDF = "Estimated investment";
            }
            currentPracticeCost2CurrentCus = '<div class="currentPracticeCost2 clearfix">\
                            <div class="header">Proposed Bair Paws System and Linen</div>\
                            <div class="lableWrapper"><div class="label">Model number</div><div class="value">' + calculatorController.sessionData.newBPKitCosts.get("modelNumber") + '</div></div>\
                            <div class="lableWrapper"><div class="label">Proposed cost of a Bair Paws gown kit (or gown only) - Cost per patient</div><div class="value">' + calculatorController.sessionData.newBPKitCosts.get("currentCostBairPawsGown") + '</div></div>\
                            <div class="lableWrapper"><div class="label">Additional kit costs - Cost per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(additionalKitCosts/noOfSurgeries).toFixed(2))+'</div></div>\
                            <div class="lableWrapper"><div class="label">Linen - Cost per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(linenCosts/noOfSurgeries).toFixed(2))+'</div></div>\
                            <div class="lableWrapper"><div class="label">Forced-air warming - Avg. cost per patient</div><div class="value">'+that.onFormatCurrency(parseFloat(forcedAirWarmingCosts/airWarmingBlankets).toFixed(2))+'</div></div>\
                            </div>';
            totalCosts = '<div class="totalCosts clearfix">\
                            <div class="header">Totals</div>\
                            <div class="lableWrapper"><div class="label">'+costsavingLabelPDF+'</div><div class="value">' + that.onFormatCurrency(Math.abs(calculatorController.costSavings), true, true) + '</div></div>\
                            </div>';
            rightContainer = '<div class="rightContainer">' + currentPracticeCost2CurrentCus + totalCosts + '</div>';
        }

        pageThreeContent = '<div class="pdfPage"><h2>Values</h2>' + leftContainer + rightContainer + '</div>';

        //Page Four Content
        if(customerType === 'notCurrentCustomer'){
          pageFourContent =   '<div class="pdfPage"><h2>References</h2>' +
                              this.volumeReferenceTable +
                              this.costOfCottonTable +
                              this.activeWarmingCostsTable +
                              this.currentPracticeCostTable +
                              '</div>';
        }

        else {
          pageFourContent =   '<div class="pdfPage"><h2>References</h2>' +
                              this.volumeReferenceTable +
                              this.costOfCottonCurrentTable +
                              this.activeWarmingCostsTable +
                              this.currentPracticeCostTable +
                              '</div>';
        }


        pageFiveContent =   '<div class="pdfPage"><h2>References</h2>' +
                            this.complicationsTable +
                            this.hypothermiaCostsTable +
                            '</div>';

        if (customerType === 'notCurrentCustomer' && includeComplications) {
            pdfContent = '<div class="pdfContent towChart">\
                           <div class="page">'+ header + pageOneContent + footer + '</div><div class="page-seperator"></div>\
                           <div class="page secondChart">'+ header + pageTwoContent + footer + '</div><div class="page-seperator"></div>\
                           <div class="page">'+ header + pageThreeContent + footer + '</div><div class="page-seperator"></div>\
                           <div class="page">' + header + pageFourContent + footer + '</div><div class="page-seperator"></div>\
                           <div class="page">' + header + pageFiveContent + footer + '</div>\
                          </div>';
        }
        else {
            pdfContent = '<div class="pdfContent oneChart">\
                            <div class="page">' + header + pageOneContent + footer + '</div><div class="page-seperator"></div>\
                            <div class="page">' + header + pageThreeContent + footer + '</div><div class="page-seperator"></div>\
                            <div class="page">'+ header + pageFourContent + footer + '</div>\
                          </div>'

        }
        console.log(pdfContent);
        macs.convertHTMLToPDF({"pageContent": encodeURI("<html class='print'><head><link rel='stylesheet' href='touch/resources/css/cupertino.css' type='text/css'><link href='resources/css/app.css' rel='stylesheet' type='text/css'><link href='resources/css/print.css' rel='stylesheet' type='text/css'></head><body class='printWrapper'>" +
            pdfContent +
            "</body></html>") +
            ""}, function () {
        });

    },
    buildReferences: function(that) {
        that.volumeReferenceMap.add('1', 'VPMR survey results. Warming Methods Cost Comparison Research, sponsored by 3M. July 2012.' +
            '<br/>Market research was conducted with 150 nurses and 30 administrative managers representing 173 facilities in the US.  The research found that on average 9 cotton blankets are utilized per patient during the perioperative process.');
        that.volumeReferenceMap.add('2', 'Senn G. Some Cold, Hard Facts About Warmed Cotton Blankets. Surgical Services Management. June 2002;8:19-25.');

        that.costOfCottonReferenceMap.add('1', 'The Key Group survey results. Hospital Linen Usage and Cost Analysis Survey, sponsored by 3M. Nov. 2011.' +
            '<br/>Market research was conducted with 144 US hospital purchasing and laundry management personnel on the costs of acquiring and laundering cotton linens.');
        that.costOfCottonReferenceMap.add('2', 'VPMR survey results. Warming Methods Cost Comparison Research, sponsored by 3M. July 2012.' +
            '<br/>Market research was conducted with 150 nurses and 30 administrative managers representing 173 facilities in the US.  The research found that on average 9 cotton blankets are utilized per patient during the perioperative process.');
        that.costOfCottonReferenceMap.add('3', 'Senn G. Some Cold, Hard Facts About Warmed Cotton Blankets. Surgical Services Management. June 2002;8:19-25.');
        that.costOfCottonReferenceMap.add('4', 'Web. 12 Dec. 2014. https://www.medline.com/sku/item/MDPMDTPG2ROLSNO<br/>Average weight of a hospital patient gown is .41 lb.');


        that.costOfCottonReferenceCurrentMap.add('1', 'The Key Group survey results. Hospital Linen Usage and Cost Analysis Survey, sponsored by 3M. Nov. 2011.' +
            '<br/>Market research was conducted with 144 US hospital purchasing and laundry management personnel on the costs of acquiring and laundering cotton linens.');
        that.costOfCottonReferenceCurrentMap.add('2', 'VPMR survey results. Warming Methods Cost Comparison Research, sponsored by 3M. July 2012.' +
            '<br/>Market research was conducted with 150 nurses and 30 administrative managers representing 173 facilities in the US.  The research found that on average 9 cotton blankets are utilized per patient during the perioperative process.');
        that.costOfCottonReferenceCurrentMap.add('3', 'Senn G. Some Cold, Hard Facts About Warmed Cotton Blankets. Surgical Services Management. June 2002;8:19-25.');

        that.activeWarmingCostsReferenceMap.add('1', 'Based on current forced-air warming blanket costs for upper, lower, torso and full blankets. Input an average cost for these forced-air warming blankets.');

        that.currentPracticeReferenceMap.add('1', 'Assumes cost of use for cotton blankets.');
        that.currentPracticeReferenceMap.add('2', 'Bair Paws gown kit includes patient warming gown, bonnet, booties, personal belongings bag and shoe bag.');

        that.complicationsReferenceMap.add('1', 'Rajagopalan, S. Mascha, E. Na, J. et. al. The Effects of Mild Perioperative Hypothermia on Blood Loss and Transfusion Requirement. Anesthesiology. Jan 2008;108(1):71-77.');
        that.complicationsReferenceMap.add('2', 'Shander, A. Hofmann, A. Ozawa, S. et. al. Activity-based costs of blood transfusions in surgical patients at four hospitals. Transfusion. April 2010;50:753-765.');
        that.complicationsReferenceMap.add('3', 'Kurz, A. Sessler, DI. Lenhardt, R. Perioperative Normothermia to Reduce the Incidence of Surgical Wound Infection and Shorten Hospitalization. N Engl J Med. 1996;334:1209-15.');
        that.complicationsReferenceMap.add('4', 'Oh, J. ASC Communications 2012. April 30, 2012. Source: Kaiser State Health Facts.');
        that.complicationsReferenceMap.add('5', 'Mahoney, CB. Odom, J. Maintaining intraoperative normothermia: A meta-analysis of outcomes with costs. AANA Journal. 1999;67(2):155-164.');
        that.complicationsReferenceMap.add('6', 'Lenhardt, R. Marker, E. Goll V. et. al. Mild Intraoperative Hypothermia Prolongs Postanesthetic Recovery. Anesthesiology. Dec. 1997;87(6):1318-23.' +
            '<br/>Hypothermic patients can have delayed recovery times. The paper from Lenhardt found that on average, hypothermia patients took 40 minutes longer to reach fitness for discharge from PACU.');
        that.complicationsReferenceMap.add('7', 'Steinriede, K. The Financial Impact of Nerve Blocks. Outpatient Surgery Magazine. October 2010. Average cost of a PACU minute is $10.00.' +
            '<br/>(40 minute longer PACU stay x $10.00 = $400.00)');
        that.complicationsReferenceMap.add('8', 'Stone, P. Braccia, D. Larson, E. Systematic review of economic analyses of health care-associated infections. AJIC. Nov 2005;33(9):501-509.');

        that.hypothermiaReferenceMap.add('1', 'Hannan, E. Samadashvili, Z., Wechsler, A. et. al. The relationship between perioperative temperature and adverse outcomes after off-pump coronary artery bypass graft surgery. Journal of Thoracic and Cardiovascular Surgery. June 2010:1568-1575.' +
            '<br/>This retrospective study found that of 2,294 patients undergoing off-pump CABG 37.7% were mildly hypothermic (34.6°C-35.9°C) and 9% were moderately to severely hypothermic (≤34.5°C).');
        that.hypothermiaReferenceMap.add('2', 'Young, L. Watson, M. Prevention of Perioperative Hypothermia in Plastic Surgery. Aesthetic Surgery Journal. Sept/Oct 2006;26(5):551-571.' +
            '<br/>According to this article unintended perioperative hypothermia can occur in 50%-90% of all surgical patients unless active warming is utilized.');
        that.hypothermiaReferenceMap.add('3', 'Vlessides, M. Hypothermia During Surgery Affects Even Warmed Patients. Anesthesiology News. May 2014;40:5.                                                                                                                                                ' +
            '<br/>Even patients warmed intraoperatively can still experience hypothermia. A recent article highlighted retrospective research that showed up to one third of patients experienced periods of intraoperative hypothermia.');
        that.hypothermiaReferenceMap.add('4', 'Horn, E.-P. Bein, B. Bohm, R. et. al. The effect of short time periods of pre-operative warming in the prevention of peri-operative hypothermia. Anaesthesia. 2012;67:612-617.' +
            '<br/>This study showed that without forced-air prewarming, 68% of patients became hypothermic at the end of anesthesia.With just 10 minutes of forced-air prewarming only 13% became hypothermic at the end of anesthesia; with 20 minutes of prewarming only 7% became hypothermic at the end of anesthesia and with 30 minutes of prewarming only 6% became hypothermic at the end of anesthesia.');
        that.hypothermiaReferenceMap.add('5', 'Billeter, A. Hohmann, S. Druen, D. et. al. Unintentional perioperative hypothermia is associated with severe complications and high mortality in elective operations. Surgery. Nov. 2014;156(5):1245-1252.' +
            '<br/>Retrospective analysis of 707 patients who became unintentionally hypothermic. The hypothermic patients experienced a 4-fold increase in mortality and doubled complication rate.');
        function buildTableReference(title, map) {
            var tableString =  '<table width="96%" border="0" cellspacing="0" cellpadding="0" class="referenceTable"><tr><td colspan="2" class="refHeading">' +
                                title +
                                '</td></tr>';
            map.each(function(key, value, length){
                tableString +=   '<tr><td width="20">' +
                                    key +
                                    '</td>' +
                                    '<td>' +
                                    value +
                                    '</td></tr>';
            });
            tableString += '</table>';
            return tableString;
        };
        that.volumeReferenceTable = buildTableReference('Volume', that.volumeReferenceMap);
        that.costOfCottonTable = buildTableReference('Cost of Linen', that.costOfCottonReferenceMap);
        that.costOfCottonCurrentTable = buildTableReference('Cost of Linen', that.costOfCottonReferenceCurrentMap);
        that.activeWarmingCostsTable = buildTableReference('Active Warming Costs', that.activeWarmingCostsReferenceMap);
        that.currentPracticeCostTable = buildTableReference('Current Practice Costs', that.currentPracticeReferenceMap);
        that.complicationsTable = buildTableReference('Complications', that.complicationsReferenceMap);
        that.hypothermiaCostsTable = buildTableReference('Hypothermia Associated Costs', that.hypothermiaReferenceMap);
    },
    onPreviewReferences: function (flag, refNum, screenSection) {
        var that = this;
        var htmlContent;
        var main = this.getMain();
        var xtypeActiveItem = main.navigationView.getActiveItem().xtype;
        var title = '';
        var htmlContent = '';
        var refs = '';
        var map = {};

        if (flag === true) {
            htmlContent = this.volumeReferenceTable + '<br/>' + this.costOfCottonTable + '<br/>' + this.activeWarmingCostsTable + '<br/>' + this.currentPracticeCostTable + '<br/>' + this.complicationsTable + '<br/>' + this.hypothermiaCostsTable + '<br/><br/>';
        }
        else {
            var referenceArray = refNum.split(',');
            if (xtypeActiveItem === 'volumefieldview') {
                title = 'Volume';
                map = this.volumeReferenceMap;
            }
            else if (xtypeActiveItem === 'costofcottonview') {
                if (screenSection === 'costofcotton') {
                    title = 'Cost of Linen';
                    map = this.costOfCottonReferenceMap;
                } else if (screenSection === 'activewarmingcosts') {
                    title = 'Active Warming Costs';
                    map = this.activeWarmingCostsReferenceMap;
                } else {
                    title = 'Current Practice Costs';
                    map = this.currentPracticeReferenceMap;
                }

            }
            else if (xtypeActiveItem === 'hypothermiacostsview') {
                if (screenSection === 'hypothermia') {
                    title = 'Hypothermia';
                    map = this.hypothermiaReferenceMap;
                }
                else {
                    title = 'Complications';
                    map = this.complicationsReferenceMap;
                }
            }
            htmlContent =   '<table width="96%" border="0" cellspacing="0" cellpadding="0" class="referenceTable"><tr><td colspan="2" class="refHeading">' +
                            title +
                            '</td></tr>';

            Ext.Array.each(referenceArray, function(rec){
                htmlContent += '<tr><tr><td width="20">' +
                                rec +
                                '</td><td>' +
                                map.get(rec.trim()) +
                                '</td></tr>';

            });
            htmlContent += '</table>';
        }

        if (this.overlayContainer) {
            this.overlayContainer.destroy();
        }
        this.overlayContainer = Ext.create('Ext.Panel', {
            modal: true,
            hideOnMaskTap: true,
            height: '500px',
            width: '500px',
            style: 'background-color:#fff;',
            showAnimation: {
                type: 'popIn',
                duration: 500,
                easing: 'ease-out'
            },
            hideAnimation: {
                type: 'popOut',
                duration: 500,
                easing: 'ease-out'
            },
            zIndex: 500,
            centered: true,
            styleHtmlContent: true,
            items: [
                {
                    xtype: 'button',
                    style: 'border:none;font-size:20px;color:#333;background:none;',
                    width: 50,
                    height: 50,
                    top: 10,
                    right: 10,
                    html: 'X',
                    zIndex: 50,
                    listeners: {
                        tap: function () {
                            that.overlayContainer.destroy();
                        }
                    }
                },
                {
                    xtype: 'container',
                    zIndex: 20,
                    top: 20,
                    items: [
                        {
                            html: htmlContent
                        }
                    ]
                }
            ],
            scrollable: true,
            listeners: {
            }
        });

        if (flag) {
            this.overlayContainer.setHeight('500px');
        }
        else {
            this.overlayContainer.setHeight('320px');
        }

        var overlay = Ext.Viewport.add(this.overlayContainer);
        overlay.show();


    },
    meadiaitemOne: [
        {
            xtype: 'button',
            html: 'Flex brochure 603026E',
            listeners: {
                tap: function () {
                    macs.viewAsset("22743", function () {
                    });
                }
            }
        },
        {
            xtype: 'button',
            html: 'Patient Satisfaction brochure <br/>603555A',
            listeners: {
                tap: function () {
                    macs.viewAsset("22744", function () {
                    });
                }
            }
        },
        {
            xtype: 'button',
            html: 'What Patients and Clinicians <br/>are Saying 602415D',
            listeners: {
                tap: function () {
                    macs.viewAsset("19971", function () {
                    });
                }
            }
        }

    ],
    mediaitemTwo: [
        {
            xtype: 'button',
            html: 'Cost of Linen brochure <br/> 601334F   ',
            listeners: {
                tap: function () {
                    macs.viewAsset("19968", function () {
                    });
                }
            }
        }
    ],
    mediaitemThree: [
        {
            xtype: 'button',
            html: 'Cost of Linen brochure <br/> 601334F',
            listeners: {
                tap: function () {
                    macs.viewAsset("19968", function () {
                    });
                }
            }
        }
    ],
    mediaitemFive: [
        {
            xtype: 'button',
            html: 'Value Analysis brochure <br/> 603691A',
            listeners: {
                tap: function () {
                    macs.viewAsset("19958", function () {
                    });
                }
            }
        }
    ],
    onCollapseMediaList: function (button) {
        var main = this.getMain();
        var currentPage = main.navigationView.getActiveItem().xtype;

        if (this.mediaPanel) {
            this.mediaPanel.destroy();
        }
        this.mediaPanel = Ext.create('Ext.Panel', {
            width: 230,
            cls: 'mediaList',
            modal: true,
            hideOnMaskTap: true,
            styleHtmlContent: true,
            scrollable: false
        });
        button.enable();
        if (currentPage === 'initialview') {
            this.mediaPanel.setItems(this.meadiaitemOne);
            this.mediaPanel.setHeight(173);
        }
        else if (currentPage === 'volumefieldview') {
            this.mediaPanel.setItems(this.mediaitemTwo);
            this.mediaPanel.setHeight(80);
        }
        else if (currentPage === 'costofcottonview') {
            this.mediaPanel.setItems(this.mediaitemThree);
            this.mediaPanel.setHeight(80);
        }
        else if (currentPage === 'hypothermiacostsview') {
            this.mediaPanel.setItems(this.mediaitemFive);
            this.mediaPanel.setHeight(80);
        }
        else {
            button.disable();
        }
        Ext.Viewport.add(this.mediaPanel);
        var mediaButton = this.getMain().segmentedButton.innerItems[2];
        this.mediaPanel.showBy(mediaButton);
    },
    launch: function () {
        this.callParent();
        var navBar = this.getNavbarview();
        var main = this.getMain();
        var volumeFieldView = this.getVolumeFieldView();
        var costOfCottonView = this.getCostOfCottonView();
        var hypothermiaCostsView = this.getHypothermiaCostsView();
        this.volumeReferenceTable = '';
        this.costOfCottonTable = '';
        this.activeWarmingCostsTable = '';
        this.currentPracticeCostTable = '';
        this.complicationsTable = '';
        this.costOfCottonCurrentTable = '';
        this.costOfCottonReferenceCurrentMap =
        this.volumeReferenceMap = Ext.create('Ext.util.HashMap');
        this.costOfCottonReferenceMap = Ext.create('Ext.util.HashMap');
        this.activeWarmingCostsReferenceMap = Ext.create('Ext.util.HashMap');
        this.currentPracticeReferenceMap = Ext.create('Ext.util.HashMap');
        this.complicationsReferenceMap = Ext.create('Ext.util.HashMap');
        this.hypothermiaReferenceMap = Ext.create('Ext.util.HashMap');
        this.costOfCottonReferenceCurrentMap = Ext.create('Ext.util.HashMap');
        this.buildReferences(this);
        navBar.backButton.setHidden(true);
        navBar.on({
            scope: this,
            nextNavigation: this.onNextNavigation,
            backNavigation: this.onBackNavigation,
            navbarViewSettingsButtonTapped: this.navbarViewSettingsButtonTapped,
            pdfGenearate: this.onPdfGenearate

        });
        main.on({
            scope: this,
            previewReferences: this.onPreviewReferences,
            collapseMediaList: this.onCollapseMediaList
        });
        volumeFieldView.on({
            scope: this,
            previewReferences: this.onPreviewReferences
        });
        costOfCottonView.on({
            scope: this,
            previewReferences: this.onPreviewReferences
        });
        hypothermiaCostsView.on({
            scope: this,
            previewReferences: this.onPreviewReferences
        });
    }
});
