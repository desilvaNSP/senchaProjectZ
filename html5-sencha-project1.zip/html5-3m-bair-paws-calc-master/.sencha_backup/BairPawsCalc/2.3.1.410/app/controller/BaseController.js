Ext.define('BairPawsCalc.controller.BaseController', {
    extend: 'Ext.app.Controller',
    requires: [
    ],
    currencyExchange: 1.00,
    config: {
        refs: {
            main: 'main'
        }
    },
    onFormatPercentage: function (number) {
        //adding percentage sign
        var numberText = this.onCleanPercentage(number);
        if (numberText < 0) {
            return '';
        }
        if (!isNaN(numberText)) {
            number = numberText.toString();
            if (number.indexOf('%') === number.length - 1) {
                return number;
            }
            else {
                return number + '%';
            }
        }
        else {
            return '';
        }
    },

    onCleanPercentage: function (number) {
        //cleaning percentage sign
        number = number.toString();
        if (number.indexOf('%') === number.length - 1) {
            return parseFloat(number.slice(0, -1));
        }
        else {
            return parseFloat(number);
        }
    },

    onFormatCurrency: function (number, canBeMinusOrZero, removeDecimal) {
        //adding $ sign and commas to the currency
        var fixedSpace = 2;
        if(removeDecimal) {
          fixedSpace = 0
        }
        if (number === 0) {
            return '$0.00';
        }
        var numberText = this.onCleanCurrency(number);

        if (!canBeMinusOrZero) {
            if (numberText < 0) {
                return '';
            }
        }
        if (!isNaN(numberText) && numberText !== '') {
            number = number.toString();
//            console.log(number);
//
            if (number.indexOf('$') === 0) {
                return '$' + parseFloat(number.substring(1)).toFixed(fixedSpace).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

            }
            else {
                return '$' + parseFloat(number).toFixed(fixedSpace).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
        } else {
            return '';
        }
    },
    onCleanCurrency: function (number) {
        //cleaning the currency, removing $ sign and commas
        number = number.toString();
        if (number[0] === '$' && number !== '') {
            if (number.indexOf(',') > -1) {
                return parseFloat(number.substring(1).split(',').join(''));
            }
            else {
                return parseFloat(number.substring(1));
            }
        }
        else {
            if (number.indexOf(',') > -1) {
                return parseFloat(number.split(',').join(''));
            }
            else {
                return parseFloat(number);
            }
        }
    },

    onCurrencyFieldBlur: function (field) {
        //console.log("nan"+this.onCleanCurrency(field.getValue()));
        if (field.getValue() !== '') {
            field.setValue(this.onFormatCurrency(this.onCleanCurrency(field.getValue())));
        }
        else {
            field.setValue('');
        }

    },
    onCurrencyFieldFocus: function (field) {
        if (field.getValue() !== '') {
            field.setValue(this.onCleanCurrency(field.getValue()));
        }
        else {
            field.setValue('');
        }
    },
    onPercentageFieldBlur: function (field) {
        if (field.getValue() !== '') {
            field.setValue(this.onFormatPercentage(this.onCleanPercentage(field.getValue())));
        }
        else {
            field.setValue('');
        }
    },
    onPercentageFieldFocus: function (field) {
        if (field.getValue() !== '') {
            field.setValue(this.onCleanPercentage(field.getValue()));
        }
        else {
            field.setValue('');
        }
    },
    getCurrencyExchangedValue: function (realValue) {
        return realValue * this.currencyExchange;
    },


    validateFields: function (model, disableFields, isNotCurrentCustomer) {

        var errors = model.validate();
        var errorMsg = '';
        var newErrorObj = [];


        if (disableFields.length !== 0) {
            errors.each(function (errorObj) {
                for (var j = 0; j < disableFields.length; j++) {
                    if (disableFields[j] !== errorObj.getField()) {
                        newErrorObj.push(errorObj);
                    }
                }

            });

            if (newErrorObj.length > 0) {
                for (var j = 0; j < newErrorObj.length; j++) {
                    errorMsg += newErrorObj[j].getMessage() + '<br>';
                }
                if(isNotCurrentCustomer) {
                    errorMsg = errorMsg.replace('Current cost of a Bair Paws gown', 'Proposed cost of a Bair Paws gown');
                }
                Ext.Msg.show({
                    title: 'Please enter the following fields:',
                    message: errorMsg,
                    minWidth: 500
                });
                return false;
            }
            else {
                return true;
            }

        } else {

            newErrorObj = errors;
            if (newErrorObj.length > 0) {
                newErrorObj.each(function (errorObj) {
                    errorMsg += errorObj.getMessage() + '<br>';
                });
                if(isNotCurrentCustomer) {
                    errorMsg = errorMsg.replace('Current cost of a Bair Paws gown', 'Proposed cost of a Bair Paws gown');
                }
                Ext.Msg.show({
                    title: 'Please enter the following fields:',
                    message: errorMsg,
                    minWidth: 500
                });
                return false;
            }
            else {
                return true;
            }
        }

    },
    onCheckedKitCostBase: function (modelNumber, base) {
        var kitCostArray = [];
        if (base === "kitCosts") {
            if (modelNumber === '81003') {
                kitCostArray.push("");
            } else if (modelNumber === '83003') {
                kitCostArray.push("booties");
            } else if (modelNumber === '84003') {
                kitCostArray.push( "bonnet", "booties", "garmentBag", "shoeBag");
            } else if (modelNumber === '81002') {
                kitCostArray.push("");
            } else if (modelNumber === '83002') {
                kitCostArray.push("booties");
            } else if (modelNumber === '84002') {
                kitCostArray.push( "bonnet", "booties", "garmentBag", "shoeBag");
            } else if (modelNumber === '81001') {
                kitCostArray.push("");
            } else if (modelNumber === '83001') {
                kitCostArray.push("booties");
            } else if (modelNumber === '84001') {
                kitCostArray.push( "bonnet", "booties", "garmentBag", "shoeBag");
            }
        }

        return kitCostArray;
    },

    onCheckedBlanketBase: function (modelNumber) {
        if (modelNumber === '81003' || modelNumber === '83003' || modelNumber === '84003') {
            return false;
        } else {
            return true;
        }
    },

    launch: function () {
        Ext.Viewport.on({
            scope: this,
            formatPercentage: this.onFormatPercentage,
            cleanPercentage: this.onCleanPercentage,
            cleanCurrency: this.onCleanCurrency,
            currencyFieldBlur: this.onCurrencyFieldBlur,
            currencyFieldFocus: this.onCurrencyFieldFocus,
            percentageFieldBlur: this.onPercentageFieldBlur,
            percentageFieldFocus: this.onPercentageFieldFocus
        });
    }
});
