Ext.define('BairPawsCalc.model.AnnualCostDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'totalAnnualCost', type: 'string' },
            { name: 'averageCostPerPatient', type: 'string' }
        ]
    }
});
