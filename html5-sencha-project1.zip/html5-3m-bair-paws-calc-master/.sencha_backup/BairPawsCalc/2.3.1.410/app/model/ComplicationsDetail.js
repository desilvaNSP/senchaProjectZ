Ext.define('BairPawsCalc.model.ComplicationsDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'meanAcquisitionCost', type: 'string', defaultValue: '$203' },
            { name: 'averageCostInpatient', type: 'string', defaultValue: '$1,629'},
            { name: 'averageCostPACUMinute', type: 'string', defaultValue: '$10'},
            { name: 'averageCostSSI7', type: 'string', defaultValue: '$25,000'},
            { name: 'averagePerPatient', type: 'string', defaultValue: '$2,500'}
        ]
    }
});
