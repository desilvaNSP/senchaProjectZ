Ext.define('BairPawsCalc.model.VolumeDetail', {
    extend: 'Ext.data.Model',
    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'anesthesiaSurgeries', type: 'string'},
            { name: 'cottonBlanketsCurrent', type: 'string', defaultValue: '9' },
            { name: 'cottonBlankets', type: 'string', defaultValue: '1' },
            { name: 'airWarmingBlankets', type: 'string'}
        ],
        validations: [
            { type: 'presence', field: 'anesthesiaSurgeries', message: 'Number of general & regional anesthesia surgeries per year' },
            { type: 'presence', field: 'cottonBlanketsCurrent', message: 'Current number of cotton blankets per surgical patient (BEFORE Bair Paws system use)' },
            { type: 'presence', field: 'cottonBlankets', message: 'Number of cotton blankets per surgical patient (AFTER Bair Paws system use)' },
            { type: 'presence', field: 'airWarmingBlankets', message: 'Number of forced-air warming blankets (upper, lower, torso & full) used annually' }

        ]
//        proxy: {
//            type: 'localstorage',
//            id: 'form-data'
//        }
    }
});
