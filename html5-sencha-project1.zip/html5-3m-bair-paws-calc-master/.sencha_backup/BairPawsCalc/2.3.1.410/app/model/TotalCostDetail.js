Ext.define('BairPawsCalc.model.TotalCostDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'estimatedTotalCost', type: 'string', defaultValue: '203' },
            { name: 'costSavings', type: 'string', defaultValue: '1600'}
        ]
//        proxy: {
//            type: 'localstorage',
//            id: 'form-data'
//        }
    }
});
