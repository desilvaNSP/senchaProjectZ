Ext.define('BairPawsCalc.model.CustomerSettingsDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'id', type: 'int' },
            { name: 'salesRepName', type: 'string'},
            { name: 'phoneNumber', type: 'string'},
            { name: 'email', type: 'string'}
        ],
//        validations: [
////            { type: 'presence', field: 'avgCostBlanket', message: 'Please enter the Average Cost of Linen blanket.' },
//            { type: 'presence', field: 'currentCost', message: 'Please enter Current cost of a Bair Paws gown.' },
//        ]
        proxy: {
            type: 'localstorage',
            id: 'customer-settings'
        }
    }
});
