Ext.define('BairPawsCalc.model.CustomerDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'facilityName', type: 'string'},
            { name: 'currentCustomer', type: 'string'},
            { name: 'modelNumber', type: 'string'},
            { name: 'currentCost', type: 'string'}
        ],
        validations: [
            { type: 'presence', field: 'facilityName', message: 'Facility name' },
            { type: 'presence', field: 'currentCustomer', message: 'Are you a current Bair Paws gown customer' },
            { type: 'presence', field: 'modelNumber', message: 'Model number' },
            { type: 'presence', field: 'currentCost', message: 'Current cost of a Bair Paws gown' }
        ]
    }
});
