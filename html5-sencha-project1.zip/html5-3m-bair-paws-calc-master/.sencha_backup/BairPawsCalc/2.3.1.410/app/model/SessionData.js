Ext.define('BairPawsCalc.model.SessionData', {
    annualCostDetail: '',
    cottonCostDetail: '',
    newBPKitCosts:'',
    customerDetail: '',
    practiceCostDetail: '',
    volumeDetail: '',
    hypothermiaCostsDetail: '',
    complicationsDetail: '',
    totalCostDetail: ''
});
