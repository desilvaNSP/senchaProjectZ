Ext.define('BairPawsCalc.model.CottonCostDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'avgCostBlanket', type: 'string', defaultValue: '$1.63'},
            { name: 'avgCostGown', type: 'string', defaultValue: '$0.30' },
            { name: 'kitCosts', type: 'string'},
            { name: 'kitCostsValue', type: 'string', defaultValue: '$0' },
            { name: 'airWarmingCost', type: 'string'}
        ],

        validations: [
            { type: 'presence', field: 'avgCostBlanket', message: 'Average Cost of Linen blanket' },
            { type: 'presence', field: 'avgCostGown', message: 'Average cost per use of cotton blanket' },
            { type: 'presence', field: 'airWarmingCost', message: 'Cost per forced-air warming<br/>blanket (upper, lower, torso & full) per patient' }

        ]
    }
});
