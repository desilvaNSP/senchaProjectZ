Ext.define('BairPawsCalc.model.HypothermiaCostDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'percentageOfPatients', type: 'string'},
            { name: 'totalOfPatients', type: 'string'},
            { name: 'percentageOfPatientsComplications', type: 'string'}, //defaultValue: ''
            { name: 'totalOfPatientsComplications', type: 'string'},
            { name: 'estimatedCostOfComplications', type: 'string', defaultValue: null}

        ],
        validations: [
           { type: 'presence', field: 'percentageOfPatients', message: 'Estimated % of patients hypothermic' },
           { type: 'presence', field: 'percentageOfPatientsComplications', message: 'Estimated % of patients with complications due to hypothermia' },
           { type: 'presence', field: 'estimatedCostOfComplications', message: 'Estimated cost of complications associated with hypothermia' }
        ]
    }
});
