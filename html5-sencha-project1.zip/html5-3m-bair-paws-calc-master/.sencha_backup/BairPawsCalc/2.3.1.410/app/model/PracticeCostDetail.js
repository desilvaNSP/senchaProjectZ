Ext.define('BairPawsCalc.model.PracticeCostDetail', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'forcedAirWarming', type: 'string' },
            { name: 'cottonBlanketsGowns', type: 'string' },
            { name: 'otherKitItems', type: 'string' },
            { name: 'bairPawsGown', type: 'string' }
        ]
//        proxy: {
//            type: 'localstorage',
//            id: 'form-data'
//        }
    }
});
