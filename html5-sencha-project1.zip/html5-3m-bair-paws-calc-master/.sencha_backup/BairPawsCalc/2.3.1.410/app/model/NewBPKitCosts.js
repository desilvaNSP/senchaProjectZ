Ext.define('BairPawsCalc.model.NewBPKitCosts', {
    extend: 'Ext.data.Model',

    config: {
        idProperty: 'id',
        identifier: {
            type: 'uuid'
        },
        fields: [
            { name: 'modelNumber', type: 'string'},
            { name: 'currentCostBairPawsGown', type: 'string'},
            { name: 'avgcostforcedairblanket', type: 'string'},
            { name: 'newKitCosts', type: 'string'}
        ],
        validations: [
            { type: 'presence', field: 'modelNumber', message: 'Model number' },
            { type: 'presence', field: 'currentCostBairPawsGown', message: 'Proposed cost of a Bair Paws gown' },
            { type: 'presence', field: 'avgcostforcedairblanket', message: 'Average cost per forced-air warming blanket (upper, lower, torso & full)' }
        ]

    }
});
