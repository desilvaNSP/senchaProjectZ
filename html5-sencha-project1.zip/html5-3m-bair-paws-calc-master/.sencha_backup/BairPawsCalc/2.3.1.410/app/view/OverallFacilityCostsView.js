Ext.define('BairPawsCalc.view.OverallFacilityCostsView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'overallfacilitycostsview',
    requires: [
    ],
    config: {
        cls: 'OverallFacilityCostsView',
        width: '100%'
    },
    items:[
        {
            html:'Overall Facility Costs (\'000s) '
        }
    ],
    initialize: function () {
    }
});
