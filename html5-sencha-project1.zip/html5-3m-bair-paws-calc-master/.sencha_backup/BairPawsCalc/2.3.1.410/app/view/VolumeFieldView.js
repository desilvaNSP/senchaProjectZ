Ext.define('BairPawsCalc.view.VolumeFieldView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'volumefieldview',
    requires: [
    ],
    config: {
        items: [
            {
                html: 'Complete the Volume Fields Below:',
                cls: 'formHeader volumeFieldsHeader'
            }
        ]
    },
      previewReferences: function (flag, refNum) {
        this.fireEvent('previewReferences',flag, refNum);
    },
    initialize: function() {
        var that = this;
        this.formVolumeFieldView = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['volumeFieldView', 'formDefaults'],
            height: '100%',
            width: '92%',
            scrollable: false,
            padding: '0 10',
            items: [
                {
                    xtype: 'numberTextField',
                    label: 'Number of general & regional anesthesia<br/>surgeries per year',
                    name: 'anesthesiaSurgeries',
                    placeHolder:'Enter Value',
                    labelWidth: '56%'
                },
                {
                    xtype: 'button',
                    name: 'cottonReference',
                    text: '1, 2',
                    width: '50px',
                    height: '30px',
                    top: '142px',
                    left: '470px',
                    style: 'border:none;background:transparent;',
                    listeners:{
                        tap:function(){
                            that.previewReferences(false, this.getText());
                        }
                    }
                },
                {
                    xtype: 'numberTextField',
                    label: 'Current number of cotton blankets per surgical patient<br/>(BEFORE Bair Paws system use)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                    name: 'cottonBlanketsCurrent',
                    hidden : true,
                    placeHolder:'Enter Value',
                    labelWidth: '56%'
                },
                {
                    xtype: 'numberTextField',
                    label: 'Number of cotton blankets per surgical patient<br/>(AFTER Bair Paws system use)',
                    name: 'cottonBlankets',
                    placeHolder:'Enter Value',
                    labelWidth: '56%'
                },
                {
                    xtype: 'numberTextField',
                    label: 'Number of forced-air warming blankets<br>(upper, lower, torso & full) used annually',
                    name: 'airWarmingBlankets',
                    placeHolder:'Enter Value',
                    labelWidth: '56%'
                }
            ]
        });
        this.formVolumeFieldView.setRecord(Ext.create('BairPawsCalc.model.VolumeDetail'));
        this.add(this.formVolumeFieldView);
    },
    resetFields: function() {
        this.formVolumeFieldView.setRecord(Ext.create('BairPawsCalc.model.VolumeDetail'));
    }
});
