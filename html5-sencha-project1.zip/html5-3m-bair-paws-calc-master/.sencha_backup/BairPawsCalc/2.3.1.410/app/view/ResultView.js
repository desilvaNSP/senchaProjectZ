Ext.define('BairPawsCalc.view.ResultView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'resultview',
    requires: [
    ],
    config: {
        cls: 'perPatientResultsView',
        width: '100%'
    },
    initialize: function () {
//        var that = this;
        this.resultviewWrapperContainer = Ext.create('Ext.Container', {
            cls: 'resultviewWrapperContainer',
            layout: 'vbox',
            width: '100%',
            height: '100%'
        });

        this.chartContainerWrapper = Ext.create('Ext.Container', {
            cls: 'chartContainerWrapper',
            width: '100%',
            height: '100%'
        });

        this.barChart = Ext.create('BairPawsCalc.view.ChartView', {
            cls: 'barChartRight finalResult',
            width: '100%',
            height: '100%'
        });

        this.chartContainerWrapper.add([this.barChart]);
        this.resultviewWrapperContainer.add([this.chartContainerWrapper]);
        this.add(this.resultviewWrapperContainer);
    },
    loadChartData: function (dataLeft, dataRight) {
        this.barChartRight.renderChartData(dataRight);
    }
});
