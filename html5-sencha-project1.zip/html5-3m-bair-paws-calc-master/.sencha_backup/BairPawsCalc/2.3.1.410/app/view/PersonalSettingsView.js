Ext.define('BairPawsCalc.view.PersonalSettingsView', {
    extend: 'BairPawsCalc.view.BaseView',
    alias: 'widget.personalSettingsView',
    xtype: 'personalsettingsview',
    requires: [
    ],
    config: {
        left: 0,
        top: 0,
//        modal: true,
        //hideOnMaskTap: false,
        styleHtmlContent: true,
        height: '450px',
        width: '600px'
    },
    initialize: function() {
        this.formPersonalSettingsView = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['personalSettingsViewForm', 'formDefaults'],
            height: '450px',
            width: '600px',
            centered: true,
            scrollable: false,
            items: [
//                {
//                    xtype: 'button',
//                    text: 'Close',
//                    top: '18px',
//                    left: '10px',
//                    style: 'border:none;',
//                    width:'100px',
//                    listeners: {
//                        tap: function() {
//                            that.parent.hide();
//                            that.parent.destroy();
//                        }
//                    }
//                },
                {
                    html: 'Personal Settings',
                    cls: 'personalSettingsHeader'
                },
                {
                    xtype: 'textfield',
                    label: 'Sales Rep Name',
                    name: 'salesRepName',
                    labelWidth: '40%',
                    placeHolder: 'First and Last Name',
                    cls: 'salesRepName'
                },
                {
                    xtype: 'numberTextField',
                    label: 'Phone Number',
                    name: 'phoneNumber',
                    labelWidth: '40%',
                    placeHolder: '(xxx) xxx-xxxx'
                },
                {
                    xtype: 'textfield',
                    label: 'Email',
                    name: 'email',
                    labelWidth: '40%',
                    placeHolder: 'example@mail.com'
                }
//                {
//                    xtype: 'button',
//                    text: 'OK',
//                    width: '50%',
//                    margin: '0 0 0 50%',
//                    listeners: {
//                        tap: function () {
//                            that.fireEvent('confirmButtonTapped', that.formPersonalSettingsView);
//                        }
//                    }
//                }
            ]
        });
        var settingsStore = Ext.getStore('settingsstore');
        settingsStore.load();
        //console.log(settingsStore.getAt(0));
        this.formPersonalSettingsView.setRecord(settingsStore.getAt(0));
        this.add(this.formPersonalSettingsView);
    }
});
