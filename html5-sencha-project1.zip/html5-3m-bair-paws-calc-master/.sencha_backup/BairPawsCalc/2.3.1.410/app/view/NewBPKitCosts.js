Ext.define('BairPawsCalc.view.NewBPKitCosts', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'newbpkitcostsview',
    cls:'newbpKitCostsWrapper',
    requires: [
    ],
    config: {
        items: [
            {
                xtype: 'container',
                style: 'background:url(resources/images/heroImage.jpg) no-repeat 0 0; background-size:1024px 211px;',
                height: '211px',
                width: '1024px'
            },
            {
                html: 'Proposed Bair Paws System and Linen',
                cls: 'newbpKitCostsHeader formHeader'
            }
        ]
    },
    additionalCostCheckBoxChanged: function (name) {
        this.fireEvent('additionalCostCheckBoxChanged',name);
    },
    kitCostChecked: function (modelNumber) {
        this.fireEvent('kitCostChecked', modelNumber);
    },
    chageStatusOnNewModel:function(newvalue){
      this.fireEvent('chageStatusOnNewModel',newvalue);
    },

    initialize: function () {
        var that = this;

        this.formPanelBPKitCosts = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['initialViewForm', 'formDefaults'],
            height: '100%',
            width: '85%',
            scrollable: false,
            padding: '0 10',
            margin: '0 auto',
            items: [
                {
                    xtype: 'selectfield',
                    label: 'Model number',
                    name: 'modelNumber',
                    labelWidth: '50%',
                    placeHolder: 'Choose Model Number',
                    autoSelect: null,
                    options: [
                        {text: 'Model 81003', value: '81003'},
                        {text: 'Model 83003', value: '83003'},
                        {text: 'Model 84003', value: '84003'},
                        {text: 'Model 81002', value: '81002'},
                        {text: 'Model 83002', value: '83002'},
                        {text: 'Model 84002', value: '84002'},
                        {text: 'Model 81001', value: '81001'},
                        {text: 'Model 83001', value: '83001'},
                        {text: 'Model 84001', value: '84001'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 190,
                        minHeight: 190,
                        width: '21em'
                    },
                    listeners: {
                        change: function (obj,newvalue) {
                            that.chageStatusOnNewModel(newvalue);
                        }
                    }
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Proposed cost of a Bair Paws gown',
                    name: 'currentCostBairPawsGown',
                    labelWidth: '50%',
                    placeHolder: 'Enter Cost'
                },
                {
                    xtype: 'checkboxfield',
                    height: '30px',
                    name: 'newKitCosts',
                    label: 'Additional kit costs',
                    paddng: '0 20 0 0',
                    margin:'10 0 0 0',
                    labelWidth: '50%',
                    labelAlign: 'left',
                    cls: 'formCheckbbox checkBoxBpkitCost',
                    listeners: {
                        check: function () {
                            var modelNumber = that.formPanelBPKitCosts.down('field[name=modelNumber]').getValue();
                            that.kitCostChecked(modelNumber);
                            that.additionalCostCheckBoxChanged('newKitCosts');
                        },
                        uncheck: function () {

                        }
                    }
                },
                {
                    xtype: 'label',
                    html:'Kit cost included',
                    name: 'newKitCostIncluded',
                    cls:'newKitCostIncluded',
                    hidden:true,
                    value:'test'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Average cost per forced-air warming blanket<br>(upper, lower, torso & full)',
                    name: 'avgcostforcedairblanket',
                    labelWidth: '50%',
                    placeHolder: 'Enter Cost',
                    labelWrap: true
                }
            ]
        });
        this.formPanelBPKitCosts.setRecord(Ext.create('BairPawsCalc.model.NewBPKitCosts'));
        this.add(this.formPanelBPKitCosts);
    },
    resetFields: function () {
        this.formPanelBPKitCosts.setRecord(Ext.create('BairPawsCalc.model.NewBPKitCosts'));
        this.formPanelBPKitCosts.down('field[name=modelNumber]').setOptions([
            {text: 'Model 81003', value: '81003'},
            {text: 'Model 83003', value: '83003'},
            {text: 'Model 84003', value: '84003'},
            {text: 'Model 81002', value: '81002'},
            {text: 'Model 83002', value: '83002'},
            {text: 'Model 84002', value: '84002'},
            {text: 'Model 81001', value: '81001'},
            {text: 'Model 83001', value: '83001'},
            {text: 'Model 84001', value: '84001'}
        ]);
    }
});
