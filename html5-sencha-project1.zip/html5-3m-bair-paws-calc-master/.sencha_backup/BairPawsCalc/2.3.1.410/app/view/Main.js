Ext.define('BairPawsCalc.view.Main', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'main',
    requires: [
    ],
    config: {
        layout: 'vbox'
    },
    resetDefaults: function () {
        this.fireEvent('resetDefaults');
    },
    //previewReferences
    previewReferences: function (flag) {
        this.fireEvent('previewReferences', flag);
    },
    collapseMediaList: function (button) {
        this.fireEvent('collapseMediaList', button);
    },
    initialize: function () {
        var that = this;
        this.callParent(arguments);
        Ext.define('currencyTextField', {
            extend: 'Ext.field.Text',
            alias: 'widget.currencyTextField',
            config: {
                listeners: {
                    blur: function () {
                        this.suspendEvents(false);
                        Ext.Viewport.fireEvent('currencyFieldBlur', this);
                        this.resumeEvents(true);
                    },
                    focus: function () {
                        this.suspendEvents(false);
                        Ext.Viewport.fireEvent('currencyFieldFocus', this);
                        this.resumeEvents(true);
                    }
                }
            }

        });
        Ext.define('percentageTextField', {
            extend: 'Ext.field.Text',
            alias: 'widget.percentageTextField',
            config: {
                listeners: {
                    blur: function () {
                        this.suspendEvents(false);
                        Ext.Viewport.fireEvent('percentageFieldBlur', this);
                        this.resumeEvents(true);
                    },
                    focus: function () {
                        this.suspendEvents(false);
                        Ext.Viewport.fireEvent('percentageFieldFocus', this);
                        this.resumeEvents(true);
                    }
                }
            }

        });
        Ext.define('numberTextField', {
            extend: 'Ext.field.Text',
            alias: 'widget.numberTextField',
            config: {
                listeners: {
                    blur: function () {
                        that.checkIsNaN(this);
                    }
                }
            }

        });

        this.segmentedButton = Ext.create('Ext.SegmentedButton', {
            padding: '20 20 0 0',
            cls:'SegmentedButton',
            items: [
                {
                    text: 'References',
                    listeners: {
                        tap: function () {
                            that.previewReferences(true);
                        }
                    }
                },
                {
                    text: 'Reset Defaults',
                    listeners: {
                        tap: function () {
                            that.resetDefaults();
                        }
                    }
                },
                {
                    text: 'Media',
                    listeners: {
                        tap: function () {
                           that.collapseMediaList(this);
                        }
                    }
                }
            ],
            listeners: {
                toggle: function (container) {
                    container.setPressedButtons(-1);
                }
            }
        });
        //Header bar with Logo and Segmented buttons
        this.headerBar = Ext.create('Ext.Container', {
            layout: 'hbox',
            height: '75px',
            cls: 'topMenuMainWrapper',
            items: [
                {
                    xtype: 'spacer'
                },
                {
                    items: [this.segmentedButton]
                }
            ]
        });
        this.navigationView = Ext.create('BairPawsCalc.view.NavigationView', {});
        this.navBar = Ext.create('BairPawsCalc.view.NavBarView', {});
        this.add([this.headerBar, this.navigationView, this.navBar]);
    }

});
