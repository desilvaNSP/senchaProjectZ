Ext.define('BairPawsCalc.view.CostOfCottonView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'costofcottonview',
    requires: [
        'Ext.field.Radio'
    ],
    config: {
        cls: 'costOfCottonView',
        layout: 'hbox'
    },
    saveValues:function(passedButtonName) {
        this.fireEvent('saveValues', this ,passedButtonName);
    },
    calculateValues: function() {
        this.fireEvent('calculateValues', this);
    },
    additionalCostCheckBoxChanged: function(name) {
        this.fireEvent('additionalCostCheckBoxChanged', name);
    },
    calculateKitCosts: function() {
        this.fireEvent('calculateKitCosts');
    },
    previewReferences: function(flag, refNum, screenSection) {
        this.fireEvent('previewReferences', flag, refNum, screenSection);
    },
    kitCostChecked: function (modelNumber) {
        this.fireEvent('kitCostChecked', modelNumber);
    },
    initialize: function() {
        console.log("initializing Cost of Linen");
        var that = this;
        this.activeWarmingReferencePositionTop = '387px';
        this.overlay = Ext.create('Ext.Panel', {
            modal: true,
            passedButtonName: '',
            hideOnMaskTap: true,
            height: '400px',
            width: '500px',
            showAnimation: {
                type: 'popIn',
                duration: 500,
                easing: 'ease-out'
            },
            hideAnimation: {
                type: 'popOut',
                duration: 500,
                easing: 'ease-out'
            },
            centered: true,
            styleHtmlContent: true,
            items: [{
                    xtype: 'additionalKitCosts'
                }
            ],
            scrollable: false,
            listeners: {
                hide: function() {
                    that.saveValues(this.passedButtonName);
                    that.calculateKitCosts(this.passedButtonName);
                }
            }
        });
        this.overlay.hide();
        Ext.Viewport.add(this.overlay);
        this.costOfCottonReference = Ext.create('Ext.Button',
          {
              xtype: 'button',
              text: '1, 4',
              width: '45px',
              height: '30px',
              top: '169px',
              left: '450px',
              id: 'costOfGownReference',
              style: 'border:none;background:transparent;',
              listeners: {
                  tap: function() {
                      that.previewReferences(false, this.getText(), 'costofcotton');
                  }
              }
          }
        );
        this.costOfBlanketReference = Ext.create('Ext.Button',
          {
            xtype: 'button',
            text: '3',
            width: '30px',
            height: '30px',
            top: '169px',
            left: '450px',
            id: 'costOfBlanketReference',
            style: 'border:none;background:transparent;',
            listeners: {
              tap: function() {
                that.previewReferences(false, this.getText(), 'costofcotton');
              }
            }
          }
        );
        this.cottonBlanketReferenceCurrent = Ext.create('Ext.Button',
          {
            xtype: 'button',
            text: '1, 2, 3',
            width: '65px',
            height: '30px',
            top: '107px',
            left: '440px',
            style: 'border:none;background:transparent;',
            listeners: {
              tap: function() {
                that.previewReferences(false, this.getText(), 'costofcotton');
              }
            }
          }
        );
        this.activeWarmingReference = Ext.create('Ext.Button',
          {
              xtype: 'button',
              text: '1',
              width: '30px',
              height: '30px',
              top: this.activeWarmingReferencePositionTop,
              left: '450px',
              style: 'border:none;background:transparent;',
              listeners: {
                  tap: function() {
                      that.previewReferences(false, this.getText(), 'activewarmingcosts');
                  }
              }
          }
        );
        this.cottonBlanketReference = Ext.create('Ext.Button',
          {
            xtype: 'button',
            text: '1, 2, 3',
            width: '65px',
            height: '30px',
            top: '107px',
            left: '440px',
            style: 'border:none;background:transparent;',
            listeners: {
              tap: function() {
                that.previewReferences(false, this.getText(), 'costofcotton');
              }
            }
          }
        );


        this.formCostOfCottonView = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['costOfCottonViewForm', 'formDefaults'],
//            height: '100%',
            width: 500,
            scrollable: false,
            layout: 'vbox',
            items: [
                {
                    html: 'Cost of Linen',
                    cls: 'formHeader'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Average cost per use<br/>of cotton blanket',
                    name: 'avgCostBlanket',
                    labelWidth: '310px',
                    placeHolder:'Enter Value',
                    paddng: '0 20 0 0',
                    listeners: {
                        change: function() {
                            that.calculateValues();
                        }
                    }
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Average cost per use of</br>cotton gown',
                    name: 'avgCostGown',
                    labelWidth: '310px',
                    placeHolder:'Enter Value',
                    paddng: '0 20 0 0',
                    listeners: {
                        change: function() {
                            that.calculateValues();
                        }
                    }
                },
                {
                    xtype: 'checkboxfield',
                    height: '30px',
                    margin: '15 0 15 15',
                    name: 'kitCosts',
                    label: 'Additional kit costs',
                    labelWidth: '310px',
                    paddng: '0 20 0 0',
                    labelAlign: 'left',
                    cls: 'formCheckbbox',
                    listeners: {
                       check: function () {
                            that.kitCostChecked('flag');
                            that.additionalCostCheckBoxChanged('kitCosts');
                        },
                        uncheck: function() {
                            that.formLeftCurrentPracticeCosts.down('field[name=otherKitItems]').setValue('');
                        }
                    }
                },
                {
                    xtype: 'label',
                    html:'Kit cost included',
                    name: 'kitCostMsgLabel',
                    hidden:true,
                    cls:'kitCostIncluded'

                },
                {
                    html: 'Active Warming Costs',
                    cls: 'formHeader activeWarmingCosts'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Cost per forced-air warming<br/>blanket (upper, lower,<br/>torso & full) per patient',
                    name: 'airWarmingCost',
                    labelWidth: '310px',
                    paddng: '0 20 0 0',
                    cls: 'airWarmingCost',
                    placeHolder:'Enter Value',
                    listeners: {
                        change: function() {
                            that.calculateValues();
                        }
                    }
                }
//                ,
//                {
//                    xtype: 'currencyTextField',
//                    label: 'Cost of a Bair Paws gown kit<br/>(or gown only)',
//                    name: 'gownKitCost',
//                    paddng: '0 20 0 0',
//                    labelWidth: '310px',
//                    placeHolder:'Enter Value',
//                    listeners: {
//                        change: function() {
//                            that.calculateValues();
//                        }
//                    }
//                }
            ]
        });
        this.formCostOfCottonView.setRecord(Ext.create('BairPawsCalc.model.CottonCostDetail'));
        this.formLeftCurrentPracticeCosts = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['formLeftCurrentPracticeCosts', 'formDefaults'],
            height: '444px',
            width: '100%',
            layout: 'vbox',
            scrollable: false,
            items: [
                {
                    xtype: 'textfield',
                    label: 'Forced-air<br/>warming blankets',
                    name: 'forcedAirWarming',
                    readOnly: true,
                    cls: 'forcedAirWarming',
                    labelWidth: '120px'
                },
                {
                    xtype: 'textfield',
                    label: 'Cotton blankets<br/>and gowns',
                    name: 'cottonBlanketsGowns',
                    cls: 'cottonBlanketsGowns',
                    labelWidth: '120px',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    label: 'Additional<br>kit costs',
                    name: 'otherKitItems',
                    cls: 'otherKitItems',
                    labelWidth: '120px',

                    readOnly: true,
                    listeners: {
                        change: function(field, newValue) {
                            if (newValue === '') {
                                that.formCostOfCottonView.down('field[name=kitCosts]').uncheck();
                            }
                            that.calculateValues();
                        }
                    }
                },
                {
                    xtype: 'textfield',
                    label: 'Bair Paws gown',
                    name: 'bairPawsGown',
                    cls: 'bairPawsGown',
                    labelWidth: '120px',
                    readOnly: true
                }
            ]
        });
        this.formRightCurrentPracticeCosts = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['formRightCurrentPracticeCosts', 'formDefaults'],
            height: '100%',
            width: '100%',
            layout: 'vbox',
            scrollable: false,
            items: [
                {
                    html: ''
                            //cls: 'formHeader'
                },
                {
                    xtype: 'textfield',
                    name: 'totalAnnualCost',
                    cls: 'totalAnnualCost',
                    labelWidth: '0px',
                    readOnly: true
                },
                {
                    html: 'Total annual costs',
                    cls: 'titleWrapper'
                },
                {
                    xtype: 'textfield',
                    name: 'averageCostPerPatient',
                    cls: 'totalAnnualCost',
                    labelWidth: '0px',
                    readOnly: true

                },
                {
                    html: 'Average cost</br>per patient',
                    cls: 'titleWrapper'
                }
            ]
        });

        this.formLeftCurrentPracticeCostsWrapper = Ext.create('Ext.Container', {
            height: '444px',
            width: '49%',
            cls: 'formLeftCurrentPracticeCostsWrapper'
        });

        this.formRightCurrentPracticeCostsWrapper = Ext.create('Ext.Container', {
            height: '444px',
            width: '45%',
            cls: 'formRightCurrentPracticeCostsWrapper'
        });

        this.currentPracticeCostsWrapper = Ext.create('Ext.Container', {
            height: '100%',
            width: '60%',
            layout: 'vbox',
            items: [
                {
                    html: 'Current Practice Costs',
                    cls: 'formHeader formDefaults currentPracticeCostsHeader'
                }
            ]
        });

        this.currentPracticeCostsFormsWrapper = Ext.create('Ext.Container', {
            height: '425px',
            width: '86%',
            layout: 'hbox',
            cls: 'currentPracticeCostsFormsWrapper',
            padding: '10 10 10 15'
        });

        this.formLeftCurrentPracticeCostsWrapper.add(this.formLeftCurrentPracticeCosts);
        this.formRightCurrentPracticeCostsWrapper.add(this.formRightCurrentPracticeCosts);
        this.currentPracticeCostsFormsWrapper.add([this.formLeftCurrentPracticeCostsWrapper, this.formRightCurrentPracticeCostsWrapper]);
        this.currentPracticeCostsWrapper.add(this.currentPracticeCostsFormsWrapper);
        this.add([this.cottonBlanketReferenceCurrent, this.cottonBlanketReference,
            this.formCostOfCottonView, this.currentPracticeCostsWrapper, this.costOfCottonReference, this.activeWarmingReference, this.cottonBlanketReference]);
    },
    resetFields: function() {
        this.formCostOfCottonView.setRecord(Ext.create('BairPawsCalc.model.CottonCostDetail'));
    }
});
