Ext.define('BairPawsCalc.view.InitialView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'initialview',
    requires: [
    ],
    config: {
        items: [
            {
                xtype: 'container',
                style: 'background:url(resources/images/heroImage.jpg) no-repeat 0 0; background-size:1024px 211px;',
                height: '211px',
                width: '1024px'
            },
            {
                html: 'Use this calculator to compare the cost of warming every patient with the Bair Paws system to your current warming practices, cotton blanket usage and the costs associated with unintended hypothermia.',
                cls: 'initialViewHeader'
            }
        ]
    },
    changeCustomerAndModelStatus: function(){
        this.fireEvent('changeCustomerAndModelStatus', this);
    },
    initialize: function () {
        var that = this;
        if (this.overlayContainer) {
            this.overlayContainer.destroy();
        }
        this.overlayContainer = Ext.create('Ext.Container', {
            modal: true,
            hideOnMaskTap: true,
            hidden: true,
            height: '500px',
            width: '400px',
            style: 'background-color:#fff;',
            cls: 'overlayContainerNotaCust',
            showAnimation: {
                type: 'popIn',
                duration: 500,
                easing: 'ease-out'
            },
            hideAnimation: {
                type: 'popOut',
                duration: 500,
                easing: 'ease-out'
            },
            zIndex: 500,
            centered: true,
            styleHtmlContent: true,
            items: [
                {
                    html: 'Choose Model number',
                    cls: 'notCustHeading'
                },
                {
                    xtype: 'list',
                    height: '500px',
                    width: '400px',
                    cls: 'notCustList',
                    itemTpl: '{text}',
                    scrollable: true,
                    data: [
                        {text: 'Model 81003', value: '81003'},
                        {text: 'Model 83003', value: '83003'},
                        {text: 'Model 84003', value: '84003'},
                        {text: 'Model 81002', value: '81002'},
                        {text: 'Model 83002', value: '83002'},
                        {text: 'Model 84002', value: '84002'},
                        {text: 'Model 81001', value: '81001'},
                        {text: 'Model 83001', value: '83001'},
                        {text: 'Model 84001', value: '84001'}
                    ],
                    listeners: {
                        select: function () {
                            that.overlayContainer.hide();
                            console.log(that.formPanelInitialView.down('field[name=currentCustomer]').setAutoSelect(false));
                        }
                    }
                }
            ],
            scrollable: false
        });
        Ext.Viewport.add(this.overlayContainer);

        this.formPanelInitialView = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['initialViewForm', 'formDefaults'],
            height: '100%',
            width: '85%',
            scrollable: false,
            padding: '0 10',
            margin: '0 auto',
            items: [
                {
                    xtype: 'textfield',
                    label: 'Facility name',
                    name: 'facilityName',
                    labelWidth: '50%',
                    placeHolder: 'Enter Name'
                },
                {
                    xtype: 'selectfield',
                    label: 'Are you a current Bair Paws gown customer?',
                    name: 'currentCustomer',
                    labelWidth: '50%',
                    cls: 'currentCustomer',
                    placeHolder: 'Select Answer',
                    autoSelect: null,
                    options: [
                        {text: 'Current Bair Paws gown customer', value: 'currentCustomer'},
                        {text: 'Not a current Bair Paws gown customer', value: 'notCurrentCustomer'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 120,
                        minHeight: 120,
                        width: '22em'
                    },
                    listeners: {
                        change: function () {
                            that.changeCustomerAndModelStatus();
                        }
                    }
                },


                {
                    xtype: 'selectfield',
                    label: 'Model number',
                    name: 'modelNumber',
                    labelWidth: '50%',
                    cls: 'currentCustomer',
                    placeHolder: 'Choose Model Number',
                    autoSelect: null,
                    options: [
                        {text: 'Model 81003', value: '81003'},
                        {text: 'Model 83003', value: '83003'},
                        {text: 'Model 84003', value: '84003'},
                        {text: 'Model 81002', value: '81002'},
                        {text: 'Model 83002', value: '83002'},
                        {text: 'Model 84002', value: '84002'},
                        {text: 'Model 81001', value: '81001'},
                        {text: 'Model 83001', value: '83001'},
                        {text: 'Model 84001', value: '84001'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 190,
                        minHeight: 190,
                        width: '21em'
                    },
                     listeners: {
                        change: function () {
                            that.changeCustomerAndModelStatus();
                        }
                    }

                },
                {
                    xtype: 'currencyTextField',
                    label: 'Current cost of a Bair Paws gown',
                    name: 'currentCost',
                    labelWidth: '50%',
                    placeHolder: 'Enter Cost'
                }
            ]
        });
        this.formPanelInitialView.setRecord(Ext.create('BairPawsCalc.model.CustomerDetail'));
        this.add(this.formPanelInitialView);
    },
    resetFields: function () {
        this.formPanelInitialView.setRecord(Ext.create('BairPawsCalc.model.CustomerDetail'));
        this.formPanelInitialView.down('field[name=modelNumber]').setOptions([
            {text: 'Model 81003', value: '81003'},
            {text: 'Model 83003', value: '83003'},
            {text: 'Model 84003', value: '84003'},
            {text: 'Model 81002', value: '81002'},
            {text: 'Model 83002', value: '83002'},
            {text: 'Model 84002', value: '84002'},
            {text: 'Model 81001', value: '81001'},
            {text: 'Model 83001', value: '83001'},
            {text: 'Model 84001', value: '84001'}
        ]);
        this.formPanelInitialView.down('field[name=currentCustomer]').setOptions([
            {text: 'Current Bair Paws customer', value: 'currentCustomer'},
            {text: 'Not a current Bair Paws gown customer', value: 'notCurrentCustomer'}
        ]);
        this.formPanelInitialView.down('field[name=currentCost]').show();
    }
});
