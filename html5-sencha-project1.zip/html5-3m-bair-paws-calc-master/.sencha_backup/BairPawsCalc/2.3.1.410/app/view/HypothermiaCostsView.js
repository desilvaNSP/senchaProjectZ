Ext.define('BairPawsCalc.view.HypothermiaCostsView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'hypothermiacostsview',
    requires: [
    ],
    config: {
        cls: 'hypothermiaCostsView',
        layout: 'hbox'
    },
    calculateValues: function () {
        this.fireEvent('calculateValues', this);
    },
    previewReferences: function (flag, refNum, screenSection) {
        this.fireEvent('previewReferences', flag, refNum, screenSection);
    },
    initialize: function () {
        var that = this;
        this.formHypothermiaCosts = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['hypothermiaCostsForm', 'formDefaults'],
            height: '100%',
            width: '50%',
            scrollable: false,
            layout: 'vbox',
            items: [
                {
                    html: 'Hypothermia Associated Costs',
                    cls: 'formHeader'
                },
                {
                    xtype: 'percentageTextField',
                    label: 'Estimated % of patients<br/>hypothermic&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                    name: 'percentageOfPatients',
                    cls: 'boxTop',
                    clearIcon: false,
                    placeHolder: 'Enter Percentage',
                    labelWidth: '245px',
                    listeners: {
                        change: function () {
                            that.calculateValues();
                        }
                    }
                },
                {
                    xtype: 'numberTextField',
                    label: 'Total number of<br/>hypothermic patients',
                    name: 'totalOfPatients',
                    clearIcon: false,
                    cls: 'boxBot',
                    labelWidth: '245px',
                    readOnly: true,
                    listeners: {
                        change: function (field, newValue) {
                            if (isNaN(newValue)) {
                                field.setValue('');
                            }
                            else {
                                if (parseFloat(newValue) < 0) {
                                    field.setValue('');
                                }
                            }
                        }
                    }
                },
                {
                    xtype: 'percentageTextField',
                    label: 'Estimated % of patients<br/>with complications due to<br/>hypothermia&nbsp;&nbsp;&nbsp;',
                    name: 'percentageOfPatientsComplications',
                    labelWidth: '245px',
                    placeHolder: 'Enter Percentage',
                    clearIcon: false,
                    cls: 'boxTop',
                    listeners: {
                        change: function () {
                            that.calculateValues();
                        }
                    }
                },
                {
                    xtype: 'numberTextField',
                    label: 'Total number of patients<br/>with hypothermia related</br> complications',
                    name: 'totalOfPatientsComplications',
                    clearIcon: false,
                    cls: 'boxBot',
                    labelWidth: '245px',
                    readOnly: true,
                    listeners: {
                        change: function (field, newValue) {
                            if (isNaN(newValue)) {
                                field.setValue('');
                            }
                            else {
                                if (parseFloat(newValue) < 0) {
                                    field.setValue('');
                                }
                            }
                        }
                    }
                },
                {
                    xtype: 'selectfield',
                    label: 'Estimated cost of<br/>complications associated<br/>with hypothermia',
                    name: 'estimatedCostOfComplications',
                    labelWidth: '280px',
                    value: 'surgicalCost',
                    cls: 'surgicalCost',
                    autoSelect: null,
                    placeHolder: 'Select Answer',
                    options: [
                        {text: 'Unit of blood', value: 'unitOfBlood'},
                        {text: 'Cost per inpatient day', value: 'inpatientDay'},
                        {text: 'PACU minutes', value: 'PACUminute'},
                        {text: 'Cost of an SSI', value: 'costSSI'},
                        {text: 'Meta-analysis', value: 'mahoneyValue'}
                    ],
                    defaultTabletPickerConfig: {
                        height: 260,
                        minHeight: 260
                    }
                }
            ]
        });
        this.formComplications = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['complicationsForm', 'formDefaults'],
            height: '100%',
            width: '50%',
            scrollable: false,
            layout: 'vbox',
            items: [
                {
                    html: 'Complications',
                    cls: 'formHeader'
                },
                {
                    xtype: 'textfield',
                    label: 'Mild hypothermia (< 1C) increases<br/>blood loss by 16% and relative<br/>risk of transfusion by 22%',
                    name: 'meanAcquisitionCost',
                    cls: 'firstElm',
                    clearIcon: false,
                    labelWidth: '300px',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    label: 'Hypothermic patients’ duration of<br/>hospitalization is 20% longer (2.6<br/>days) than normothermic patients',
                    name: 'averageCostInpatient',
                    clearIcon: false,
                    labelWidth: '300px',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    label: 'Hypothermic patients can have<br/>delayed PACU discharge times<br>(40 minutes longer)',
                    name: 'averageCostPACUMinute',
                    clearIcon: false,
                    labelWidth: '300px',
                    readOnly: true

                },
                {
                    xtype: 'textfield',
                    label: 'Wound infection rates are three<br/>times higher for hypothermic<br/> patients (19% vs. 6%)',
                    name: 'averageCostSSI7',
                    clearIcon: false,
                    labelWidth: '300px',
                    readOnly: true
                },
                {
                    xtype: 'textfield',
                    label: 'Average cost to treat unintended<br/>hypothermia is estimated to be<br/>between $2,500-7,000 per patient',
                    name: 'averagePerPatient',
                    clearIcon: false,
                    labelWidth: '300px',
                    readOnly: true,
                    cls: 'lastElm'
                }
            ]
        });
        this.formHypothermiaCosts.setRecord(Ext.create('BairPawsCalc.model.HypothermiaCostDetail'));
        this.formComplications.setRecord(Ext.create('BairPawsCalc.model.ComplicationsDetail'));
        this.add([
            {
                xtype: 'container',
                style: 'text-align:right;font-size:11px;',
                items: [
                    {html: 'Mean acquisition cost<br>of a unit of blood', width:'150px', top: '0px', right: '75px', style:'text-align:center'},
                    {html: 'Average cost of an<br>inpatient day', width:'150px', top: '98px', right: '75px', style:'text-align:center'},
                    {html: 'Average cost of a<br>PACU minute', width:'150px', top: '189px', right: '75px', style:'text-align:center'},
                    {html: 'Average cost of<br>an SSI', width:'150px', top: '282px', right: '75px', style:'text-align:center'},
                    {html: 'Average cost <br>per patient', width:'150px', top: '380px', right: '75px', style:'text-align:center'}
                ],
                width: '300px',
                height: '40px',
                top: '120px',
                left: '768px',
                listeners: {
                    tap: function () {
                        that.previewReferences(false);
                    }
                }
            },
            {
                xtype: 'button',
                text: '1',
                width: '45px',
                height: '30px',
                top: '119px',
                left: '723px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '2',
                width: '30px',
                height: '30px',
                top: '129px',
                left: '965px',
                style: 'border:none;background:transparent;font-size:11px;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '3',
                width: '30px',
                height: '30px',
                top: '217px',
                left: '788px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '4',
                width: '30px',
                height: '30px',
                top: '227px',
                left: '965px',
                style: 'border:none;background:transparent;font-size:11px;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '6',
                width: '50px',
                height: '30px',
                top: '314px',
                left: '675px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '7',
                width: '30px',
                height: '30px',
                top: '317px',
                left: '965px',
                style: 'border:none;background:transparent;font-size:11px;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '8',
                width: '30px',
                height: '30px',
                top: '418px',
                left: '965px',
                style: 'border:none;background:transparent;font-size:11px;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '3',
                width: '30px',
                height: '30px',
                top: '412px',
                left: '702px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '5',
                width: '30px',
                height: '30px',
                top: '508px',
                left: '965px',
                style: 'border:none;background:transparent;font-size:11px;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText());
                    }
                }
            },
            {
                xtype: 'button',
                text: '1, 2, 3, 4',
                width: '100px',
                height: '30px',
                top: '99px',
                left: '196px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText(), 'hypothermia');
                    }
                }
            },
            {
                xtype: 'button',
                text: '5',
                width: '30px',
                height: '30px',
                top: '310px',
                left: '259px',
                style: 'border:none;background:transparent;',
                listeners: {
                    tap: function () {
                        that.previewReferences(false, this.getText(), 'hypothermia');
                    }
                }
            },
            this.formHypothermiaCosts,
            this.formComplications
        ]);
    },
    resetFields: function () {
        this.formHypothermiaCosts.setRecord(Ext.create('BairPawsCalc.model.HypothermiaCostDetail'));
        this.formComplications.setRecord(Ext.create('BairPawsCalc.model.ComplicationsDetail'));
        this.formHypothermiaCosts.down('field[name=estimatedCostOfComplications]').setOptions([
            {text: 'Unit of blood', value: 'unitOfBlood'},
            {text: 'Cost per inpatient day', value: 'inpatientDay'},
            {text: 'PACU minutes', value: 'PACUminute'},
            {text: 'Cost of an SSI', value: 'costSSI'},
            {text: 'Meta-analysis', value: 'mahoneyValue'}
        ]);

    }
});
