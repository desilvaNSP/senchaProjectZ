Ext.define('BairPawsCalc.view.BaseView', {
    extend: 'Ext.Container',
    xtype: 'baseview',
    requires: [
        'Ext.SegmentedButton',
        'Ext.Img',
        'BairPawsCalc.form.Panel',
        'Ext.field.Select'
    ],
    config: {

    },
    disappear: function () {
        this.fireEvent('disappear', this);
    },
    checkIsNaN: function(field) {
        if(isNaN(field.getValue())) {
           field.setValue('');
        }
        else {
            if(parseFloat(field.getValue()) < 0) {
                field.setValue('');
            }
        }
    }
});

