Ext.define('BairPawsCalc.view.NavigationView', {
    extend: 'Ext.NavigationView',
    xtype: 'navigationview',
    requires: [
    ], config: {
        height: '550px',
        layout: {
            type: 'card'
        },
        navigationBar: {
            hidden: true
        },
        items: [
            {
                xtype: 'initialview'
            },
            {
                xtype: 'volumefieldview'
            },
            {
                xtype: 'costofcottonview'
            },
            {
                xtype: 'newbpkitcostsview'
            },
            {
                xtype: 'chartview'
            },
            {
                xtype: 'hypothermiacostsview'
            },
            {
                xtype: 'resultview'
            }
        ],
        listeners: {
            initialize: function () {
                this.setActiveItem(0);
            }

        }
    }

});
