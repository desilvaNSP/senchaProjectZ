Ext.define('BairPawsCalc.view.AdditionalKitCosts', {
    extend: 'BairPawsCalc.view.BaseView',
    alias: 'widget.additionalKitCosts',
    xtype: 'additionalkitcosts',
    requires: [
    ],
    config: {
        left: 0,
        top: 0,
        modal: true,
        hideOnMaskTap: true,
        styleHtmlContent: true,
        scrollable: true,
        height: '400px',
        width: '500px'
    },
    initialize: function () {
        var that = this;
        this.formAdditionalKitCostsView = Ext.create('BairPawsCalc.form.Panel', {
            cls: ['additionalKitCostsViewForm', 'formDefaults'],
            height: '400px',
            width: '500px',
            centered: true,
            scrollable: false,
            items: [
                {
                    xtype: 'button',
                    cls:'closeButton',
                    html: 'Close',
                    listeners: {
                        tap: function () {
                            that.parent.hide();
                        }
                    }
                },
                {
                    html: 'Additional kit costs',
                    cls: 'additionalKitCostsHeader'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Bonnet',
                    name: 'bonnet',
                    labelWidth: '40%',
                    placeHolder:'Enter Value',
                    cls: 'bonnet'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Booties',
                    name: 'booties',
                    placeHolder:'Enter Value',
                    labelWidth: '40%',
                    cls:'booties'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Garment bag',
                    name: 'garmentBag',
                    placeHolder:'Enter Value',
                    labelWidth: '40%'
                },
                {
                    xtype: 'currencyTextField',
                    label: 'Shoe bag',
                    name: 'shoeBag',
                    placeHolder:'Enter Value',
                    labelWidth: '40%'
                }
            ]
        });
        this.add(this.formAdditionalKitCostsView);
    },

    resetFields: function () {
        this.formAdditionalKitCostsView.down('field[name=bonnet]').setValue('');
        this.formAdditionalKitCostsView.down('field[name=booties]').setValue('');
        this.formAdditionalKitCostsView.down('field[name=garmentBag]').setValue('');
        this.formAdditionalKitCostsView.down('field[name=shoeBag]').setValue('');
    }
});
