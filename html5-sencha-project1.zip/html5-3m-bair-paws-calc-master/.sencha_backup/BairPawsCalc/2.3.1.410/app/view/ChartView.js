Ext.define('BairPawsCalc.view.ChartView', {
    extend: 'Ext.Panel',
    xtype: 'chartview',
    requires: [
        'Ext.TitleBar',
        'Ext.Video'
    ],
    fullscreen: true,
    containers: [],
    barStack: [],
    toolTips: [],
    colours: [],
    maxValue: 0.00,
    chartMaxHeight: '99%',
    chartMaxWidth: '95%',
    formattedText: '',
    config: {
        cls: 'chartview',
        layout:{
            type:'vbox',
            align:'center'
        },
        items:[{
            html:'Overall Facility Costs (\'000s)',
            cls: 'formHeader titleChartview'
        }]
    },
    previewReferences: function(flag, refNum, screenSection) {
        this.fireEvent('previewReferences', flag, refNum, screenSection);
    },
    formatText: function (number) {
      console.log('number formatter');
      console.log(number);
        this.formattedText = '$' + parseFloat(number).toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return this.formattedText;
    },
    setData: function (data, barNames, hasLegend) {
        var that = this;
        if (this.mainPanel) {
            this.mainPanel.destroy();
        }

        this.legendWrapper = Ext.create('Ext.Container', {
            height: '100%',
            //flex: 10,
            //width:470,
            cls: 'legendWrapper'
        });

        this.mainPanel = Ext.create('Ext.Panel', {
//            fullscreen: true,
            layout: 'hbox',
            height: '80%',
            width: that.chartMaxWidth,
//            margin: '5% auto',
            cls: 'chartViewMainPanel'

        });

        if (this.yAxisContainer) {
            this.yAxisContainer.destroy();
        }
        this.yAxisContainer = Ext.create('Ext.Container', {
//            flex: 1,
            cls:'yAxisContainer',

            layout: {
                type: 'vbox',
                align: 'end',
                pack: 'center'
            }
        });
        this.containerWrapper = Ext.create('Ext.Container', {
            style: 'background:url(resources/images/graphBackground.png) no-repeat; background-size:99% 93%; background-position:0px 24px',
//            flex: 9,
            cls:'containerWrapper',
            height: '75%',
            layout: {
                type: 'hbox',
                align: 'center',
                pack: 'center'
            }

        });

        this.containers = [];

        var containerArray = [],
            barCount = data[0].values.length,
            totalCountArray = [];

        for (var k = 0; k < barCount; k++) {
            var yValueArray = [];
            var totalCount = 0;
            console.log(data);

            Ext.each(data, function (data, index) {
             var dataValue  =  parseFloat(((data.values[k].y)/1000.00));
                var yValuesObj = {};
                yValuesObj.key = data.key;
                yValuesObj.y = dataValue;
                yValuesObj.colorCode = data.colorCode;
                totalCount += parseFloat(dataValue);
                yValueArray[index] = yValuesObj;
            });

            containerArray.push(yValueArray);
            totalCountArray.push(totalCount);
        }
        this.maxValue = Math.max.apply(Math, totalCountArray);

        for (var t = 0; t < containerArray.length; t++) {
            this.renderChart(containerArray[t], totalCountArray[t], barNames[t].name, hasLegend);
        }

        if (hasLegend) {
            that.createLegend(containerArray, barNames);
        }

        var barValues = [],
            barValueStack = [];
        var range = Math.floor(Math.log(this.maxValue) / Math.LN10) ;
        console.log(this.maxValue);

        var yAxisHighestValue = (Math.floor(this.maxValue / Math.pow(10, range-1))) * Math.pow(10, range-1);
        for (var d = 10; d > 0; d--) {
            if (this.maxValue < 100) {
                barValues[10 - d] = '$' + parseFloat((yAxisHighestValue)/ 10.00 * d).toFixed(0);
            } else {
                barValues[10 - d] = '$' + parseFloat((yAxisHighestValue) / 10.00 * d).toFixed(0);
            }

        }
        barValues.push('$' + 0);

        Ext.each(barValues, function (field, index) {
            barValueStack[index] = Ext.create('Ext.Panel', {
                html: barValues[index],
                cls:'yAxisHighestValue',
                style: 'font-size:11px;'
            });
        });

        this.yAxisContainer.add(barValueStack);
        this.showChart(hasLegend);
    },
    renderChart: function (yData, sumOfValues, barName) { // passes {key: 'Value', y: '100'}
        var that = this;
        var barContainer = Ext.create('Ext.Panel', {
            layout: 'vbox',
            flex: 4,
            height: that.chartMaxHeight
            //style: 'margin: 0 2%'
        });
        var yValues = [];
        var barStack = [];
        var unitSize = 0;


        unitSize = 100 / (this.maxValue + (this.maxValue * 10 / 100));
       // alert(unitSize);


        barStack[0] = Ext.create('Ext.Panel', {//filling the chart from top
            height: (93 - (unitSize * sumOfValues)).toString() + '%'
        });
        barStack[1] = Ext.create('Ext.Panel', {//adding total value label
            height: '25px',
            style: 'text-align:center;font-size: 12px;font-weight: bold;',
            listeners: {
                initialize: function () {
                    that.formatText(sumOfValues);
                    this.setHtml(that.formattedText);
                }
            }
        });
        Ext.each(yData, function (data, index) {
            yValues[index] = parseFloat(data.y);
            barStack[index + 2] = Ext.create('Ext.Panel', {
                tooltip: '',
                containerName: '',
                layout: {
                    type: 'hbox',
                    align: 'center',
                    pack: 'center',
                    id: 'contain' + index,
                    constrain: true
                },
                cls: 'pdfChartStyles',
                style: 'background-color: ' + yData[index].colorCode + '; text-align:center',
                listeners: {
                    initialize: function () {
                        this.tooltip = false;
                        this.containerName = yData[index].key;
                        this.setHeight((unitSize * yValues[index]).toString() + '%');

                        if (unitSize * yValues[index] > 14) {
                            that.formatText(yValues[index]);
                            this.add({
                                html: yData[index].key + '<br>' + that.formattedText,
                                style: 'color: white;font-size:12px;'
                            });
                        }
                        else if (unitSize * yValues[index] !== 0.00) {
                            that.formatText(yValues[index]);
                            this.tooltip = true;
                            this.containerName = yData[index].key + '<br>' + that.formattedText;
                        }
                    }
                }

            });

        });

        barStack.push(Ext.create('Ext.Panel', {
            height: '20px',
            layout: {
                type: 'hbox',
                align: 'center',
                pack: 'center'
            },
            items: [
                {
                    html: barName,
                    cls:'barName'
                }
            ],
            style: 'text-align:center; font-size:14px; margin-top:20px;'
        }));

        barContainer.add(barStack);
        that.createTooltips(barStack);
        this.barStack.push(barStack);
        this.containers.push({xtype: 'spacer', flex: 1});
        this.containers.push(barContainer);
    },

    createLegend: function (containerArray, barNames) {
        var that = this;
        var legendContainer = Ext.create('Ext.Container', {
            border: '1 1 1 1',
            cls: 'legendWrapper',
            style: 'border-color: #D5D5D5; border-style: solid;'
        });
        var headerContainer = Ext.create('Ext.Container', {
                layout: {
                    type: 'hbox',
                    align: 'center',
                    pack: 'center'
                },
                cls: 'headerTitles',
                items: [
                        {
                            xtype: 'label',
                            html: 'Category',
                            style: 'text-align:left;',
                            cls:'category',
                            flex: 5
                        }
                    ]}
        );
        for (var h = 0; h < barNames.length; h++) {
            headerContainer.add([{xtype: 'label',html: barNames[h].name,flex: 3,cls:'barNames'}]);
        }

        legendContainer.add([headerContainer]);

        var values = [];

        var colorCodes = new Ext.util.MixedCollection();

        for (var i = 0; i < containerArray.length; i++) {
            values[i] = new Ext.util.MixedCollection();
            for (var j = 0; j < containerArray[i].length; j++) {
                values[i].add(containerArray[i][j].key, containerArray[i][j].y);
            }
        }

        for (var k = 0; k < containerArray[0].length; k++) {
            colorCodes.add(containerArray[0][k].key, containerArray[0][k].colorCode);
        }

        values[0].eachKey(
            function (key, item) {

                var textContainer = Ext.create('Ext.Container', {
                    layout: {
                        type: 'hbox'
                    },
                    border: '0 0 1 0',
                    style: 'border-color: #D5D5D5; border-style: solid;'
                });

                var colorCode = colorCodes.getByKey(key);

                var circleContainer = Ext.create('Ext.Container', {
                    items: [
                        {
                            xtype: 'label',
                            cls: 'custom-circle',
                            style: 'background:' + colorCode + ';width: 15px;height: 15px;'
                        }
                    ],
                    flex: 1,
                    cls:'circleContainer'
                });

                textContainer.add([circleContainer, {xtype: 'label', html: key, flex: 5}, {xtype: 'label', html: that.formatText(item), flex: 3, cls: 'legendValue'}]);

                for (var m = 1; m < containerArray.length; m++) {
                    var legendValue = values[m].getByKey(key);
                    textContainer.add([
                        {xtype: 'label', html: that.formatText(legendValue), flex: 3, cls: 'legendValue'}
                    ]);
                }
                legendContainer.add(textContainer);
            }
        );

        var totalsContainer = Ext.create('Ext.Container', {
            layout: {
                type: 'hbox'
            },
            border: '0'
        });

        totalsContainer.add([
            {xtype: 'spacer', flex: 1},
            {xtype: 'label', html: 'Total', flex: 5, style: 'font-weight:bold', cls:'totalLabel'}
        ]);

        for (var n = 0; n < containerArray.length; n++) {
            var total = 0;
            values[n].eachKey(function (key, item) {
                total += item;
            });
            totalsContainer.add([
                {xtype: 'label', html: that.formatText(total), flex: 3, cls: 'legendValue', style: 'font-weight:bold'}
            ]);
        }

        legendContainer.add(totalsContainer);
        this.legendWrapper.add([legendContainer]);

    },
    showChart: function (hasLegend) {
        this.containerWrapper.add(this.containers);

        this.containerWrapper.add({xtype: 'spacer'});

        if (hasLegend) {
            this.mainPanel.add([this.legendWrapper, this.yAxisContainer, this.containerWrapper]);
        }
        else {
            this.mainPanel.add([this.yAxisContainer, this.containerWrapper]);
        }

        this.add(this.mainPanel);
    },
    createTooltips: function (containerArray) {
        Ext.each(containerArray, function (container, index) {
            if (containerArray[index].tooltip) {
                var cfg = {
                    html: containerArray[index].containerName,
                    element: container,
                    alignment: 'cl-cr?',
                    cls: 'ux-tooltip'
                };
                if (index % 2 === 0) {
                    cfg.alignment = 'cr-cl?';
                }
//                var toolTip = Ext.create('toolTip', cfg);
            }
        });
    },
    setFootNote: function () {
        this.mainPanel.add([
            {
                xtype: 'container',
                style: 'text-align:left;font-size:11px;',
                items: [
                    {html: '*The hypothermia rate with the Bair Paws system is calculated at 13% and the input of "percentage of patients with complications due to hypothermia" provides an estimate of the hypothermia complications. Your individual facility results will vary.',
                    width:'960px',
                    top: '0',
                    left: '0px',
                    style:'text-align:left'}
                ],
                width: '960px',
                height: '40px',
                top: '420px',
                left: '00px'
            }
        ]);
    },
    showDifference: function (difference) {
      var that = this;
      formatedDifference = that.formatText(Math.abs(Math.round(difference)));
      console.log('difference is');
      console.log(difference);
      var message = '';
      var html = '<div class="costSavings"><span class="message">';
      if(difference < 0) {
        message = 'Estimated Investment';
      } else {
        message = 'Estimated Savings';
      }
      var costDifference = formatedDifference;
      html += message;
      html += '</span><span class="savings">';
      html += costDifference;
      html += '</span></div>';
      this.mainPanel.add([
          {
              xtype: 'container',
              items: [
                  {
                    html: html
                  }
              ],
              width: '510px',
              height: '40px',
              top: '350px'
          }
      ]);


    },
    initialize: function () {
        Ext.define('toolTip', {
            extend: 'Ext.Panel',
            alias: 'widget.toolTip',
            config: {
                html: '',
                element: {},
                alignment: '',
                width: 90,
                height: 47,
                hidden: true,
                scrollable: false,
                left: 0,
                top: 0,
                style: 'text-align:center'
            },
            showBy: function (component, alignment) {
                var me = this,
                    isVisible = false,
                    viewport = Ext.Viewport,
                    parent = me.getParent();

                me.setVisibility(false);

                if (parent !== viewport) {
                    viewport.add(me);
                }
                me.show();
                me.on({
                    hide: 'onShowByErased',
                    destroy: 'onShowByErased',
                    single: true,
                    scope: me
                });
                viewport.on('resize', 'alignTo', me, { args: [component, alignment] });
                me.alignTo(component, alignment);
                me.config.element.on({tap: {element: 'element', single: false, fn: function () {
                    if (isVisible) {
                        me.hide();
                        isVisible = false;
                    }
                    else {
                        me.setVisibility(true);
                        me.show();
                        isVisible = true;
                    }
                }}});
                for (var i = 0; i < Ext.Viewport.getItems().length; i++) {
                    Ext.Viewport.getAt(i).on({touchend: {element: 'element', single: false, fn: function () {
                        if (isVisible) {
                            me.hide();
                            isVisible = false;
                        }
                    }}});
                }
            },
            initialize: function () {
                //only show the tooltip, if target element is NOT hidden currently
                if (!this.getElement().getHidden()) {
                    this.callParent(arguments);
                    var toolView = this;
                    setTimeout(function () {
                        toolView.showBy(toolView.getElement(), toolView.getAlignment());
                    }, 1000);
                    setTimeout(function (tooltip) {
                        var config = {touchstart: {element: 'element', scope: tooltip, single: false, fn: function () {
                            tooltip.destroy();
                        }}};
                        var configPainted = {painted: {element: 'element', scope: tooltip, single: false, fn: function () {
                            tooltip.destroy();
                        }}};
                        for (var i = 0; i < Ext.Viewport.getItems().length; i++) {
                            if (Ext.Viewport.getAt(i).xtype === 'main') {
                                Ext.Viewport.getAt(i).navBar.backButton.on(config);
                                Ext.Viewport.getAt(i).navBar.nextButton.on(config);
                                Ext.Viewport.getAt(i).navigationView.getAt(0).on(configPainted);
                            }
                        }
                    }, 100, this);
                }
            }
        });
    }
});
