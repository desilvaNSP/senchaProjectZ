Ext.define('BairPawsCalc.view.BarChartView', {
    extend: 'Ext.Container',
    xtype: 'barchartview',
    requires: [
        'Ext.Ajax'
    ],
    config: {
        cls: 'barChartView',
        layout: 'fit',
        items: [
            {
            }
        ]
    },
    barChart: '',
    initialize: function () {
        this.barChartPanel = Ext.create('Ext.Panel', {
            //layout: 'fit',
            width: '50%',
            height: '100%',
//            padding: '0 0 0 10px',
            items: [
                {
                    xtype:'chartview',
                    cls:'chartViewBar'
                }
            ]
        });

    }
});