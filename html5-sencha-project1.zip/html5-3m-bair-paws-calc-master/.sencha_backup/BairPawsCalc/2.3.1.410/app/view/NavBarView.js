Ext.define('BairPawsCalc.view.NavBarView', {
    extend: 'BairPawsCalc.view.BaseView',
    xtype: 'navbarview',
    requires: [
    ],
    config: {
        cls: 'footerMain',
        height: '80px'
    },
    nextNavigate: function () {
        this.fireEvent('nextNavigation', this);
    },
    backNavigate: function () {
        this.fireEvent('backNavigation', this);
    },
    navbarViewSettingsButtonTapped: function () {
        this.fireEvent('navbarViewSettingsButtonTapped', this);
    },
    pdfGenearate: function (includeComplications) {
        this.fireEvent('pdfGenearate', this, includeComplications);
    },
    initialize: function () {
        var that = this;
        this.nextButton = Ext.create('Ext.Button', {
            text: 'Next',
            padding: '8 18',
            margin: '22 20 0 0',
            height: '37px',
            width:'85px',
            left: 911,
            listeners: {
                tap: function () {
                    that.nextNavigate();
                }
            }
        });
        this.pdfButton = Ext.create('Ext.Button', {
            text: 'PDF',
            padding: '8 18',
            margin: '22 20 0 0',
            height: '37px',
            width:'85px',
            left: 911,
            hidden: true,
            listeners: {
                tap: function () {
                    that.pdfGenearate(true);
                }
            }
        });
        this.secondPdfButton = Ext.create('Ext.Button', {
          text: 'PDF',
          padding: '8 18',
          margin: '22 20 0 0',
          height: '37px',
          width:'85px',
          left: 800,
          hidden: true,
          listeners: {
            tap: function () {
              that.pdfGenearate(false);
            }
          }
        });
        this.backButton = Ext.create('Ext.Button', {
            text: 'Back',
            padding: '8 18',
            margin: '22 0 0 20',
            height: '37px',
            width:'85px',
            left: 0,
            listeners: {
                tap: function () {
                    that.backNavigate();
                }
            },
            hidden: true
        });
        this.settingsButton = Ext.create('Ext.Button', {
            text: '',
            padding: '8 18',
            //margin: '12 20 0 0',
            height: '37px',
            width:'85px',
            left: '32px',
            top: '22px',
            cls: 'settingsButton',
            listeners: {
                tap: function () {
                    that.navbarViewSettingsButtonTapped();
                }
            }
        });
        this.logoImage = Ext.create('Ext.Img', {
            padding: '28 0 0 0',
            src: 'resources/images/placeHolderImage.png',
            height: '25px',
            mode: '',
            left: 483
        });
        this.footerNavBar = Ext.create('Ext.Container', {
            layout: 'hbox',
            items: [
                {
                    items: [this.backButton]
                },
                {
                    items: [this.settingsButton]
                },
                {
                    items: [this.logoImage]
                },
                {
                    items: [this.nextButton]
                },
                {
                    items: [this.pdfButton]
                },
                {
                    items: [this.secondPdfButton]
                }
            ]
        });
        this.add([this.footerNavBar]);
    }
});
