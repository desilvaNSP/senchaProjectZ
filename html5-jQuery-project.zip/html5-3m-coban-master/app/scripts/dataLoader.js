/**
 * Created by premuditha on 4/15/14.
 */

(function ($, w, d, h) {

    var appConfigs = {
        mediaPrefix: '',
        parallaxBackgrounds: false
    };

    function initialize(resJSON) {
        var configs = resJSON.configs;
        appConfigs.mediaPrefix = configs.mediaPrefix;
        appConfigs.parallaxBackgrounds = configs.parallaxBackgrounds.length ? true : false;
        handleData(resJSON);
    }

    function handleData(resJSON) {
        // HandelBar template for Parallax Backgrounds.
        var parallaxBackgroundTemplate = '{{#each configs.parallaxBackgrounds}}' +
                '<div id="parallaxBg-{{@index}}"> <img src="{{this}}"/></div>' +
            '{{/each}}';

        // HandelBar template for Chapter thumbnails.
        var chapterThumbnailTemplate = '{{#each chapters}} ' +
            '<div class="item chapter"> ' +
                '<a href="#chapter{{chapter_no}}" data-first-slide="{{first_slide}}" data-title="{{chapter_title}}" ' +
                        'data-description="{{chapter_description}}">' +
                    '<span class="outer"><img src="' + appConfigs.mediaPrefix + '{{chapter_thumbnail}}">' +
                    '<span class="title">{{chapter_title}}</span></span>' +
                '</a>' +
            '</div>' +
            '{{/each}}';

        // HandelBar template for Slide thumbnails.
        var slidesThumbnailTemplate = '{{#each chapters}} {{#each slides}}' +
            '<div class="item" data-slide-id="{{slide_no}}" data-chapter-no="{{../chapter_no}}">' +
                '<img src="' + appConfigs.mediaPrefix + '{{slide_thumb}}">' +
            '</div>' +
            '{{/each}} {{/each}}';

        // HandelBar template for Slide.
        var slidesTemplate = '{{#each chapters}} {{#each slides}}' +
            '<div class="swiper-slide parent slide-no-{{slide_no}}" style="height: ' + (w.innerHeight - 63) + 'px" ' +
                    'data-content="' + appConfigs.mediaPrefix + '{{slide_content}}" ' +
                    'data-slide-notes="' + appConfigs.mediaPrefix + '{{slide_notes}}" data-slide-no="{{slide_no}}" ' +
                    'data-chapter-no="{{../chapter_no}}" data-vertical-scrollable="{{vertical_scrollable}}"' +
                    'data-related-docs-folder-id = "{{related_docs_folder}}">' +
                '<p class="loading-text">Loading...</p>' +
            '</div>' +
            '{{/each}} {{/each}}';

        if (appConfigs.parallaxBackgrounds) {
            var parallaxBgCompiledTpl = h.compile(parallaxBackgroundTemplate);
            $('div.parallaxHolder').append(parallaxBgCompiledTpl(resJSON));
        }

        var chaptersCompliedTpl = h.compile(chapterThumbnailTemplate);
        $('div.chapters').html(chaptersCompliedTpl(resJSON));

        var slidesThumbCompliedTpl = h.compile(slidesThumbnailTemplate);
        $('div.slides-container').html(slidesThumbCompliedTpl(resJSON));

        var slidesCompliedTpl = h.compile(slidesTemplate);
        $('div.main-slides-container').html(slidesCompliedTpl(resJSON));

        $.event.trigger({type: 'onTemplateRenderComplete'});
    }

    function render() {
        $.getJSON('data/presentations.json', function (data) {
            initialize(data);
        });
    }

    $(d).ready(function () {
        render();
    });

    w.appConfigs = appConfigs;

})(jQuery, window, document, Handlebars);
