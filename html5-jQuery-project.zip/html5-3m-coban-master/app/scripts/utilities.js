//Created by Jason Roy on 5/3/14
$(function () {
    FastClick.attach(document.body);
});