/**
* Created by premuditha on 5/18/14.
*/

(function ($, d) {

    var domElements = {
        parallaxBg0: '',
        parallaxBg1: ''
    };

    function initialize() {
        if (appConfigs.parallaxBackgrounds) {
            domElements.parallaxBg0 = $('#parallaxBg-0');
            domElements.parallaxBg1 = $('#parallaxBg-1');
        }
    }

    function animateParallaxBackgrounds(hScroll) {

        var progress = hScroll.progress;
        //progress is a number between 0 and 1 representing where we are in the entire presentation

        domElements.parallaxBg0.css('-webkit-transform', 'translateX(' + (Math.floor(progress * 2000) * (-0.9)) + 'px)');
        //move(domElements.parallaxBg0[0]).x( Math.floor(progress * 2000) * (-1) ).end();
        //domElements.parallaxBg1.css('left', (Math.floor(progress * 2000) * (0.8)) + 'px');
    }

    function setOpacity(elements, opacity) {
        elements.forEach(function (element) {
            element.css('opacity', opacity);
        });
    }

    function createTouchPoints(mySlideNumber, holderNum) {

        $('div.touchPoints').removeClass().addClass('touchPoints').addClass('slide' + mySlideNumber);
        $('.swiper-slide-active .touchPointHolder:eq('+holderNum+')').children().clone().appendTo('div.touchPoints');

        $('div.touchPoints div.touchPoint a').click(function() {

          var myIndex = $(this).parents('.touchPoint').index();
          var myOpacity = parseFloat( $('.touchPoint:eq('+myIndex+') div.text').css('opacity') );

          if ( myOpacity > 0) {
            $('.touchPoint:eq('+myIndex+') a').removeClass('close');
            $('.touchPoint:eq('+myIndex+') div.text').removeClass('fadeIn');
          } else {
            $('.touchPoint:eq('+myIndex+') a').addClass('close');
            $('.touchPoint:eq('+myIndex+') div.text').addClass('fadeIn');
          }

        });
        $('div.touchPoint').addClass('animated fadeIn');
    }

    $(d).on('onHorizontalSlideChangeStart', function (event) {
      $('div.touchPoints').empty();
      var hScroll = event.horizontalScroll;
      var littleTimeout = setTimeout(function() {
        if ( $('.swiper-slide-active .touchPointHolder:eq(0)').children().length > 0) {
          createTouchPoints(hScroll.activeIndex+1, 0);
        }
      }, 500);
    });


    $(d).on('onVerticalSlideChangeStart', function (event) {
      $('div.touchPoints').empty();
      var vScroll = event.verticalScroll;
      var hScroll = event.horizontalScroll;
      var littleTimeout = setTimeout(function() {
        if ( $('.swiper-slide-active .touchPointHolder:eq('+vScroll.activeIndex+')').children().length > 0) {
          createTouchPoints(hScroll.activeIndex+1, vScroll.activeIndex);
        }
      }, 500);
    });

    $(d).on('onTemplateRenderComplete', function () {
        initialize();
    });

    $(d).on('onHorizontalSlideChangeEnd', function (event) {
      
      var hScroll = event.horizontalScroll; //represents the big swiper object with all sorts of info
      console.log(hScroll.activeIndex);

      if (appConfigs.parallaxBackgrounds && hScroll.activeIndex === 5 || appConfigs.parallaxBackgrounds && hScroll.activeIndex === 7 || appConfigs.parallaxBackgrounds && hScroll.activeIndex === 15) {
        setOpacity([domElements.parallaxBg0, domElements.parallaxBg1], 0);
      } else {
        setOpacity([domElements.parallaxBg0, domElements.parallaxBg1], 1);
      }

      //text animations per slide
      var slideNumber = hScroll.activeIndex + 1;

      var littleTimeout = setTimeout(function() {
        switch (slideNumber) {
          case 2:
            $('.compression').addClass('fadeInLeft');
            $('.effective').addClass('fadeInRight');
            $('.unna').addClass('fadeInLeft');
            break;

          case 3:
            break;

          case 4:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          /*
          case 5:
            $('.large').addClass('fadeInLeft');
            break;
          */

          case 5:
            $('.zinc').addClass('fadeInLeft');
            $('.optimal').addClass('fadeInRight');
            break;

          case 6:
            $('.patient').addClass('fadeInLeft');
            $('.nonCompliance').addClass('fadeInRight');
            break;

          case 7:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          case 9:
            $('.modern').addClass('fadeInLeft');
            $('.compression').addClass('fadeInRight');
            break;

          case 11:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          case 12:
            $('.improvements').addClass('fadeInLeft');
            $('.slippage').addClass('fadeInRight');
            break;

          case 15:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          case 17:
            $('.better').addClass('fadeInLeft');
            $('.consistent').addClass('fadeInRight');
            break;

          case 20:
            $('.betterz').addClass('fadeInLeft');
            $('.easy').addClass('fadeInRight');
            break;

          case 21:
            $('.better').addClass('fadeInLeft');
            $('.standardization').addClass('fadeInRight');
            break;

          case 22:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          case 23:
            $('.large').addClass('fadeInLeft');
            break;

          case 24:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          case 25:
            $('.woundHealing').addClass('fadeInLeft');
            $('.capabilities').addClass('fadeInRight');
            break;

          case 27:
            $('.woundHealing').addClass('fadeInLeft');
            $('.testimonial').addClass('fadeInRight');
            break;

          case 29:
            $('.wrapUp').addClass('fadeInLeft');
            break;

          default:
            break;
        }
      }, 250);


    });

    $(d).on('onProgressChange', function (event) {
        var hScroll = event.horizontalScroll;
        if (appConfigs.parallaxBackgrounds) {
            animateParallaxBackgrounds(hScroll);
        }
    });

    $(d).on('onVerticalSlideChangeEnd onVerticalSliderCreated', function (event) {
        var hScroll = event.horizontalScroll; // in case we need to know what top level slide we're on
        var vScroll = event.verticalScroll;

        if (vScroll) {
            if (appConfigs.parallaxBackgrounds && vScroll.activeIndex === 0 && hScroll.activeIndex !== 5) {
                setOpacity([domElements.parallaxBg0, domElements.parallaxBg1], 1);
            }
            else if (appConfigs.parallaxBackgrounds && vScroll.activeIndex !== 0) {
                setOpacity([domElements.parallaxBg0, domElements.parallaxBg1], 0);
            }
        }
    });
})(jQuery, document);